-- ============================================================
-- 범일NPC 술번개 — 전체 DB 셋업 (새 Supabase 프로젝트에 한 번만 실행)
-- Supabase 대시보드 → SQL Editor → 전체 붙여넣기 → Run
-- ============================================================

-- ─── 테이블 생성 ──────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nickname text NOT NULL UNIQUE,
  bio text,
  photo_url text DEFAULT 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=400',
  personality_score integer NOT NULL DEFAULT 50 CHECK (personality_score >= 0 AND personality_score <= 100),
  dom_sub_score integer DEFAULT NULL CHECK (dom_sub_score IS NULL OR (dom_sub_score >= 0 AND dom_sub_score <= 100)),
  mbti text,
  birth_year smallint,
  location text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  liker_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  liked_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(liker_id, liked_id)
);

CREATE TABLE IF NOT EXISTS chats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user1_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user2_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user1_id, user2_id),
  CHECK (user1_id != user2_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  image_url text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS contact_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  liker_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  liked_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  kakao text,
  instagram text,
  phone text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(liker_id, liked_id)
);

CREATE TABLE IF NOT EXISTS app_settings (
  id integer PRIMARY KEY DEFAULT 1,
  session_active boolean NOT NULL DEFAULT false,
  admin_phone text NOT NULL DEFAULT '010-0000-0000',
  admin_password text NOT NULL DEFAULT 'admin1234',
  game_state jsonb DEFAULT NULL,
  timer_end_at timestamptz DEFAULT NULL,
  timer_label text DEFAULT NULL,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT app_settings_singleton CHECK (id = 1)
);

CREATE TABLE IF NOT EXISTS seats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_number integer NOT NULL,
  seat_position integer NOT NULL,
  seat_label text NOT NULL,
  profile_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'empty' CHECK (status IN ('empty', 'occupied')),
  registered_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(table_number, seat_position)
);

CREATE TABLE IF NOT EXISTS session_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ended_at timestamptz NOT NULL DEFAULT now(),
  seats_snapshot jsonb NOT NULL
);

CREATE TABLE IF NOT EXISTS suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  nickname text,
  content text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  admin_reason text,
  contact_info text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS balance_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  creator_nickname text,
  scope text DEFAULT 'global' CHECK (scope IN ('global', 'table')),
  table_number integer,
  question text NOT NULL,
  option_a text NOT NULL,
  option_b text NOT NULL,
  status text DEFAULT 'active' CHECK (status IN ('active', 'ended')),
  created_at timestamptz DEFAULT now(),
  ended_at timestamptz
);

CREATE TABLE IF NOT EXISTS balance_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES balance_games(id) ON DELETE CASCADE,
  voter_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  option text NOT NULL CHECK (option IN ('a', 'b')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(game_id, voter_id)
);

CREATE TABLE IF NOT EXISTS anonymous_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_number integer,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info',
  target text NOT NULL DEFAULT 'all',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- ─── 인덱스 ───────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_likes_liker_id ON likes(liker_id);
CREATE INDEX IF NOT EXISTS idx_likes_liked_id ON likes(liked_id);
CREATE INDEX IF NOT EXISTS idx_chats_users ON chats(user1_id, user2_id);
CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- ─── RLS 활성화 ───────────────────────────────────────────────

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE seats ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE suggestions ENABLE ROW LEVEL SECURITY;
ALTER TABLE balance_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE balance_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE anonymous_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- ─── RLS 정책 ─────────────────────────────────────────────────

-- profiles
DROP POLICY IF EXISTS "anon_select_profiles" ON profiles;
CREATE POLICY "anon_select_profiles" ON profiles FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_profiles" ON profiles;
CREATE POLICY "anon_insert_profiles" ON profiles FOR INSERT TO anon, authenticated WITH CHECK (char_length(nickname) >= 1 AND char_length(nickname) <= 20);
DROP POLICY IF EXISTS "anon_update_profiles" ON profiles;
CREATE POLICY "anon_update_profiles" ON profiles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_profiles" ON profiles;
CREATE POLICY "anon_delete_profiles" ON profiles FOR DELETE TO anon, authenticated USING (true);

-- likes
DROP POLICY IF EXISTS "anon_select_likes" ON likes;
CREATE POLICY "anon_select_likes" ON likes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_likes" ON likes;
CREATE POLICY "anon_insert_likes" ON likes FOR INSERT TO anon, authenticated WITH CHECK (liker_id != liked_id);
DROP POLICY IF EXISTS "anon_update_likes" ON likes;
CREATE POLICY "anon_update_likes" ON likes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_likes" ON likes;
CREATE POLICY "anon_delete_likes" ON likes FOR DELETE TO anon, authenticated USING (true);

-- chats
DROP POLICY IF EXISTS "anon_select_chats" ON chats;
CREATE POLICY "anon_select_chats" ON chats FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_chats" ON chats;
CREATE POLICY "anon_insert_chats" ON chats FOR INSERT TO anon, authenticated WITH CHECK (user1_id != user2_id);

-- messages
DROP POLICY IF EXISTS "anon_select_messages" ON messages;
CREATE POLICY "anon_select_messages" ON messages FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT TO anon, authenticated WITH CHECK (char_length(content) >= 1);

-- contact_shares
DROP POLICY IF EXISTS "anon_select_contact_shares" ON contact_shares;
CREATE POLICY "anon_select_contact_shares" ON contact_shares FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_contact_shares" ON contact_shares;
CREATE POLICY "anon_insert_contact_shares" ON contact_shares FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_contact_shares" ON contact_shares;
CREATE POLICY "anon_update_contact_shares" ON contact_shares FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- app_settings
DROP POLICY IF EXISTS "app_settings_select" ON app_settings;
CREATE POLICY "app_settings_select" ON app_settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "app_settings_update" ON app_settings;
CREATE POLICY "app_settings_update" ON app_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- seats
DROP POLICY IF EXISTS "seats_select" ON seats;
CREATE POLICY "seats_select" ON seats FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "seats_insert" ON seats;
CREATE POLICY "seats_insert" ON seats FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "seats_update" ON seats;
CREATE POLICY "seats_update" ON seats FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "seats_delete" ON seats;
CREATE POLICY "seats_delete" ON seats FOR DELETE TO anon, authenticated USING (true);

-- session_history
DROP POLICY IF EXISTS "history_select" ON session_history;
CREATE POLICY "history_select" ON session_history FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "history_insert" ON session_history;
CREATE POLICY "history_insert" ON session_history FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "history_delete" ON session_history;
CREATE POLICY "history_delete" ON session_history FOR DELETE TO anon, authenticated USING (true);

-- suggestions
DROP POLICY IF EXISTS "select_suggestions" ON suggestions;
CREATE POLICY "select_suggestions" ON suggestions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_suggestions" ON suggestions;
CREATE POLICY "insert_suggestions" ON suggestions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_suggestions" ON suggestions;
CREATE POLICY "update_suggestions" ON suggestions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_suggestions" ON suggestions;
CREATE POLICY "anon_delete_suggestions" ON suggestions FOR DELETE TO anon, authenticated USING (true);

-- balance_games
DROP POLICY IF EXISTS "select_balance_games" ON balance_games;
CREATE POLICY "select_balance_games" ON balance_games FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_balance_games" ON balance_games;
CREATE POLICY "insert_balance_games" ON balance_games FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_balance_games" ON balance_games;
CREATE POLICY "update_balance_games" ON balance_games FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- balance_votes
DROP POLICY IF EXISTS "select_balance_votes" ON balance_votes;
CREATE POLICY "select_balance_votes" ON balance_votes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_balance_votes" ON balance_votes;
CREATE POLICY "insert_balance_votes" ON balance_votes FOR INSERT TO anon, authenticated WITH CHECK (true);

-- anonymous_reports
DROP POLICY IF EXISTS "select_anonymous_reports" ON anonymous_reports;
CREATE POLICY "select_anonymous_reports" ON anonymous_reports FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_anonymous_reports" ON anonymous_reports;
CREATE POLICY "insert_anonymous_reports" ON anonymous_reports FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_anonymous_reports" ON anonymous_reports;
CREATE POLICY "anon_delete_anonymous_reports" ON anonymous_reports FOR DELETE TO anon, authenticated USING (true);

-- notifications
DROP POLICY IF EXISTS "notif_select" ON notifications;
CREATE POLICY "notif_select" ON notifications FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "notif_insert" ON notifications;
CREATE POLICY "notif_insert" ON notifications FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "notif_update" ON notifications;
CREATE POLICY "notif_update" ON notifications FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "notif_delete" ON notifications;
CREATE POLICY "notif_delete" ON notifications FOR DELETE TO anon, authenticated USING (true);

-- ─── Realtime ─────────────────────────────────────────────────

ALTER PUBLICATION supabase_realtime ADD TABLE
  profiles, likes, chats, messages,
  app_settings, suggestions,
  balance_games, balance_votes, anonymous_reports,
  notifications;

-- ─── Storage ──────────────────────────────────────────────────

INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "anon_insert_chat_images" ON storage.objects;
CREATE POLICY "anon_insert_chat_images" ON storage.objects
  FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'chat-images');

-- ─── 초기 데이터 ──────────────────────────────────────────────

-- 앱 설정 (관리자 비밀번호는 여기서 변경 가능)
INSERT INTO app_settings (id, session_active, admin_phone, admin_password)
VALUES (1, false, '010-0000-0000', 'admin1234')
ON CONFLICT (id) DO NOTHING;

-- 좌석 (A~L 테이블, 각 8자리)
-- A-D: 일반 테이블 (하단2 + 좌측3 + 우측3)
INSERT INTO seats (table_number, seat_position, seat_label) VALUES
  (1,1,'A테이블 하단 1'),(1,2,'A테이블 하단 2'),(1,3,'A테이블 좌측 1'),(1,4,'A테이블 좌측 2'),(1,5,'A테이블 좌측 3'),(1,6,'A테이블 우측 1'),(1,7,'A테이블 우측 2'),(1,8,'A테이블 우측 3'),
  (2,1,'B테이블 하단 1'),(2,2,'B테이블 하단 2'),(2,3,'B테이블 좌측 1'),(2,4,'B테이블 좌측 2'),(2,5,'B테이블 좌측 3'),(2,6,'B테이블 우측 1'),(2,7,'B테이블 우측 2'),(2,8,'B테이블 우측 3'),
  (3,1,'C테이블 하단 1'),(3,2,'C테이블 하단 2'),(3,3,'C테이블 좌측 1'),(3,4,'C테이블 좌측 2'),(3,5,'C테이블 좌측 3'),(3,6,'C테이블 우측 1'),(3,7,'C테이블 우측 2'),(3,8,'C테이블 우측 3'),
  (4,1,'D테이블 하단 1'),(4,2,'D테이블 하단 2'),(4,3,'D테이블 좌측 1'),(4,4,'D테이블 좌측 2'),(4,5,'D테이블 좌측 3'),(4,6,'D테이블 우측 1'),(4,7,'D테이블 우측 2'),(4,8,'D테이블 우측 3'),
-- E-H: 일반 테이블
  (5,1,'E테이블 하단 1'),(5,2,'E테이블 하단 2'),(5,3,'E테이블 좌측 1'),(5,4,'E테이블 좌측 2'),(5,5,'E테이블 좌측 3'),(5,6,'E테이블 우측 1'),(5,7,'E테이블 우측 2'),(5,8,'E테이블 우측 3'),
  (6,1,'F테이블 하단 1'),(6,2,'F테이블 하단 2'),(6,3,'F테이블 좌측 1'),(6,4,'F테이블 좌측 2'),(6,5,'F테이블 좌측 3'),(6,6,'F테이블 우측 1'),(6,7,'F테이블 우측 2'),(6,8,'F테이블 우측 3'),
  (7,1,'G테이블 하단 1'),(7,2,'G테이블 하단 2'),(7,3,'G테이블 좌측 1'),(7,4,'G테이블 좌측 2'),(7,5,'G테이블 좌측 3'),(7,6,'G테이블 우측 1'),(7,7,'G테이블 우측 2'),(7,8,'G테이블 우측 3'),
  (8,1,'H테이블 하단 1'),(8,2,'H테이블 하단 2'),(8,3,'H테이블 좌측 1'),(8,4,'H테이블 좌측 2'),(8,5,'H테이블 좌측 3'),(8,6,'H테이블 우측 1'),(8,7,'H테이블 우측 2'),(8,8,'H테이블 우측 3'),
-- I-L: 소파 테이블 (소파3 + 맞은편3 + 하단/상단2)
  (9,1,'I테이블 소파 1'),(9,2,'I테이블 소파 2'),(9,3,'I테이블 소파 3'),(9,4,'I테이블 맞은편 1'),(9,5,'I테이블 맞은편 2'),(9,6,'I테이블 맞은편 3'),(9,7,'I테이블 하단 1'),(9,8,'I테이블 하단 2'),
  (10,1,'J테이블 소파 1'),(10,2,'J테이블 소파 2'),(10,3,'J테이블 소파 3'),(10,4,'J테이블 맞은편 1'),(10,5,'J테이블 맞은편 2'),(10,6,'J테이블 맞은편 3'),(10,7,'J테이블 하단 1'),(10,8,'J테이블 하단 2'),
  (11,1,'K테이블 소파 1'),(11,2,'K테이블 소파 2'),(11,3,'K테이블 소파 3'),(11,4,'K테이블 맞은편 1'),(11,5,'K테이블 맞은편 2'),(11,6,'K테이블 맞은편 3'),(11,7,'K테이블 상단 1'),(11,8,'K테이블 상단 2'),
  (12,1,'L테이블 소파 1'),(12,2,'L테이블 소파 2'),(12,3,'L테이블 소파 3'),(12,4,'L테이블 맞은편 1'),(12,5,'L테이블 맞은편 2'),(12,6,'L테이블 맞은편 3'),(12,7,'L테이블 상단 1'),(12,8,'L테이블 상단 2')
ON CONFLICT DO NOTHING;
