-- Update seat_labels to use alphabet format matching admin QR tab TABLE_LABELS
-- A=1, B=2, C=3, D=4, E=5, F=6, G=7, H=8, I=9, J=10
UPDATE seats SET seat_label =
  CASE table_number
    WHEN 1  THEN REPLACE(seat_label, '1번 테이블',  'A테이블')
    WHEN 2  THEN REPLACE(seat_label, '2번 테이블',  'B테이블')
    WHEN 3  THEN REPLACE(seat_label, '3번 테이블',  'C테이블')
    WHEN 4  THEN REPLACE(seat_label, '4번 테이블',  'D테이블')
    WHEN 5  THEN REPLACE(seat_label, '5번 테이블',  'E테이블')
    WHEN 6  THEN REPLACE(seat_label, '6번 테이블',  'F테이블')
    WHEN 7  THEN REPLACE(seat_label, '7번 테이블',  'G테이블')
    WHEN 8  THEN REPLACE(seat_label, '8번 테이블',  'H테이블')
    WHEN 9  THEN REPLACE(seat_label, '9번 테이블',  'I테이블')
    WHEN 10 THEN REPLACE(seat_label, '10번 테이블', 'J테이블')
    ELSE seat_label
  END;
