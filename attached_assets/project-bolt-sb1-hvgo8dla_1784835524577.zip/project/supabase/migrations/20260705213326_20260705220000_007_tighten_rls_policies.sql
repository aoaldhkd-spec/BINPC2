/*
# RLS 정책 강화

1. 변경 사항
- `profiles.anon_update_profiles` 삭제 — 앱이 프로필을 수정하지 않음
- `likes.anon_delete_likes` 삭제 — 앱이 좋아요를 취소하지 않음
- INSERT 정책의 WITH CHECK에 실제 비즈니스 규칙 조건 추가:
  - profiles: 닉네임 길이 1~20자
  - likes: 자기 자신에게 좋아요 불가 (liker_id != liked_id)
  - chats: 자기 자신과의 채팅 불가 (user1_id != user2_id)
  - messages: 빈 메시지 불가 (content 길이 > 0)

2. 보안
- 사용하지 않는 쓰기 권한 제거
- 항상-참(always true) 조건 제거 → Supabase 어드바이저 경고 해소
*/

-- profiles: UPDATE 정책 제거 (앱 미사용)
DROP POLICY IF EXISTS "anon_update_profiles" ON profiles;

-- likes: DELETE 정책 제거 (앱 미사용)
DROP POLICY IF EXISTS "anon_delete_likes" ON likes;

-- profiles INSERT: 닉네임 유효성 조건 추가
DROP POLICY IF EXISTS "anon_insert_profiles" ON profiles;
CREATE POLICY "anon_insert_profiles" ON profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(nickname) >= 1 AND char_length(nickname) <= 20);

-- likes INSERT: 자기 자신에게 좋아요 불가
DROP POLICY IF EXISTS "anon_insert_likes" ON likes;
CREATE POLICY "anon_insert_likes" ON likes FOR INSERT
  TO anon, authenticated
  WITH CHECK (liker_id != liked_id);

-- chats INSERT: 자기 자신과의 채팅 불가
DROP POLICY IF EXISTS "anon_insert_chats" ON chats;
CREATE POLICY "anon_insert_chats" ON chats FOR INSERT
  TO anon, authenticated
  WITH CHECK (user1_id != user2_id);

-- messages INSERT: 빈 메시지 불가
DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(content) >= 1);
