-- Add contact info fields directly to profiles
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS contact_private BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS kakao_id TEXT,
  ADD COLUMN IF NOT EXISTS instagram_id TEXT,
  ADD COLUMN IF NOT EXISTS phone_number TEXT;
