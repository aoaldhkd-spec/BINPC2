-- 1. Add status to likes (accept/reject)
ALTER TABLE likes ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected'));

-- 2. Suggestions table
CREATE TABLE IF NOT EXISTS suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  nickname text,
  content text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  admin_reason text,
  contact_info text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE suggestions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_suggestions" ON suggestions FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_suggestions" ON suggestions FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_suggestions" ON suggestions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- 3. Redesign seats: clear old data, add new 8-table layout
DELETE FROM seats;

-- Row 1: Tables 1-4, 8 seats each (top2, bottom2, left2, right2)
DO $$
DECLARE
  t int; pos int;
  labels text[] := ARRAY['상단 1','상단 2','하단 1','하단 2','좌측 1','좌측 2','우측 1','우측 2'];
BEGIN
  FOR t IN 1..4 LOOP
    FOR pos IN 1..8 LOOP
      INSERT INTO seats (table_number, seat_position, seat_label, status)
      VALUES (t, pos, t || '번 테이블 ' || labels[pos], 'empty');
    END LOOP;
  END LOOP;
END $$;

-- Row 2 Left: Table 5 (sofa left side): sofa3, face3, bottom2
-- seat_position: 1-3=소파(left), 4-6=맞은편(right), 7-8=하단
INSERT INTO seats (table_number, seat_position, seat_label, status) VALUES
  (5, 1, '5번 테이블 소파 1', 'empty'),
  (5, 2, '5번 테이블 소파 2', 'empty'),
  (5, 3, '5번 테이블 소파 3', 'empty'),
  (5, 4, '5번 테이블 맞은편 1', 'empty'),
  (5, 5, '5번 테이블 맞은편 2', 'empty'),
  (5, 6, '5번 테이블 맞은편 3', 'empty'),
  (5, 7, '5번 테이블 하단 1', 'empty'),
  (5, 8, '5번 테이블 하단 2', 'empty');

-- Row 2 Right: Table 6 (sofa right side): sofa3, face3, bottom2
INSERT INTO seats (table_number, seat_position, seat_label, status) VALUES
  (6, 1, '6번 테이블 소파 1', 'empty'),
  (6, 2, '6번 테이블 소파 2', 'empty'),
  (6, 3, '6번 테이블 소파 3', 'empty'),
  (6, 4, '6번 테이블 맞은편 1', 'empty'),
  (6, 5, '6번 테이블 맞은편 2', 'empty'),
  (6, 6, '6번 테이블 맞은편 3', 'empty'),
  (6, 7, '6번 테이블 하단 1', 'empty'),
  (6, 8, '6번 테이블 하단 2', 'empty');

-- Row 3 Left: Table 7 (sofa left side): sofa3, face3, top2, no bottom
INSERT INTO seats (table_number, seat_position, seat_label, status) VALUES
  (7, 1, '7번 테이블 소파 1', 'empty'),
  (7, 2, '7번 테이블 소파 2', 'empty'),
  (7, 3, '7번 테이블 소파 3', 'empty'),
  (7, 4, '7번 테이블 맞은편 1', 'empty'),
  (7, 5, '7번 테이블 맞은편 2', 'empty'),
  (7, 6, '7번 테이블 맞은편 3', 'empty'),
  (7, 7, '7번 테이블 상단 1', 'empty'),
  (7, 8, '7번 테이블 상단 2', 'empty');

-- Row 3 Right: Table 8 (sofa right side): sofa3, face3, top2, no bottom
INSERT INTO seats (table_number, seat_position, seat_label, status) VALUES
  (8, 1, '8번 테이블 소파 1', 'empty'),
  (8, 2, '8번 테이블 소파 2', 'empty'),
  (8, 3, '8번 테이블 소파 3', 'empty'),
  (8, 4, '8번 테이블 맞은편 1', 'empty'),
  (8, 5, '8번 테이블 맞은편 2', 'empty'),
  (8, 6, '8번 테이블 맞은편 3', 'empty'),
  (8, 7, '8번 테이블 상단 1', 'empty'),
  (8, 8, '8번 테이블 상단 2', 'empty');
