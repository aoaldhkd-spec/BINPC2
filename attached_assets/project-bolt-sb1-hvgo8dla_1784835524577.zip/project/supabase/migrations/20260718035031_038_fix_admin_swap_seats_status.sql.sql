-- Fix status column assignment in admin_swap_seats (status is text 'occupied'/'empty')
CREATE OR REPLACE FUNCTION admin_swap_seats(
  p_seat_a_id uuid,
  p_seat_b_id uuid,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_pw text;
  v_token text;
  v_profile_a text;
  v_profile_b text;
BEGIN
  IF p_seat_a_id = p_seat_b_id THEN RETURN; END IF;

  BEGIN
    v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;

  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;

  SELECT profile_id::text INTO v_profile_a FROM seats WHERE id = p_seat_a_id;
  SELECT profile_id::text INTO v_profile_b FROM seats WHERE id = p_seat_b_id;

  UPDATE seats SET profile_id = v_profile_b::uuid,
                   status = CASE WHEN v_profile_b IS NOT NULL THEN 'occupied' ELSE 'empty' END,
                   registered_at = CASE WHEN v_profile_b IS NOT NULL THEN now() ELSE NULL END
  WHERE id = p_seat_a_id;

  UPDATE seats SET profile_id = v_profile_a::uuid,
                   status = CASE WHEN v_profile_a IS NOT NULL THEN 'occupied' ELSE 'empty' END,
                   registered_at = CASE WHEN v_profile_a IS NOT NULL THEN now() ELSE NULL END
  WHERE id = p_seat_b_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_swap_seats(uuid, uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION admin_swap_seats(uuid, uuid, text) TO anon;