/*
# Enable Realtime for all tables

Adds profiles, likes, chats, and messages to the supabase_realtime publication
so that postgres_changes subscriptions work from the frontend client.
*/

ALTER PUBLICATION supabase_realtime ADD TABLE profiles, likes, chats, messages;
