-- 1. Enable realtime for app_settings and suggestions
ALTER PUBLICATION supabase_realtime ADD TABLE app_settings, suggestions;

-- 2. Add game_state column to app_settings
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS game_state jsonb DEFAULT NULL;

-- 3. Update Row 1 seat labels: no top, left(3), right(3), bottom(2)
-- pos1-2 = 하단, pos3-5 = 좌측1-3, pos6-8 = 우측1-3
UPDATE seats SET seat_label = table_number || '번 테이블 하단 1' WHERE table_number IN (1,2,3,4) AND seat_position = 1;
UPDATE seats SET seat_label = table_number || '번 테이블 하단 2' WHERE table_number IN (1,2,3,4) AND seat_position = 2;
UPDATE seats SET seat_label = table_number || '번 테이블 좌측 1' WHERE table_number IN (1,2,3,4) AND seat_position = 3;
UPDATE seats SET seat_label = table_number || '번 테이블 좌측 2' WHERE table_number IN (1,2,3,4) AND seat_position = 4;
UPDATE seats SET seat_label = table_number || '번 테이블 좌측 3' WHERE table_number IN (1,2,3,4) AND seat_position = 5;
UPDATE seats SET seat_label = table_number || '번 테이블 우측 1' WHERE table_number IN (1,2,3,4) AND seat_position = 6;
UPDATE seats SET seat_label = table_number || '번 테이블 우측 2' WHERE table_number IN (1,2,3,4) AND seat_position = 7;
UPDATE seats SET seat_label = table_number || '번 테이블 우측 3' WHERE table_number IN (1,2,3,4) AND seat_position = 8;
