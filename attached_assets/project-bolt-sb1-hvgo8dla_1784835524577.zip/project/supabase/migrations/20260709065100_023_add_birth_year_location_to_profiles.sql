ALTER TABLE profiles ADD COLUMN IF NOT EXISTS birth_year smallint;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS location text;
