ALTER TABLE app_settings
  ADD COLUMN IF NOT EXISTS timer_end_at timestamptz DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS timer_label text DEFAULT NULL;
