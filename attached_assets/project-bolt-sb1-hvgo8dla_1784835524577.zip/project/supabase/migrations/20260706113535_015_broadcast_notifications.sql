/*
# Add broadcast_notifications table

## Purpose
Allows the admin to send broadcast messages (공지/긴급/이벤트) to all users or specific tables.
Users see active notifications as a dismissable banner in the app in realtime.

## New Tables
- `notifications`
  - id: uuid primary key
  - message: text — the notification content
  - type: text — 'info' | 'urgent' | 'event' (affects badge color in UI)
  - target: text — 'all' or 'table_1' ... 'table_10'
  - is_active: boolean — when false, notification is archived/dismissed
  - created_at: timestamptz

## Security
- RLS enabled.
- anon + authenticated can SELECT (so users see notifications).
- Only anon + authenticated INSERT/UPDATE/DELETE (no auth system, admin uses same anon key).
*/

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info',
  target text NOT NULL DEFAULT 'all',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "notif_select" ON notifications;
CREATE POLICY "notif_select" ON notifications FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "notif_insert" ON notifications;
CREATE POLICY "notif_insert" ON notifications FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "notif_update" ON notifications;
CREATE POLICY "notif_update" ON notifications FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "notif_delete" ON notifications;
CREATE POLICY "notif_delete" ON notifications FOR DELETE
TO anon, authenticated USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
