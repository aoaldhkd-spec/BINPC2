-- Allow anon/authenticated users to delete records (admin operations)
CREATE POLICY "anon_delete_profiles" ON profiles FOR DELETE
  TO anon, authenticated USING (true);

CREATE POLICY "anon_delete_likes" ON likes FOR DELETE
  TO anon, authenticated USING (true);

CREATE POLICY "anon_delete_anonymous_reports" ON anonymous_reports FOR DELETE
  TO anon, authenticated USING (true);

CREATE POLICY "anon_delete_suggestions" ON suggestions FOR DELETE
  TO anon, authenticated USING (true);
