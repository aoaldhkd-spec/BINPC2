-- Fix admin_force_seat to also displace any existing occupant of the target seat
CREATE OR REPLACE FUNCTION admin_force_seat(
  p_profile_id text,
  p_seat_id uuid,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_pw text;
BEGIN
  SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
  IF v_pw IS DISTINCT FROM p_admin_password THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  -- Clear the profile's current seat (wherever they are now)
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
  -- Clear any existing occupant from the target seat (displace them)
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id = p_seat_id AND profile_id IS NOT NULL AND profile_id != p_profile_id;
  -- Assign profile to target seat
  UPDATE seats SET profile_id = p_profile_id, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
END;
$$;

GRANT EXECUTE ON FUNCTION admin_force_seat(text, uuid, text) TO anon, authenticated;
