-- dom_sub_score nullable: null means 일반/보통
ALTER TABLE profiles ALTER COLUMN dom_sub_score DROP NOT NULL;
ALTER TABLE profiles ALTER COLUMN dom_sub_score SET DEFAULT NULL;