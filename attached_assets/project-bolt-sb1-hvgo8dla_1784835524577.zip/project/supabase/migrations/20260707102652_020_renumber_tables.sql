-- Step 1: delete obsolete tables 9 and 10
DELETE FROM seats WHERE table_number IN (9, 10);

-- Step 2: shift all remaining table numbers to temp range (avoid unique constraint conflicts)
UPDATE seats SET table_number = table_number + 100;
-- now: old 1→101, 2→102, 3→103, 4→104, 5→105, 6→106, 7→107, 8→108, 11→111, 12→112, 13→113, 14→114

-- Step 3: remap to new table numbers
--   old 14 (114) → 1   old 13 (113) → 2   old 12 (112) → 3   old 11 (111) → 4
--   old 2  (102) → 5   old 3  (103) → 6   old 1  (101) → 7   old 4  (104) → 8
--   old 5  (105) → 9   old 7  (107) → 10  old 6  (106) → 11  old 8  (108) → 12
UPDATE seats SET table_number = CASE table_number
  WHEN 114 THEN 1
  WHEN 113 THEN 2
  WHEN 112 THEN 3
  WHEN 111 THEN 4
  WHEN 102 THEN 5
  WHEN 103 THEN 6
  WHEN 101 THEN 7
  WHEN 104 THEN 8
  WHEN 105 THEN 9
  WHEN 107 THEN 10
  WHEN 106 THEN 11
  WHEN 108 THEN 12
  ELSE table_number
END;

-- Step 4: update seat_labels — replace old letter prefix with new letter
-- After renaming, each new table_number maps to a new letter (new 1=A … 12=L)
-- Old letter that was in seat_label (based on old table before renaming):
--   new 1  ← old 14 (was N테이블) → A테이블
--   new 2  ← old 13 (was M테이블) → B테이블
--   new 3  ← old 12 (was L테이블) → C테이블
--   new 4  ← old 11 (was K테이블) → D테이블
--   new 5  ← old 2  (was B테이블) → E테이블
--   new 6  ← old 3  (was C테이블) → F테이블
--   new 7  ← old 1  (was A테이블) → G테이블
--   new 8  ← old 4  (was D테이블) → H테이블
--   new 9  ← old 5  (was E테이블) → I테이블
--   new 10 ← old 7  (was G테이블) → J테이블
--   new 11 ← old 6  (was F테이블) → K테이블
--   new 12 ← old 8  (was H테이블) → L테이블
UPDATE seats SET seat_label = CASE table_number
  WHEN 1  THEN REPLACE(seat_label, 'N테이블', 'A테이블')
  WHEN 2  THEN REPLACE(seat_label, 'M테이블', 'B테이블')
  WHEN 3  THEN REPLACE(seat_label, 'L테이블', 'C테이블')
  WHEN 4  THEN REPLACE(seat_label, 'K테이블', 'D테이블')
  WHEN 5  THEN REPLACE(seat_label, 'B테이블', 'E테이블')
  WHEN 6  THEN REPLACE(seat_label, 'C테이블', 'F테이블')
  WHEN 7  THEN REPLACE(seat_label, 'A테이블', 'G테이블')
  WHEN 8  THEN REPLACE(seat_label, 'D테이블', 'H테이블')
  WHEN 9  THEN REPLACE(seat_label, 'E테이블', 'I테이블')
  WHEN 10 THEN REPLACE(seat_label, 'G테이블', 'J테이블')
  WHEN 11 THEN REPLACE(seat_label, 'F테이블', 'K테이블')
  WHEN 12 THEN REPLACE(seat_label, 'H테이블', 'L테이블')
  ELSE seat_label
END;
