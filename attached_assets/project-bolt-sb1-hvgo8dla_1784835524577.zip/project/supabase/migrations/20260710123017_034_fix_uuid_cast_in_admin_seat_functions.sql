-- Fix: restore ::uuid cast for profile_id comparisons in admin seat functions
-- (Migration 033 overwrote the fix from migration 032)

CREATE OR REPLACE FUNCTION admin_force_seat(
  p_profile_id text, p_seat_id uuid, p_admin_password text
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pw text; v_token text;
BEGIN
  BEGIN v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;
  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id::uuid;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id = p_seat_id AND profile_id IS NOT NULL AND profile_id != p_profile_id::uuid;
  UPDATE seats SET profile_id = p_profile_id::uuid, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
END;
$$;

CREATE OR REPLACE FUNCTION admin_clear_profile_seat(p_profile_id text, p_admin_password text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pw text; v_token text;
BEGIN
  BEGIN v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;
  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id::uuid;
END;
$$;

GRANT EXECUTE ON FUNCTION admin_force_seat(text, uuid, text) TO anon;
GRANT EXECUTE ON FUNCTION admin_clear_profile_seat(text, text) TO anon;
