/*
# Add heart_type column to likes table

1. Purpose
- Support three distinct heart types, each with its own quota of 2:
  - 'red'   : 맘에 드는 사람 (romantic interest) — the original/default heart
  - 'blue'  : 친구하고 싶어요 (wanna be friends)
  - 'pink'  : 뜨밤 (sleepover / want to spend the night together)
- All three types share the same matching flow: send → recipient accepts/rejects → contact exchange.
- The existing UNIQUE(liker_id, liked_id) constraint is kept, meaning a user can send at most ONE heart (of any type) to a given person.

2. Schema changes
- ALTER TABLE likes ADD COLUMN heart_type text DEFAULT 'red' CHECK (heart_type IN ('red','blue','pink')).
  - Existing rows backfill to 'red' automatically via the DEFAULT.
  - New inserts must specify one of the three values (or default to 'red').

3. Security
- No new tables. RLS on likes is unchanged (already open to anon/authenticated for SELECT/INSERT/DELETE/UPDATE).
- No policy changes needed.

4. Backward compatibility
- DEFAULT 'red' ensures all pre-existing hearts are treated as the original red heart.
- No destructive operations; no data loss.
*/

ALTER TABLE likes ADD COLUMN IF NOT EXISTS heart_type text DEFAULT 'red' CHECK (heart_type IN ('red','blue','pink'));
