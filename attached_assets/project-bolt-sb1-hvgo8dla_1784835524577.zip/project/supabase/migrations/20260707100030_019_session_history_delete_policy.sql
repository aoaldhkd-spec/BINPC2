CREATE POLICY "history_delete" ON session_history FOR DELETE
  TO anon, authenticated USING (true);
