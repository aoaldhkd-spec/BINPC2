-- Drop the overly broad SELECT policy on storage.objects for chat-images.
-- Public bucket objects are accessible via their public URL without any RLS policy.
-- A SELECT policy on storage.objects allows clients to LIST all files, which is unnecessary
-- and may expose more data than intended.
DROP POLICY IF EXISTS "anon_read_chat_images" ON storage.objects;
