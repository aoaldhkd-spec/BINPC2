-- Anonymous reports: add admin acknowledgment
ALTER TABLE anonymous_reports
  ADD COLUMN IF NOT EXISTS ack_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS ack_message TEXT;

-- Suggestions: add admin response
ALTER TABLE suggestions
  ADD COLUMN IF NOT EXISTS admin_response TEXT,
  ADD COLUMN IF NOT EXISTS admin_responded_at TIMESTAMPTZ;

-- App settings: seating lock + active tables
ALTER TABLE app_settings
  ADD COLUMN IF NOT EXISTS seating_locked BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS active_tables INTEGER[];

-- Q&A games table
CREATE TABLE IF NOT EXISTS qa_games (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question TEXT NOT NULL,
  correct_answer TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
  scope TEXT NOT NULL DEFAULT 'global',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS qa_answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id UUID REFERENCES qa_games(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  nickname TEXT,
  table_number INTEGER,
  answer TEXT NOT NULL,
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  is_correct BOOLEAN DEFAULT FALSE,
  UNIQUE(game_id, user_id)
);

ALTER TABLE qa_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE qa_answers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_qa_games" ON qa_games FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_qa_games" ON qa_games FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_qa_games" ON qa_games FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_qa_games" ON qa_games FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "select_qa_answers" ON qa_answers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_qa_answers" ON qa_answers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_qa_answers" ON qa_answers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_qa_answers" ON qa_answers FOR DELETE TO anon, authenticated USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE qa_games;
ALTER PUBLICATION supabase_realtime ADD TABLE qa_answers;
