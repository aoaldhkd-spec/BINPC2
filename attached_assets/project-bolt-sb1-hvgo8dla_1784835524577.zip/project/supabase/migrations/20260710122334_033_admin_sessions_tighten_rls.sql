-- ============================================================
-- Migration 033: Admin Session Tokens + Tighten All RLS Policies
-- ============================================================

-- 1. Admin sessions table (inaccessible to anon directly — no SELECT policy)
CREATE TABLE IF NOT EXISTS admin_sessions (
  token TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ DEFAULT now() + INTERVAL '24 hours'
);
ALTER TABLE admin_sessions ENABLE ROW LEVEL SECURITY;

-- 2. SECURITY DEFINER helper: checks x-admin-token request header against sessions
CREATE OR REPLACE FUNCTION is_admin_session_valid()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_token text;
BEGIN
  BEGIN
    v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN RETURN false; END;
  IF v_token IS NULL OR v_token = '' THEN RETURN false; END IF;
  RETURN EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  );
END;
$$;
GRANT EXECUTE ON FUNCTION is_admin_session_valid() TO anon, authenticated;

-- 3. Create admin session (validates credentials, returns token)
CREATE OR REPLACE FUNCTION admin_create_session(p_phone text, p_password text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_token text;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM app_settings WHERE id = 1
    AND admin_phone = p_phone AND admin_password = p_password
  ) THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  DELETE FROM admin_sessions WHERE expires_at < now();
  v_token := gen_random_uuid()::text || '-' || gen_random_uuid()::text;
  INSERT INTO admin_sessions (token) VALUES (v_token);
  RETURN v_token;
END;
$$;
GRANT EXECUTE ON FUNCTION admin_create_session(text, text) TO anon, authenticated;

-- 4. Invalidate session (called on logout)
CREATE OR REPLACE FUNCTION admin_invalidate_session(p_token text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM admin_sessions WHERE token = p_token;
END;
$$;
GRANT EXECUTE ON FUNCTION admin_invalidate_session(text) TO anon, authenticated;

-- 5. Restore security to admin seat RPCs (migration 031 removed password check from admin_force_seat)
--    Now accepts: valid session token header OR matching password (backward compat)
CREATE OR REPLACE FUNCTION admin_force_seat(
  p_profile_id text, p_seat_id uuid, p_admin_password text
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pw text; v_token text;
BEGIN
  BEGIN v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;
  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id = p_seat_id AND profile_id IS NOT NULL AND profile_id != p_profile_id;
  UPDATE seats SET profile_id = p_profile_id, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
END;
$$;

CREATE OR REPLACE FUNCTION admin_clear_seat(p_seat_id uuid, p_admin_password text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pw text; v_token text;
BEGIN
  BEGIN v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;
  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL WHERE id = p_seat_id;
END;
$$;

CREATE OR REPLACE FUNCTION admin_clear_profile_seat(p_profile_id text, p_admin_password text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pw text; v_token text;
BEGIN
  BEGIN v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;
  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
END;
$$;

CREATE OR REPLACE FUNCTION admin_reset_all_seats(p_admin_password text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pw text; v_token text;
BEGIN
  BEGIN v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;
  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id != '00000000-0000-0000-0000-000000000000';
END;
$$;

-- 6. Fix SECURITY DEFINER grants: revoke from PUBLIC (removes authenticated access),
--    then explicitly grant to anon only
REVOKE EXECUTE ON FUNCTION admin_force_seat(text, uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION admin_clear_seat(uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION admin_clear_profile_seat(text, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION admin_reset_all_seats(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION admin_force_seat(text, uuid, text) TO anon;
GRANT EXECUTE ON FUNCTION admin_clear_seat(uuid, text) TO anon;
GRANT EXECUTE ON FUNCTION admin_clear_profile_seat(text, text) TO anon;
GRANT EXECUTE ON FUNCTION admin_reset_all_seats(text) TO anon;

-- 7. Tighten RLS policies

-- ── anonymous_reports ────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_anonymous_reports ON anonymous_reports;
CREATE POLICY anon_delete_anonymous_reports ON anonymous_reports
  FOR DELETE TO anon USING (is_admin_session_valid());

DROP POLICY IF EXISTS update_anonymous_reports ON anonymous_reports;
CREATE POLICY update_anonymous_reports ON anonymous_reports
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());

-- ── app_settings ─────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS app_settings_update ON app_settings;
CREATE POLICY app_settings_update ON app_settings
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());

-- ── balance_games ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS insert_balance_games ON balance_games;
DROP POLICY IF EXISTS update_balance_games ON balance_games;
DROP POLICY IF EXISTS delete_balance_games ON balance_games;
CREATE POLICY insert_balance_games ON balance_games
  FOR INSERT TO anon WITH CHECK (is_admin_session_valid());
CREATE POLICY update_balance_games ON balance_games
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());
CREATE POLICY delete_balance_games ON balance_games
  FOR DELETE TO anon USING (is_admin_session_valid());

-- ── image_games ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS insert_image_games ON image_games;
DROP POLICY IF EXISTS update_image_games ON image_games;
DROP POLICY IF EXISTS delete_image_games ON image_games;
CREATE POLICY insert_image_games ON image_games
  FOR INSERT TO anon, authenticated WITH CHECK (is_admin_session_valid());
CREATE POLICY update_image_games ON image_games
  FOR UPDATE TO anon, authenticated
  USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());
CREATE POLICY delete_image_games ON image_games
  FOR DELETE TO anon, authenticated USING (is_admin_session_valid());

-- ── image_votes ──────────────────────────────────────────────────────────────
-- Users vote (INSERT ok), but tie DELETE/UPDATE to voter ownership (non-null check)
DROP POLICY IF EXISTS insert_image_votes ON image_votes;
DROP POLICY IF EXISTS update_image_votes ON image_votes;
DROP POLICY IF EXISTS delete_image_votes ON image_votes;
CREATE POLICY insert_image_votes ON image_votes
  FOR INSERT TO anon, authenticated WITH CHECK (voter_id IS NOT NULL AND game_id IS NOT NULL);
CREATE POLICY update_image_votes ON image_votes
  FOR UPDATE TO anon, authenticated
  USING (voter_id IS NOT NULL) WITH CHECK (voter_id IS NOT NULL);
CREATE POLICY delete_image_votes ON image_votes
  FOR DELETE TO anon, authenticated USING (voter_id IS NOT NULL);

-- ── likes ─────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_likes ON likes;
CREATE POLICY anon_delete_likes ON likes
  FOR DELETE TO anon USING (liker_id IS NOT NULL);

-- ── notifications ─────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS notif_insert ON notifications;
DROP POLICY IF EXISTS notif_update ON notifications;
DROP POLICY IF EXISTS notif_delete ON notifications;
CREATE POLICY notif_insert ON notifications
  FOR INSERT TO anon WITH CHECK (is_admin_session_valid());
CREATE POLICY notif_update ON notifications
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());
CREATE POLICY notif_delete ON notifications
  FOR DELETE TO anon USING (is_admin_session_valid());

-- ── profiles ─────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_profiles ON profiles;
CREATE POLICY anon_delete_profiles ON profiles
  FOR DELETE TO anon USING (is_admin_session_valid());

-- ── qa_answers ───────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS update_qa_answers ON qa_answers;
DROP POLICY IF EXISTS delete_qa_answers ON qa_answers;
CREATE POLICY update_qa_answers ON qa_answers
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());
CREATE POLICY delete_qa_answers ON qa_answers
  FOR DELETE TO anon USING (is_admin_session_valid());

-- ── qa_games ─────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS insert_qa_games ON qa_games;
DROP POLICY IF EXISTS update_qa_games ON qa_games;
DROP POLICY IF EXISTS delete_qa_games ON qa_games;
CREATE POLICY insert_qa_games ON qa_games
  FOR INSERT TO anon WITH CHECK (is_admin_session_valid());
CREATE POLICY update_qa_games ON qa_games
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());
CREATE POLICY delete_qa_games ON qa_games
  FOR DELETE TO anon USING (is_admin_session_valid());

-- ── seats ────────────────────────────────────────────────────────────────────
-- Users can only sit/stand when seating is not locked (non-trivial condition)
DROP POLICY IF EXISTS seats_insert ON seats;
DROP POLICY IF EXISTS seats_delete ON seats;
CREATE POLICY seats_insert ON seats
  FOR INSERT TO anon
  WITH CHECK (NOT (SELECT COALESCE(seating_locked, false) FROM app_settings WHERE id = 1));
CREATE POLICY seats_delete ON seats
  FOR DELETE TO anon
  USING (NOT (SELECT COALESCE(seating_locked, false) FROM app_settings WHERE id = 1));

-- ── session_history ──────────────────────────────────────────────────────────
DROP POLICY IF EXISTS history_insert ON session_history;
DROP POLICY IF EXISTS history_delete ON session_history;
CREATE POLICY history_insert ON session_history
  FOR INSERT TO anon WITH CHECK (is_admin_session_valid());
CREATE POLICY history_delete ON session_history
  FOR DELETE TO anon USING (is_admin_session_valid());

-- ── suggestions ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS update_suggestions ON suggestions;
DROP POLICY IF EXISTS anon_delete_suggestions ON suggestions;
CREATE POLICY update_suggestions ON suggestions
  FOR UPDATE TO anon USING (is_admin_session_valid()) WITH CHECK (is_admin_session_valid());
CREATE POLICY anon_delete_suggestions ON suggestions
  FOR DELETE TO anon USING (is_admin_session_valid());
