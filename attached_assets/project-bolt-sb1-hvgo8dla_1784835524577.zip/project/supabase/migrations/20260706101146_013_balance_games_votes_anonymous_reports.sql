-- 1. Balance Games (real-time voting)
CREATE TABLE IF NOT EXISTS balance_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  creator_nickname text,
  scope text DEFAULT 'global' CHECK (scope IN ('global', 'table')),
  table_number integer,
  question text NOT NULL,
  option_a text NOT NULL,
  option_b text NOT NULL,
  status text DEFAULT 'active' CHECK (status IN ('active', 'ended')),
  created_at timestamptz DEFAULT now(),
  ended_at timestamptz
);

ALTER TABLE balance_games ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_balance_games" ON balance_games FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_balance_games" ON balance_games FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_balance_games" ON balance_games FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- 2. Balance Votes
CREATE TABLE IF NOT EXISTS balance_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES balance_games(id) ON DELETE CASCADE,
  voter_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  option text NOT NULL CHECK (option IN ('a', 'b')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(game_id, voter_id)
);

ALTER TABLE balance_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_balance_votes" ON balance_votes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_balance_votes" ON balance_votes FOR INSERT TO anon, authenticated WITH CHECK (true);

-- 3. Anonymous Reports (quick event-time messages)
CREATE TABLE IF NOT EXISTS anonymous_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_number integer,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE anonymous_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_anonymous_reports" ON anonymous_reports FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_anonymous_reports" ON anonymous_reports FOR INSERT TO anon, authenticated WITH CHECK (true);

-- 4. Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE balance_games, balance_votes, anonymous_reports;
