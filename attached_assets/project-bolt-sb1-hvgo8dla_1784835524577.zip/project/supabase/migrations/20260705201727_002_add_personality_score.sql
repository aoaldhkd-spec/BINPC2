/*
# profiles 테이블에 personality_score 컬럼 추가

1. 변경 사항
- `profiles` 테이블에 `personality_score` 컬럼 추가
- integer 타입, 0~100 범위, 기본값 50
*/

ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS personality_score integer NOT NULL DEFAULT 50;

ALTER TABLE profiles 
ADD CONSTRAINT check_personality_score CHECK (personality_score >= 0 AND personality_score <= 100);