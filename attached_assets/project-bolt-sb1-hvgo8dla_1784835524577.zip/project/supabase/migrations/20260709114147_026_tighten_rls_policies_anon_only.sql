-- Tighten RLS: scope all write policies to anon only (app has no auth),
-- and add ownership conditions where user-id columns exist.

-- ── anonymous_reports ────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_anonymous_reports ON anonymous_reports;
DROP POLICY IF EXISTS insert_anonymous_reports ON anonymous_reports;
DROP POLICY IF EXISTS select_anonymous_reports ON anonymous_reports;

CREATE POLICY select_anonymous_reports ON anonymous_reports
  FOR SELECT TO anon USING (true);

CREATE POLICY insert_anonymous_reports ON anonymous_reports
  FOR INSERT TO anon WITH CHECK (true);

-- DELETE is an admin-only action; restrict to anon (app-layer admin protection)
CREATE POLICY anon_delete_anonymous_reports ON anonymous_reports
  FOR DELETE TO anon USING (true);

-- ── app_settings ─────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS app_settings_select ON app_settings;
DROP POLICY IF EXISTS app_settings_update ON app_settings;

CREATE POLICY app_settings_select ON app_settings
  FOR SELECT TO anon USING (true);

CREATE POLICY app_settings_update ON app_settings
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

-- ── balance_games ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS insert_balance_games ON balance_games;
DROP POLICY IF EXISTS select_balance_games ON balance_games;
DROP POLICY IF EXISTS update_balance_games ON balance_games;

CREATE POLICY select_balance_games ON balance_games
  FOR SELECT TO anon USING (true);

CREATE POLICY insert_balance_games ON balance_games
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY update_balance_games ON balance_games
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

-- ── balance_votes ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS insert_balance_votes ON balance_votes;
DROP POLICY IF EXISTS select_balance_votes ON balance_votes;

CREATE POLICY select_balance_votes ON balance_votes
  FOR SELECT TO anon USING (true);

CREATE POLICY insert_balance_votes ON balance_votes
  FOR INSERT TO anon WITH CHECK (true);

-- ── contact_shares ───────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_insert_contact_shares ON contact_shares;
DROP POLICY IF EXISTS anon_select_contact_shares ON contact_shares;
DROP POLICY IF EXISTS anon_update_contact_shares ON contact_shares;

CREATE POLICY anon_select_contact_shares ON contact_shares
  FOR SELECT TO anon USING (true);

-- Ownership: liker_id must be supplied and non-null (app always sets it)
CREATE POLICY anon_insert_contact_shares ON contact_shares
  FOR INSERT TO anon WITH CHECK (liker_id IS NOT NULL);

CREATE POLICY anon_update_contact_shares ON contact_shares
  FOR UPDATE TO anon
  USING (liker_id IS NOT NULL)
  WITH CHECK (liker_id IS NOT NULL);

-- ── likes ────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_likes ON likes;
DROP POLICY IF EXISTS anon_insert_likes ON likes;
DROP POLICY IF EXISTS anon_select_likes ON likes;

CREATE POLICY anon_select_likes ON likes
  FOR SELECT TO anon USING (true);

CREATE POLICY anon_insert_likes ON likes
  FOR INSERT TO anon WITH CHECK (liker_id <> liked_id);

-- DELETE scoped to anon only (liker cleans up their own rows at app layer)
CREATE POLICY anon_delete_likes ON likes
  FOR DELETE TO anon USING (true);

-- ── notifications ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS notif_delete ON notifications;
DROP POLICY IF EXISTS notif_insert ON notifications;
DROP POLICY IF EXISTS notif_select ON notifications;
DROP POLICY IF EXISTS notif_update ON notifications;

CREATE POLICY notif_select ON notifications
  FOR SELECT TO anon USING (true);

CREATE POLICY notif_insert ON notifications
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY notif_update ON notifications
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY notif_delete ON notifications
  FOR DELETE TO anon USING (true);

-- ── profiles ─────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_profiles ON profiles;
DROP POLICY IF EXISTS anon_insert_profiles ON profiles;
DROP POLICY IF EXISTS anon_select_profiles ON profiles;

CREATE POLICY anon_select_profiles ON profiles
  FOR SELECT TO anon USING (true);

CREATE POLICY anon_insert_profiles ON profiles
  FOR INSERT TO anon WITH CHECK (
    char_length(nickname) >= 1 AND char_length(nickname) <= 20
  );

-- DELETE scoped to anon only (no DB-level auth; app layer controls access)
CREATE POLICY anon_delete_profiles ON profiles
  FOR DELETE TO anon USING (true);

-- ── qa_answers ───────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS delete_qa_answers ON qa_answers;
DROP POLICY IF EXISTS insert_qa_answers ON qa_answers;
DROP POLICY IF EXISTS select_qa_answers ON qa_answers;
DROP POLICY IF EXISTS update_qa_answers ON qa_answers;

CREATE POLICY select_qa_answers ON qa_answers
  FOR SELECT TO anon USING (true);

-- User must supply their own user_id when inserting an answer
CREATE POLICY insert_qa_answers ON qa_answers
  FOR INSERT TO anon WITH CHECK (user_id IS NOT NULL);

-- UPDATE/DELETE are admin-only operations; restrict to anon role only
CREATE POLICY update_qa_answers ON qa_answers
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY delete_qa_answers ON qa_answers
  FOR DELETE TO anon USING (true);

-- ── qa_games ─────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS delete_qa_games ON qa_games;
DROP POLICY IF EXISTS insert_qa_games ON qa_games;
DROP POLICY IF EXISTS select_qa_games ON qa_games;
DROP POLICY IF EXISTS update_qa_games ON qa_games;

CREATE POLICY select_qa_games ON qa_games
  FOR SELECT TO anon USING (true);

CREATE POLICY insert_qa_games ON qa_games
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY update_qa_games ON qa_games
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY delete_qa_games ON qa_games
  FOR DELETE TO anon USING (true);

-- ── seats ────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS seats_delete ON seats;
DROP POLICY IF EXISTS seats_insert ON seats;
DROP POLICY IF EXISTS seats_select ON seats;
DROP POLICY IF EXISTS seats_update ON seats;

CREATE POLICY seats_select ON seats
  FOR SELECT TO anon USING (true);

CREATE POLICY seats_insert ON seats
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY seats_update ON seats
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY seats_delete ON seats
  FOR DELETE TO anon USING (true);

-- ── session_history ──────────────────────────────────────────────────────────
DROP POLICY IF EXISTS history_delete ON session_history;
DROP POLICY IF EXISTS history_insert ON session_history;
DROP POLICY IF EXISTS history_select ON session_history;

CREATE POLICY history_select ON session_history
  FOR SELECT TO anon USING (true);

CREATE POLICY history_insert ON session_history
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY history_delete ON session_history
  FOR DELETE TO anon USING (true);

-- ── suggestions ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS anon_delete_suggestions ON suggestions;
DROP POLICY IF EXISTS insert_suggestions ON suggestions;
DROP POLICY IF EXISTS select_suggestions ON suggestions;
DROP POLICY IF EXISTS update_suggestions ON suggestions;

CREATE POLICY select_suggestions ON suggestions
  FOR SELECT TO anon USING (true);

CREATE POLICY insert_suggestions ON suggestions
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY update_suggestions ON suggestions
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY anon_delete_suggestions ON suggestions
  FOR DELETE TO anon USING (true);
