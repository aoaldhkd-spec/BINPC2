/*
# Fix qa_answers replica identity for realtime

1. Changes
   - Set REPLICA IDENTITY FULL on qa_answers so Supabase Realtime
     can broadcast all column data on INSERT/UPDATE/DELETE events.
   - This is required for the admin dashboard to receive live answer submissions.
*/

ALTER TABLE qa_answers REPLICA IDENTITY FULL;