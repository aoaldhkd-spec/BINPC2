-- 만능 좌석 관리 모드: 두 좌석 간 인원 교체 전용 RPC.
-- admin_force_seat은 A를 B 자리로 보내고 B를 A 자리로 보내는 스왑을 지원하지만,
-- 터치 기반 UI에서 두 자리를 직접 터치하여 교체하는 흐름을 위해 전용 함수를 추가.
-- 빈 자리가 포함된 경우에도 안전하게 동작한다.

CREATE OR REPLACE FUNCTION admin_swap_seats(
  p_seat_a_id uuid,
  p_seat_b_id uuid,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_pw text;
  v_token text;
  v_profile_a text;
  v_profile_b text;
BEGIN
  IF p_seat_a_id = p_seat_b_id THEN RETURN; END IF;

  BEGIN
    v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;

  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;

  SELECT profile_id::text INTO v_profile_a FROM seats WHERE id = p_seat_a_id;
  SELECT profile_id::text INTO v_profile_b FROM seats WHERE id = p_seat_b_id;

  UPDATE seats SET profile_id = v_profile_b::uuid, status = (v_profile_b IS NOT NULL)::text::text,
                   registered_at = CASE WHEN v_profile_b IS NOT NULL THEN now() ELSE NULL END
  WHERE id = p_seat_a_id;

  UPDATE seats SET profile_id = v_profile_a::uuid, status = (v_profile_a IS NOT NULL)::text::text,
                   registered_at = CASE WHEN v_profile_a IS NOT NULL THEN now() ELSE NULL END
  WHERE id = p_seat_b_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_swap_seats(uuid, uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION admin_swap_seats(uuid, uuid, text) TO anon;