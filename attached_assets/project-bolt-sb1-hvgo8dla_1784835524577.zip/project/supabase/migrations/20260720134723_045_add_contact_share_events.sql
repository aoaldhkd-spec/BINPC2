-- Per-user contact share events (for acceptance/rejection notifications)
CREATE TABLE IF NOT EXISTS contact_share_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user_id TEXT NOT NULL,
  to_user_id TEXT NOT NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('accepted', 'rejected')),
  seen BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE contact_share_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_share_events" ON contact_share_events FOR SELECT
  TO anon, authenticated USING (true);

CREATE POLICY "insert_own_share_events" ON contact_share_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE POLICY "update_own_share_events" ON contact_share_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "delete_own_share_events" ON contact_share_events FOR DELETE
  TO anon, authenticated USING (true);

ALTER TABLE contact_share_events REPLICA IDENTITY FULL;
