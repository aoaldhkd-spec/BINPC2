-- Add tables 9 (I) and 10 (J) with 8 seats each (same as sofa tables 5-8)
INSERT INTO seats (table_number, seat_position, seat_label) VALUES
  (9,1,'9번 테이블 1번'),(9,2,'9번 테이블 2번'),(9,3,'9번 테이블 3번'),
  (9,4,'9번 테이블 4번'),(9,5,'9번 테이블 5번'),(9,6,'9번 테이블 6번'),
  (9,7,'9번 테이블 7번'),(9,8,'9번 테이블 8번'),
  (10,1,'10번 테이블 1번'),(10,2,'10번 테이블 2번'),(10,3,'10번 테이블 3번'),
  (10,4,'10번 테이블 4번'),(10,5,'10번 테이블 5번'),(10,6,'10번 테이블 6번'),
  (10,7,'10번 테이블 7번'),(10,8,'10번 테이블 8번')
ON CONFLICT DO NOTHING;

-- Also backfill tables 1-4 to have 8 seats each (currently only 5)
INSERT INTO seats (table_number, seat_position, seat_label) VALUES
  (1,6,'1번 테이블 6번'),(1,7,'1번 테이블 7번'),(1,8,'1번 테이블 8번'),
  (2,6,'2번 테이블 6번'),(2,7,'2번 테이블 7번'),(2,8,'2번 테이블 8번'),
  (3,6,'3번 테이블 6번'),(3,7,'3번 테이블 7번'),(3,8,'3번 테이블 8번'),
  (4,6,'4번 테이블 6번'),(4,7,'4번 테이블 7번'),(4,8,'4번 테이블 8번')
ON CONFLICT DO NOTHING;
