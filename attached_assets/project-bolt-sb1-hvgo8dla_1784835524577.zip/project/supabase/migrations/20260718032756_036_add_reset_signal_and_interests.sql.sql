-- Add reset_signal timestamp to app_settings so admin full-reset can broadcast to all clients
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS reset_signal timestamptz DEFAULT now();

-- Add interests column to profiles (stores comma-joined interest tags for nickname generation)
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS interests text;
