/*
# Add table_labels column to app_settings

1. Purpose
- Allow the admin to relabel each physical table with a custom display number on the seating map.
- Previously table display labels (1..12 / A..L) were hardcoded in the frontend.
- Now the admin can set a JSON map { "1": "1", "2": "2", ... } so each table shows the number the admin chooses at each event.

2. Schema changes
- ALTER TABLE app_settings ADD COLUMN table_labels jsonb DEFAULT NULL.
  - Keys are physical table numbers as strings ("1".."12").
  - Values are the display labels (strings, e.g. "1", "2", "101").
  - NULL means "use the physical table number as the label" (backward compatible default).

3. Security
- No new tables. RLS on app_settings already exists and is unchanged.
- No policy changes.
- Column is admin-managed config; existing app_settings read/write policies already cover it.

4. Backward compatibility
- Default NULL → frontend falls back to the physical table_number, so existing events are unaffected.
- No destructive operations; no data loss.
*/

ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS table_labels jsonb DEFAULT NULL;
