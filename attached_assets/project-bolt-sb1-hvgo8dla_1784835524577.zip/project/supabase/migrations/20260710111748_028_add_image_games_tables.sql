/*
# Add image_games and image_votes tables

1. New Tables
  - `image_games`: Admin-created image games with topic, penalty, scope, table targeting
    - id (uuid, PK)
    - question (text, the topic/theme)
    - penalty (text, nullable, what the most-voted person gets)
    - scope (text, 'global' or 'table')
    - table_number (integer, nullable, for table-scoped games)
    - status ('active' or 'ended')
    - created_at, ended_at timestamps
  - `image_votes`: User votes for a person in an image game
    - id (uuid, PK)
    - game_id (FK → image_games)
    - voter_id (text, profile id of voter)
    - voted_profile_id (text, profile id of who was voted for)
    - created_at timestamp
    - UNIQUE(game_id, voter_id) — one vote per person per game

2. Security
  - RLS enabled on both tables
  - anon + authenticated can SELECT, INSERT, UPDATE, DELETE
  - Public/shared session data (no user-auth app)

3. Realtime
  - Both tables added to supabase_realtime publication
*/

CREATE TABLE IF NOT EXISTS image_games (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question TEXT NOT NULL,
  penalty TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
  scope TEXT NOT NULL DEFAULT 'global',
  table_number INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS image_votes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id UUID REFERENCES image_games(id) ON DELETE CASCADE,
  voter_id TEXT NOT NULL,
  voted_profile_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(game_id, voter_id)
);

ALTER TABLE image_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE image_votes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_image_games" ON image_games;
CREATE POLICY "select_image_games" ON image_games FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_image_games" ON image_games;
CREATE POLICY "insert_image_games" ON image_games FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_image_games" ON image_games;
CREATE POLICY "update_image_games" ON image_games FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_image_games" ON image_games;
CREATE POLICY "delete_image_games" ON image_games FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "select_image_votes" ON image_votes;
CREATE POLICY "select_image_votes" ON image_votes FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_image_votes" ON image_votes;
CREATE POLICY "insert_image_votes" ON image_votes FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_image_votes" ON image_votes;
CREATE POLICY "update_image_votes" ON image_votes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_image_votes" ON image_votes;
CREATE POLICY "delete_image_votes" ON image_votes FOR DELETE TO anon, authenticated USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE image_games;
ALTER PUBLICATION supabase_realtime ADD TABLE image_votes;