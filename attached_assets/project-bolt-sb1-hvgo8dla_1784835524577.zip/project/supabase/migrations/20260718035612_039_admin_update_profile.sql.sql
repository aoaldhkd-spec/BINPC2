-- 만능 좌석 관리 모드 '변경(Edit)' 기능용 프로필 수정 RPC.
-- profiles 테이블에 UPDATE RLS 정책이 없어 일반 클라이언트 update가 차단되므로,
-- admin_force_seat 등과 동일한 인증 패턴(관리자 비밀번호 또는 세션 토큰)으로
-- SECURITY DEFINER 함수를 통해 안전하게 프로필을 수정한다.

CREATE OR REPLACE FUNCTION admin_update_profile(
  p_profile_id text,
  p_nickname text,
  p_mbti text,
  p_bio text,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_pw text;
  v_token text;
BEGIN
  BEGIN
    v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;

  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;

  UPDATE profiles
    SET nickname = COALESCE(NULLIF(TRIM(p_nickname), ''), nickname),
        mbti = CASE WHEN p_mbti IS NULL OR p_mbti = '' THEN NULL ELSE UPPER(p_mbti) END,
        bio = CASE WHEN p_bio IS NULL OR p_bio = '' THEN NULL ELSE p_bio END
    WHERE id = p_profile_id::uuid;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_update_profile(text, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION admin_update_profile(text, text, text, text, text) TO anon;