ALTER TABLE profiles DROP CONSTRAINT IF EXISTS check_personality_score;
ALTER TABLE profiles ADD CONSTRAINT check_personality_score CHECK (personality_score >= -10 AND personality_score <= 100);
ALTER TABLE profiles ALTER COLUMN personality_score SET DEFAULT 50;