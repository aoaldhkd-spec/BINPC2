-- Remove -10 minimum, change to 0
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS check_personality_score;
ALTER TABLE profiles ADD CONSTRAINT check_personality_score CHECK (personality_score >= 0 AND personality_score <= 100);

-- Add dom_sub_score column
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS dom_sub_score integer NOT NULL DEFAULT 50;
ALTER TABLE profiles ADD CONSTRAINT check_dom_sub_score CHECK (dom_sub_score >= 0 AND dom_sub_score <= 100);