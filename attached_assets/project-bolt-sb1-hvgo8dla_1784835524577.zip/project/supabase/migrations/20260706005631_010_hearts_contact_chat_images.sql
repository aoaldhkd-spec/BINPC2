/*
# 하트 연락처 공유 + 채팅 이미지 업로드 지원

1. 새 테이블
- `contact_shares` - 하트를 받은 사람이 보낸 사람에게 연락처를 공유하는 테이블
  - liker_id: 하트를 보낸 사람 (받는 사람)
  - liked_id: 하트를 받은 사람 (공유하는 사람)
  - kakao: 카카오톡 ID (nullable)
  - instagram: 인스타그램 ID (nullable)
  - phone: 전화번호 (nullable)
  - (liker_id, liked_id) 유니크 제약 (한 쌍당 1회만 공유)

2. 기존 테이블 변경
- `messages` 테이블에 `image_url` TEXT 컬럼 추가 (채팅 이미지 URL)

3. Storage
- `chat-images` 버킷 생성 (공개, 채팅 이미지 저장)
- 버킷 READ/WRITE 정책 추가

4. Security
- contact_shares: RLS 활성화, anon+authenticated SELECT/INSERT/UPDATE 허용
*/

-- contact_shares 테이블
CREATE TABLE IF NOT EXISTS contact_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  liker_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  liked_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  kakao text,
  instagram text,
  phone text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(liker_id, liked_id)
);

ALTER TABLE contact_shares ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_contact_shares" ON contact_shares;
CREATE POLICY "anon_select_contact_shares" ON contact_shares
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_contact_shares" ON contact_shares;
CREATE POLICY "anon_insert_contact_shares" ON contact_shares
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_contact_shares" ON contact_shares;
CREATE POLICY "anon_update_contact_shares" ON contact_shares
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- messages 에 image_url 컬럼 추가
ALTER TABLE messages ADD COLUMN IF NOT EXISTS image_url text;

-- Storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "anon_insert_chat_images" ON storage.objects;
CREATE POLICY "anon_insert_chat_images" ON storage.objects
  FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'chat-images');

DROP POLICY IF EXISTS "anon_read_chat_images" ON storage.objects;
CREATE POLICY "anon_read_chat_images" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'chat-images');