-- Add pin_code to profiles (unique 4-digit code per participant)
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS pin_code TEXT;

-- Function to generate a unique 4-digit PIN
CREATE OR REPLACE FUNCTION generate_unique_pin() RETURNS TRIGGER AS $$
DECLARE
  new_pin TEXT;
  attempts INT := 0;
BEGIN
  IF NEW.pin_code IS NOT NULL THEN
    RETURN NEW;
  END IF;
  LOOP
    new_pin := LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
    IF NOT EXISTS (SELECT 1 FROM profiles WHERE pin_code = new_pin) THEN
      NEW.pin_code := new_pin;
      RETURN NEW;
    END IF;
    attempts := attempts + 1;
    IF attempts > 5000 THEN
      RAISE EXCEPTION 'Could not generate a unique 4-digit PIN after 5000 attempts';
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_set_pin_code ON profiles;
CREATE TRIGGER trg_set_pin_code
  BEFORE INSERT ON profiles
  FOR EACH ROW EXECUTE FUNCTION generate_unique_pin();

-- Back-fill existing profiles that have no pin_code
DO $$
DECLARE
  r RECORD;
  new_pin TEXT;
  attempts INT;
BEGIN
  FOR r IN SELECT id FROM profiles WHERE pin_code IS NULL LOOP
    attempts := 0;
    LOOP
      new_pin := LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
      IF NOT EXISTS (SELECT 1 FROM profiles WHERE pin_code = new_pin) THEN
        UPDATE profiles SET pin_code = new_pin WHERE id = r.id;
        EXIT;
      END IF;
      attempts := attempts + 1;
      IF attempts > 5000 THEN
        RAISE EXCEPTION 'PIN generation failed for id %', r.id;
      END IF;
    END LOOP;
  END LOOP;
END;
$$;

-- Add unique index
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_pin_code ON profiles(pin_code);
