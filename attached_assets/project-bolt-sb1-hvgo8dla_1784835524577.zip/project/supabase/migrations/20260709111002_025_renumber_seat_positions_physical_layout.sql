-- Renumber seat positions to match physical table layout.
-- Rule: sofa tables (1-4,9-12): 맞은편1(4)→8, 맞은편2(5)→7, 상/하단1(7)→4, 상/하단2(8)→5
-- Rule: row1 tables (5-8): 좌측1(3)→1, 좌측2(4)→2, 좌측3(5)→3, 하단1(1)→4, 하단2(2)→5

-- Step 1: bump affected positions to temp values to avoid unique constraint conflicts
UPDATE seats
SET seat_position = seat_position + 100
WHERE table_number IN (1,2,3,4,9,10,11,12)
  AND seat_position IN (4,5,7,8);

UPDATE seats
SET seat_position = seat_position + 100
WHERE table_number IN (5,6,7,8)
  AND seat_position IN (1,2,3,4,5);

-- Step 2: final values for sofa tables
UPDATE seats SET seat_position = 8 WHERE table_number IN (1,2,3,4,9,10,11,12) AND seat_position = 104;
UPDATE seats SET seat_position = 7 WHERE table_number IN (1,2,3,4,9,10,11,12) AND seat_position = 105;
UPDATE seats SET seat_position = 4 WHERE table_number IN (1,2,3,4,9,10,11,12) AND seat_position = 107;
UPDATE seats SET seat_position = 5 WHERE table_number IN (1,2,3,4,9,10,11,12) AND seat_position = 108;

-- Step 3: final values for row1 tables
UPDATE seats SET seat_position = 1 WHERE table_number IN (5,6,7,8) AND seat_position = 103;
UPDATE seats SET seat_position = 2 WHERE table_number IN (5,6,7,8) AND seat_position = 104;
UPDATE seats SET seat_position = 3 WHERE table_number IN (5,6,7,8) AND seat_position = 105;
UPDATE seats SET seat_position = 4 WHERE table_number IN (5,6,7,8) AND seat_position = 101;
UPDATE seats SET seat_position = 5 WHERE table_number IN (5,6,7,8) AND seat_position = 102;

-- Step 4: update seat_label to simple "X테이블 N번" format so label = position
UPDATE seats
SET seat_label = chr(64 + table_number) || '테이블 ' || seat_position || '번';
