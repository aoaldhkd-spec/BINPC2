/*
# Add interests, notification, group chat, and full-reset RPC

## Changes
1. `profiles` — add `interests` text[] column (for the 5-input nickname setup)
2. `app_settings` — add `notification` text column (admin broadcast to users)
3. New table `group_chat_messages` — real-time group chat (all users in one room)
4. New RPC `admin_full_reset` — full event-end reset: clears all user data and increments reset_version
5. New RPC `admin_assign_seat` — admin-only seat assignment with password protection

## Notes
- All additions are non-destructive (IF NOT EXISTS).
- Group chat is separate from the existing 1:1 `chats`/`messages` system.
*/

-- ─── profiles: add interests ──────────────────────────────────────────────────
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS interests text[] NOT NULL DEFAULT '{}';

-- ─── app_settings: add notification ───────────────────────────────────────────
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS notification text;

-- ─── group_chat_messages ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS group_chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  nickname text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE group_chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_group_chat" ON group_chat_messages;
CREATE POLICY "anon_select_group_chat" ON group_chat_messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_group_chat" ON group_chat_messages;
CREATE POLICY "anon_insert_group_chat" ON group_chat_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_group_chat" ON group_chat_messages;
CREATE POLICY "anon_delete_group_chat" ON group_chat_messages FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_group_chat_created_at ON group_chat_messages(created_at);

-- ─── RPC: admin_full_reset ────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION admin_full_reset(p_admin_password text)
RETURNS void AS $$
BEGIN
  IF p_admin_password = (SELECT admin_password FROM app_settings WHERE id = 1) THEN
    DELETE FROM likes;
    DELETE FROM group_chat_messages;
    DELETE FROM messages;
    DELETE FROM chats;
    DELETE FROM suggestions;
    DELETE FROM anonymous_reports;
    DELETE FROM balance_votes;
    DELETE FROM balance_games;
    DELETE FROM image_votes;
    DELETE FROM image_games;
    DELETE FROM qa_answers;
    DELETE FROM qa_games;
    DELETE FROM contact_shares;
    DELETE FROM profiles;
    UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL;
    UPDATE app_settings
      SET reset_version = reset_version + 1,
          session_active = false,
          timer_end_at = NULL,
          timer_label = NULL,
          game_state = '{"active": false}'::jsonb,
          notification = NULL,
          updated_at = now()
      WHERE id = 1;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── RPC: admin_assign_seat ───────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION admin_assign_seat(p_profile_id uuid, p_seat_id uuid, p_admin_password text)
RETURNS void AS $$
BEGIN
  IF p_admin_password = (SELECT admin_password FROM app_settings WHERE id = 1) THEN
    UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
    UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id = p_seat_id;
    UPDATE seats SET profile_id = p_profile_id, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
