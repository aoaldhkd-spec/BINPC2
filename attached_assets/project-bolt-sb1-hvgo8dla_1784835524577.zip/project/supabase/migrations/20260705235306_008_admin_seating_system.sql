-- app_settings (singleton row controls session state + admin credentials)
CREATE TABLE IF NOT EXISTS app_settings (
  id integer PRIMARY KEY DEFAULT 1,
  session_active boolean NOT NULL DEFAULT false,
  admin_phone text NOT NULL DEFAULT '010-0000-0000',
  admin_password text NOT NULL DEFAULT 'admin1234',
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT app_settings_singleton CHECK (id = 1)
);

INSERT INTO app_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- seats table (pre-populated with 4 tables x 5 seats)
CREATE TABLE IF NOT EXISTS seats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_number integer NOT NULL,
  seat_position integer NOT NULL,
  seat_label text NOT NULL,
  profile_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'empty' CHECK (status IN ('empty', 'occupied')),
  registered_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(table_number, seat_position)
);

INSERT INTO seats (table_number, seat_position, seat_label) VALUES
  (1,1,'1번 테이블 1번'),(1,2,'1번 테이블 2번'),(1,3,'1번 테이블 3번'),(1,4,'1번 테이블 4번'),(1,5,'1번 테이블 5번'),
  (2,1,'2번 테이블 1번'),(2,2,'2번 테이블 2번'),(2,3,'2번 테이블 3번'),(2,4,'2번 테이블 4번'),(2,5,'2번 테이블 5번'),
  (3,1,'3번 테이블 1번'),(3,2,'3번 테이블 2번'),(3,3,'3번 테이블 3번'),(3,4,'3번 테이블 4번'),(3,5,'3번 테이블 5번'),
  (4,1,'4번 테이블 1번'),(4,2,'4번 테이블 2번'),(4,3,'4번 테이블 3번'),(4,4,'4번 테이블 4번'),(4,5,'4번 테이블 5번')
ON CONFLICT DO NOTHING;

-- session_history table (backup when admin ends session)
CREATE TABLE IF NOT EXISTS session_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ended_at timestamptz NOT NULL DEFAULT now(),
  seats_snapshot jsonb NOT NULL
);

-- Enable RLS
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE seats ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_history ENABLE ROW LEVEL SECURITY;

-- app_settings: readable by all (session status), writable by all (admin controls via app)
CREATE POLICY "app_settings_select" ON app_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "app_settings_update" ON app_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- seats: full CRUD for anon
CREATE POLICY "seats_select" ON seats FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "seats_insert" ON seats FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "seats_update" ON seats FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "seats_delete" ON seats FOR DELETE TO anon, authenticated USING (true);

-- session_history: read + insert
CREATE POLICY "history_select" ON session_history FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "history_insert" ON session_history FOR INSERT TO anon, authenticated WITH CHECK (true);
