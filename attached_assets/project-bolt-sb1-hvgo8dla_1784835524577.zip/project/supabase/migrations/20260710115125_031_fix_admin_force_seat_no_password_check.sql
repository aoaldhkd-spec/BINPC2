CREATE OR REPLACE FUNCTION admin_force_seat(p_profile_id text, p_seat_id uuid, p_admin_password text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  -- Remove target user from their current seat (if any)
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
  -- Displace whoever is currently sitting in the target seat (if different person)
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id = p_seat_id AND profile_id IS NOT NULL AND profile_id != p_profile_id;
  -- Place target user in the seat
  UPDATE seats SET profile_id = p_profile_id, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
END;
$$;