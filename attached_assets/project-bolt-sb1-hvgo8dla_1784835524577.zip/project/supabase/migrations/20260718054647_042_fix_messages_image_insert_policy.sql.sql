-- Fix: image-only messages (content='') were rejected by the INSERT policy
-- because it required char_length(content) >= 1. Allow empty content when
-- an image_url is present.
DROP POLICY IF EXISTS "anon_insert_messages" ON public.messages;
CREATE POLICY "anon_insert_messages" ON public.messages
  FOR INSERT TO anon, authenticated
  WITH CHECK (char_length(content) >= 1 OR image_url IS NOT NULL);
