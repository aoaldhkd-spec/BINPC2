/*
# Add 'green' compliment heart type

1. Purpose
- Add a fourth heart type 'green' (칭찬 하트 / compliment heart).
- Meaning: "잘생겼어요, 분위기를 좋게해줘요, 이 사람을 칭찬합니다" — a compliment/praise heart.
- Same functionality as other hearts (send, receive, realtime notifications, quota of 2 per type) EXCEPT no contact sharing.
- Recipient can acknowledge the compliment, but no phone/kakao/instagram exchange occurs.

2. Schema changes
- Drop the existing CHECK constraint on likes.heart_type and recreate with 'green' included.
- No new columns, no new tables, no data loss.

3. Security
- No RLS changes. likes table policies unchanged.

4. Backward compatibility
- Existing rows unaffected (all default to 'red').
- New inserts can now use 'green'.
*/

DO $$
DECLARE constr_name text;
BEGIN
  SELECT conname INTO constr_name
  FROM pg_constraint
  WHERE conrelid = 'likes'::regclass
  AND contype = 'c'
  AND pg_get_constraintdef(oid) LIKE '%heart_type%';
  IF constr_name IS NOT NULL THEN
    EXECUTE format('ALTER TABLE likes DROP CONSTRAINT %I', constr_name);
  END IF;
END $$;
ALTER TABLE likes ADD CONSTRAINT likes_heart_type_check CHECK (heart_type IN ('red','blue','pink','green'));