-- Fix admin_force_seat: swap occupants instead of displacing them.
-- If target seat is empty: simply move person A there.
-- If target seat is occupied by person B AND person A has a seat: swap A ↔ B.
-- If target seat is occupied by person B AND person A has NO seat: displace B (no seat to swap).

CREATE OR REPLACE FUNCTION admin_force_seat(
  p_profile_id text,
  p_seat_id uuid,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_pw text;
  v_token text;
  v_seat_a_id uuid;   -- person A's current seat (may be NULL)
  v_profile_b text;   -- profile_id of person currently in target seat (may be NULL)
BEGIN
  -- Auth: accept valid session token header OR matching admin password
  BEGIN
    v_token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN v_token := NULL; END;

  IF v_token IS NULL OR NOT EXISTS (
    SELECT 1 FROM admin_sessions WHERE token = v_token AND expires_at > now()
  ) THEN
    SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
    IF v_pw IS DISTINCT FROM p_admin_password THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  END IF;

  -- No-op if person A is already in the target seat
  IF EXISTS (SELECT 1 FROM seats WHERE id = p_seat_id AND profile_id = p_profile_id::uuid) THEN
    RETURN;
  END IF;

  -- Find person A's current seat
  SELECT id INTO v_seat_a_id
    FROM seats WHERE profile_id = p_profile_id::uuid LIMIT 1;

  -- Find who is currently in the target seat (person B)
  SELECT profile_id::text INTO v_profile_b
    FROM seats WHERE id = p_seat_id AND profile_id IS NOT NULL;

  IF v_profile_b IS NOT NULL THEN
    -- Target seat is occupied
    IF v_seat_a_id IS NOT NULL THEN
      -- Person A has a seat → swap: send person B to person A's old seat
      UPDATE seats
        SET profile_id = v_profile_b::uuid, status = 'occupied', registered_at = now()
        WHERE id = v_seat_a_id;
    ELSE
      -- Person A has no seat → displace person B (seat becomes empty before person A takes it)
      UPDATE seats
        SET profile_id = NULL, status = 'empty', registered_at = NULL
        WHERE id = p_seat_id;
    END IF;
  ELSE
    -- Target seat is empty → just vacate person A's old seat
    IF v_seat_a_id IS NOT NULL THEN
      UPDATE seats
        SET profile_id = NULL, status = 'empty', registered_at = NULL
        WHERE id = v_seat_a_id;
    END IF;
  END IF;

  -- Place person A in the target seat
  UPDATE seats
    SET profile_id = p_profile_id::uuid, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
END;
$$;

GRANT EXECUTE ON FUNCTION admin_force_seat(text, uuid, text) TO anon;
