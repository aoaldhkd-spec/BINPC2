-- 1. seats_update 정책에 seating_locked 체크 추가
DROP POLICY IF EXISTS "seats_update" ON seats;
CREATE POLICY "seats_update" ON seats FOR UPDATE
  TO anon, authenticated
  USING (
    NOT (SELECT seating_locked FROM app_settings WHERE id = 1)
  )
  WITH CHECK (
    NOT (SELECT seating_locked FROM app_settings WHERE id = 1)
  );

-- 2. 관리자용 SECURITY DEFINER 함수 (RLS 우회, admin_password 검증)

-- 단일 자리 강제 배정 (handleForceSeat)
CREATE OR REPLACE FUNCTION admin_force_seat(
  p_profile_id text,
  p_seat_id uuid,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_pw text;
BEGIN
  SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
  IF v_pw IS DISTINCT FROM p_admin_password THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
  UPDATE seats SET profile_id = p_profile_id, status = 'occupied', registered_at = now()
    WHERE id = p_seat_id;
END;
$$;

-- 단일 자리 비우기 (handleClearSeat)
CREATE OR REPLACE FUNCTION admin_clear_seat(
  p_seat_id uuid,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_pw text;
BEGIN
  SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
  IF v_pw IS DISTINCT FROM p_admin_password THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id = p_seat_id;
END;
$$;

-- 프로필 삭제 시 자리 비우기 (handleDeleteProfile)
CREATE OR REPLACE FUNCTION admin_clear_profile_seat(
  p_profile_id text,
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_pw text;
BEGIN
  SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
  IF v_pw IS DISTINCT FROM p_admin_password THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE profile_id = p_profile_id;
END;
$$;

-- 모든 자리 초기화 (세션 종료/리셋)
CREATE OR REPLACE FUNCTION admin_reset_all_seats(
  p_admin_password text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_pw text;
BEGIN
  SELECT admin_password INTO v_pw FROM app_settings WHERE id = 1;
  IF v_pw IS DISTINCT FROM p_admin_password THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE seats SET profile_id = NULL, status = 'empty', registered_at = NULL
    WHERE id != '00000000-0000-0000-0000-000000000000';
END;
$$;

-- anon 역할이 함수 호출 가능하도록 권한 부여
GRANT EXECUTE ON FUNCTION admin_force_seat(text, uuid, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION admin_clear_seat(uuid, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION admin_clear_profile_seat(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION admin_reset_all_seats(text) TO anon, authenticated;
