export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          nickname: string;
          bio: string | null;
          photo_url: string;
          personality_score: number;
          dom_sub_score: number | null;
          mbti: string | null;
          birth_year: number | null;
          location: string | null;
          interests: string | null;
          contact_private: boolean;
          kakao_id: string | null;
          instagram_id: string | null;
          phone_number: string | null;
          pin_code: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          nickname: string;
          bio?: string | null;
          photo_url?: string;
          personality_score?: number;
          dom_sub_score?: number | null;
          mbti?: string | null;
          birth_year?: number | null;
          location?: string | null;
          interests?: string | null;
          contact_private?: boolean;
          kakao_id?: string | null;
          instagram_id?: string | null;
          phone_number?: string | null;
          pin_code?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          nickname?: string;
          bio?: string | null;
          photo_url?: string;
          personality_score?: number;
          dom_sub_score?: number | null;
          mbti?: string | null;
          birth_year?: number | null;
          location?: string | null;
          interests?: string | null;
          contact_private?: boolean;
          kakao_id?: string | null;
          instagram_id?: string | null;
          phone_number?: string | null;
          pin_code?: string | null;
          created_at?: string;
        };
      };
      likes: {
        Row: {
          id: string;
          liker_id: string;
          liked_id: string;
          status: 'pending' | 'accepted' | 'rejected';
          heart_type: 'red' | 'blue' | 'pink' | 'green';
          created_at: string;
        };
        Insert: {
          id?: string;
          liker_id: string;
          liked_id: string;
          status?: 'pending' | 'accepted' | 'rejected';
          heart_type?: 'red' | 'blue' | 'pink' | 'green';
          created_at?: string;
        };
        Update: {
          id?: string;
          liker_id?: string;
          liked_id?: string;
          status?: 'pending' | 'accepted' | 'rejected';
          heart_type?: 'red' | 'blue' | 'pink' | 'green';
          created_at?: string;
        };
      };
      suggestions: {
        Row: {
          id: string;
          profile_id: string | null;
          nickname: string | null;
          content: string;
          status: 'pending' | 'accepted' | 'rejected';
          admin_reason: string | null;
          admin_response: string | null;
          admin_responded_at: string | null;
          contact_info: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          profile_id?: string | null;
          nickname?: string | null;
          content: string;
          status?: 'pending' | 'accepted' | 'rejected';
          admin_reason?: string | null;
          admin_response?: string | null;
          admin_responded_at?: string | null;
          contact_info?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          profile_id?: string | null;
          nickname?: string | null;
          content?: string;
          status?: 'pending' | 'accepted' | 'rejected';
          admin_reason?: string | null;
          admin_response?: string | null;
          admin_responded_at?: string | null;
          contact_info?: string | null;
          created_at?: string;
        };
      };
      chats: {
        Row: {
          id: string;
          user1_id: string;
          user2_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user1_id: string;
          user2_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user1_id?: string;
          user2_id?: string;
          created_at?: string;
        };
      };
      messages: {
        Row: {
          id: string;
          chat_id: string;
          sender_id: string;
          content: string;
          image_url: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          chat_id: string;
          sender_id: string;
          content: string;
          image_url?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          chat_id?: string;
          sender_id?: string;
          content?: string;
          image_url?: string | null;
          created_at?: string;
        };
      };
      contact_shares: {
        Row: {
          id: string;
          liker_id: string;
          liked_id: string;
          kakao: string | null;
          instagram: string | null;
          phone: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          liker_id: string;
          liked_id: string;
          kakao?: string | null;
          instagram?: string | null;
          phone?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          liker_id?: string;
          liked_id?: string;
          kakao?: string | null;
          instagram?: string | null;
          phone?: string | null;
          created_at?: string;
        };
      };
      app_settings: {
        Row: {
          id: number;
          session_active: boolean;
          admin_phone: string;
          admin_password: string;
          updated_at: string;
          timer_end_at: string | null;
          timer_label: string | null;
          seating_locked: boolean | null;
          active_tables: number[] | null;
          reset_signal: string | null;
          table_labels: Record<string, string> | null;
        };
        Insert: {
          id?: number;
          session_active?: boolean;
          admin_phone?: string;
          admin_password?: string;
          updated_at?: string;
          timer_end_at?: string | null;
          timer_label?: string | null;
          seating_locked?: boolean | null;
          active_tables?: number[] | null;
          reset_signal?: string | null;
          table_labels?: Record<string, string> | null;
        };
        Update: {
          id?: number;
          session_active?: boolean;
          admin_phone?: string;
          admin_password?: string;
          updated_at?: string;
          timer_end_at?: string | null;
          timer_label?: string | null;
          seating_locked?: boolean | null;
          active_tables?: number[] | null;
          reset_signal?: string | null;
          table_labels?: Record<string, string> | null;
        };
      };
      seats: {
        Row: {
          id: string;
          table_number: number;
          seat_position: number;
          seat_label: string;
          profile_id: string | null;
          status: 'empty' | 'occupied';
          registered_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          table_number: number;
          seat_position: number;
          seat_label: string;
          profile_id?: string | null;
          status?: 'empty' | 'occupied';
          registered_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          table_number?: number;
          seat_position?: number;
          seat_label?: string;
          profile_id?: string | null;
          status?: 'empty' | 'occupied';
          registered_at?: string | null;
          created_at?: string;
        };
      };
      session_history: {
        Row: {
          id: string;
          ended_at: string;
          seats_snapshot: Json;
        };
        Insert: {
          id?: string;
          ended_at?: string;
          seats_snapshot: Json;
        };
        Update: {
          id?: string;
          ended_at?: string;
          seats_snapshot?: Json;
        };
      };
      balance_games: {
        Row: {
          id: string; creator_id: string | null; creator_nickname: string | null;
          scope: 'global' | 'table'; table_number: number | null;
          question: string; option_a: string; option_b: string;
          status: 'active' | 'ended'; created_at: string; ended_at: string | null;
        };
        Insert: {
          id?: string; creator_id?: string | null; creator_nickname?: string | null;
          scope?: 'global' | 'table'; table_number?: number | null;
          question: string; option_a: string; option_b: string;
          status?: 'active' | 'ended'; created_at?: string; ended_at?: string | null;
        };
        Update: {
          id?: string; creator_id?: string | null; creator_nickname?: string | null;
          scope?: 'global' | 'table'; table_number?: number | null;
          question?: string; option_a?: string; option_b?: string;
          status?: 'active' | 'ended'; created_at?: string; ended_at?: string | null;
        };
      };
      balance_votes: {
        Row: { id: string; game_id: string; voter_id: string; option: 'a' | 'b'; created_at: string; };
        Insert: { id?: string; game_id: string; voter_id: string; option: 'a' | 'b'; created_at?: string; };
        Update: { id?: string; game_id?: string; voter_id?: string; option?: 'a' | 'b'; created_at?: string; };
      };
      anonymous_reports: {
        Row: { id: string; table_number: number | null; content: string; created_at: string; ack_at: string | null; ack_message: string | null; };
        Insert: { id?: string; table_number?: number | null; content: string; created_at?: string; ack_at?: string | null; ack_message?: string | null; };
        Update: { id?: string; table_number?: number | null; content?: string; created_at?: string; ack_at?: string | null; ack_message?: string | null; };
      };
      qa_games: {
        Row: { id: string; question: string; correct_answer: string | null; status: 'active' | 'ended'; scope: string; created_at: string; ended_at: string | null; };
        Insert: { id?: string; question: string; correct_answer?: string | null; status?: 'active' | 'ended'; scope?: string; created_at?: string; ended_at?: string | null; };
        Update: { id?: string; question?: string; correct_answer?: string | null; status?: 'active' | 'ended'; scope?: string; created_at?: string; ended_at?: string | null; };
      };
      qa_answers: {
        Row: { id: string; game_id: string; user_id: string; nickname: string | null; table_number: number | null; answer: string; submitted_at: string; is_correct: boolean; };
        Insert: { id?: string; game_id: string; user_id: string; nickname?: string | null; table_number?: number | null; answer: string; submitted_at?: string; is_correct?: boolean; };
        Update: { id?: string; game_id?: string; user_id?: string; nickname?: string | null; table_number?: number | null; answer?: string; submitted_at?: string; is_correct?: boolean; };
      };
      image_games: {
        Row: { id: string; question: string; penalty: string | null; status: 'active' | 'ended'; scope: string; table_number: number | null; created_at: string; ended_at: string | null; };
        Insert: { id?: string; question: string; penalty?: string | null; status?: 'active' | 'ended'; scope?: string; table_number?: number | null; created_at?: string; ended_at?: string | null; };
        Update: { id?: string; question?: string; penalty?: string | null; status?: 'active' | 'ended'; scope?: string; table_number?: number | null; created_at?: string; ended_at?: string | null; };
      };
      image_votes: {
        Row: { id: string; game_id: string; voter_id: string; voted_profile_id: string; created_at: string; };
        Insert: { id?: string; game_id: string; voter_id: string; voted_profile_id: string; created_at?: string; };
        Update: { id?: string; game_id?: string; voter_id?: string; voted_profile_id?: string; created_at?: string; };
      };
    };
  };
}
