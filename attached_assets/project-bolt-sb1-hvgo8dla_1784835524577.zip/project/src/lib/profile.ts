export function getPositionLabel(score: number): string {
  if (score < 0) return '비선호';
  if (score <= 0) return '개바텀';
  if (score <= 24) return '바텀';
  if (score <= 49) return '올텀';
  if (score === 50) return '올';
  if (score <= 64) return '탑에 가까운 올';
  if (score <= 89) return '올탑';
  if (score <= 98) return '탑';
  return '퓨어탑';
}

export function getPositionBg(score: number): string {
  if (score < 0) return '#6b7280';
  if (score <= 0) return '#15803d';
  if (score <= 24) return '#22c55e';
  if (score <= 49) return '#84cc16';
  if (score <= 55) return '#eab308';
  if (score <= 75) return '#f59e0b';
  if (score <= 89) return '#3b82f6';
  if (score <= 98) return '#2563eb';
  return '#1d4ed8';
}

export function getDomSubLabel(score: number | null): string {
  if (score === null) return '일반/보통';
  if (score <= 10) return '완전 섭';
  if (score <= 30) return '섭';
  if (score <= 49) return '섭에 가까운 스위치';
  if (score <= 60) return '스위치';
  if (score <= 69) return '돔에 가까운 스위치';
  if (score <= 89) return '돔';
  return '완전 돔';
}

export function getDomSubBg(score: number | null): string {
  if (score === null) return '#6b7280';
  if (score <= 10) return '#ec4899';
  if (score <= 30) return '#f472b6';
  if (score <= 49) return '#fb923c';
  if (score <= 60) return '#eab308';
  if (score <= 69) return '#60a5fa';
  if (score <= 89) return '#1d4ed8';
  return '#1e3a8a';
}
