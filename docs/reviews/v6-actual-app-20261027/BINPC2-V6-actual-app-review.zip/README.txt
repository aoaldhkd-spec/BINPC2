BINPC2 V6 실제 앱 검토·Cursor 인계 자료 — 2026-10-27 한국 시간

독립 HTML 체험판이 아닙니다. 실제 React+Express+격리 PostgreSQL 화면과 영상입니다.
docs/reviews/v6-actual-app-20261027/videos 의 MP4와 docs/reviews/v6-actual-app-20261027/screenshots 의 PNG를 Chrome에서 여세요.
앱 직접 클릭은 제공되지 않습니다. 보안 외부 프리뷰 URL 발급 기능이 없습니다.
GitHub 실제 브랜치: https://github.com/aoaldhkd-spec/BINPC2/tree/feat/event-hub-v6-20261027

소스 기능 검증 기준: e4714cd4b60783832220058336f73124990fa74c
후속 CI 수정은 bundle/원격 개발 브랜치에 보존합니다. 문서/자료 커밋은 더 나중일 수 있습니다.
Cursor는 원격 같은 브랜치 최신 HEAD를 사용합니다. 처음부터 재개발하거나 main 병합하지 마세요.
동봉 bundle은 b7dbdcc2d722c55d20b8dd5501db0fb6a8ee6753을 선행 조건으로 하는 증분 백업입니다.
전체 소스는 GitHub에서 가져오는 것이 기본이며 bundle 복원/별도 HTML 제작은 필요 없습니다.

단위1306, 실제 DB57, 실제 브라우저6, 운영 스크립트 Node13, 보호 검사598 통과.
원격 CI의 초기 실패와 최종 재실행 결과는 github-ci-run.json/전체 보고서에서 따로 확인하세요.
전체 상태 PARTIAL: 개인정보 목적별 기간·예외·백업 정책과 실기기 확인이 남았습니다.
정책 미확정 production 신규 접수 차단, 운영 파기·실제 발송·현금 무작위 지급 비활성 유지.
main·운영 배포·실제 모집·운영 DB·외부 발송·개인정보 삭제 변경 없음.
키·비밀번호·앱 세션·storageState·DB dump·원시 API 로그는 포함하지 않습니다.
실제 참가자 정보가 아닌 합성 fixture만 사용했습니다.

가장 빠른 확인: ZIP 최상위의 참가자-실제앱-시연.mp4, 관리자-입금승인.mp4를 여세요.
