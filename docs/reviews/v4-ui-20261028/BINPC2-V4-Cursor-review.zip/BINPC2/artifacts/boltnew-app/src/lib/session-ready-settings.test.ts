import { describe, it, expect } from 'vitest';
import { planSessionReadySettingsPatch } from './session-ready-settings';

describe('planSessionReadySettingsPatch', () => {
  it('returns null for empty/invalid', () => {
    expect(planSessionReadySettingsPatch(null)).toBeNull();
    expect(planSessionReadySettingsPatch(undefined)).toBeNull();
    expect(planSessionReadySettingsPatch({})).toBeNull();
  });

  it('maps session_active + functions_locked without timers by default', () => {
    const p = planSessionReadySettingsPatch({
      session_active: true,
      functions_locked: '1',
      timer_end_at: 'x',
      timer_label: 'y',
    });
    expect(p).toEqual({
      sessionActive: true,
      hasFunctionsLocked: true,
      functionsLockedRaw: '1',
      includeTimers: false,
    });
  });

  it('includes timers when requested', () => {
    const p = planSessionReadySettingsPatch(
      { session_active: false, timer_end_at: 't1', timer_label: null },
      { includeTimers: true },
    );
    expect(p?.sessionActive).toBe(false);
    expect(p?.includeTimers).toBe(true);
    expect(p?.timerEndAt).toBe('t1');
    expect(p?.timerLabel).toBeNull();
  });

  it('omits event_schedule when omitEventSchedule is set', () => {
    const p = planSessionReadySettingsPatch(
      { session_active: true, event_schedule: '{"version":2}' },
      { includeTimers: true, omitEventSchedule: true },
    );
    expect(p?.eventScheduleRaw).toBeUndefined();
    const kept = planSessionReadySettingsPatch(
      { session_active: true, event_schedule: '{"version":2}' },
      { includeTimers: true },
    );
    expect(kept?.eventScheduleRaw).toBe('{"version":2}');
  });

  it('restores module flags from /ready after reconnect', () => {
    const p = planSessionReadySettingsPatch({
      module_flags: JSON.stringify({ direct_chat: false, ranking: false }),
    });
    expect(p?.moduleFlags?.direct_chat).toBe(false);
    expect(p?.moduleFlags?.ranking).toBe(false);
    expect(p?.moduleFlags?.hearts).toBe(true);
  });

  it('returns timers-only patch when includeTimers and no other fields', () => {
    const p = planSessionReadySettingsPatch({ timer_end_at: null }, { includeTimers: true });
    expect(p).toEqual({
      hasFunctionsLocked: false,
      includeTimers: true,
      timerEndAt: null,
      timerLabel: null,
    });
  });
});
