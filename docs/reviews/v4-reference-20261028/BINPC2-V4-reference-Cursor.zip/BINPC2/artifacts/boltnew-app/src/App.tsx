import { preserveDraftForEarlierReset, readProfileSetupDraft } from './lib/profile-setup-draft';
import { RainbowUnlockGuide } from './components/RainbowUnlockGuide';
import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { supabase, setLocalDbUserId, fetchAndSetSseToken, ensureWriteSession, onSseReconnect } from './lib/supabase';
import { useParticipantSoTResync } from './hooks/useParticipantSoTResync';
import { useSseFallbackPoll } from './hooks/useSseFallbackPoll';
import { useDarkModeStorageSync } from './hooks/useDarkModeStorageSync';
import { useUserRealtimeChannel } from './hooks/useUserRealtimeChannel';
import { useAppShellRealtimeChannels } from './hooks/useAppShellRealtimeChannels';
import { useSessionReadyBootstrap } from './hooks/useSessionReadyBootstrap';
import { useProfileBootMachine } from './hooks/useProfileBootMachine';
import { useHeartsRealtimeApply } from './hooks/useHeartsRealtimeApply';
import { useProfilesRealtimeApply } from './hooks/useProfilesRealtimeApply';
import { usePrivacySignalsRealtimeApply } from './hooks/usePrivacySignalsRealtimeApply';
import { useAppShellRealtimeApply } from './hooks/useAppShellRealtimeApply';
import { useSocialLockGuards } from './hooks/useSocialLockGuards';
import { useNicknameRegistration } from './hooks/useNicknameRegistration';
import { useProfilePrivacyLoaders } from './hooks/useProfilePrivacyLoaders';
import { useSessionInit } from './hooks/useSessionInit';
import { planAdminResetWipe, runAdminResetWipe } from './lib/admin-reset-wipe';
import type { SessionReadySettingsPatch } from './lib/session-ready-settings';
import { currentEventSlot, parseHeartOps, participantHeartState } from './lib/heart-ops';
import type { SulbunEventState } from './lib/sulbun-event';
import { subscribeNetUi, resetNetUiForRetry, type NetUiStatus } from './lib/net-health';
import { excludeSwipeGestureVerifyProfiles } from './lib/profile';
import { mergeProfilesPreserveOrder } from './lib/profile-list-order';
import { PROFILE_ROW_SELECT } from './lib/profile-select';
import {
  BLOCK_SESSION_EXPIRED_MESSAGE,
  blockFailureMessage,
  buildBlockedUserRow,
  shouldSkipBlock,
  unblockFailureMessage,
} from './lib/block-action';
import { isCompleteProfile } from './lib/profile-session';
import {
  shouldShowWaitingOverlay,
  shouldApplyAdminResetSignal,
  shouldShowNicknameSetup,
  shouldShowRecoveryScreen,
} from './lib/entry-gate';
import { countPendingHearts } from './lib/pending-hearts';
import {
  filterBlockedUsersForMe,
} from './lib/realtime-row-upsert';
import { shouldRecordProfileView } from './lib/profile-view-record';
import { FUNCTIONS_LOCK_KICK_TOAST, FUNCTIONS_LOCK_TOAST, FUNCTIONS_UNLOCK_TOAST, parseFunctionsLocked, planFunctionsLockTransition } from './lib/functions-lock';
// ─── 분리된 타입·유틸·컴포넌트 imports ────────────────────────────────────────
import type {
  Profile, ContactShare,
  View, MainTab, BlockedUser, ProfileView, UserSignal,
} from './types/app';
import { useGroupChat } from './hooks/useGroupChat';
import { renderAppEntryGates } from './components/AppEntryGates';
import { AppMainShell } from './components/AppMainShell';
import { AppOverlays } from './components/AppOverlays';
import {
  MATCHING_USER_KEY, MATCHING_DRAFT_KEY, MATCHING_LAST_RESET_KEY,
  MATCHING_PROFILES_CACHE_KEY,
  SCANNED_CONTACTS_KEY,
} from './lib/constants';
import { ls } from './lib/storage';
import { clearAllGroupLastReads } from './lib/group-rooms';
import { useHearts } from './hooks/useHearts';
import { useChat } from './hooks/useChat';
import { createParticipantNav, isParticipantAppPath } from './lib/participant-nav-history';
import { ParticipantNavProvider } from './hooks/useParticipantNav';
import { getPushOptIn, registerPushSub } from './lib/webPush';
import { DEFAULT_MODULE_FLAGS, type ModuleFlags } from './lib/module-flags';
import {
  type BottomNotificationData,
} from './components/BottomNotification';
import {
  type ShareEventNotificationData,
} from './components/ShareEventNotification';
import {
  derivePrivacyProfileIds,
  upsertScannedContact,
  type ScannedContact,
} from './lib/profile-contact-helpers';

import { eventCycleUnlocked } from './lib/event-cycle-heart';
const loadMainScreen = () => import('./components/MainScreen').then(m => ({ default: m.MainScreen }));
const loadChatScreen = () => import('./components/ChatScreen');

// ─── App ──────────────────────────────────────────────────────────────────────




function App() {
  const participantNavRef = useRef<ReturnType<typeof createParticipantNav> | null>(null);
  if (!participantNavRef.current) participantNavRef.current = createParticipantNav();
  const participantNav = participantNavRef.current;

  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    return ls.getItem(MATCHING_USER_KEY) ?? null;
  });
  const userIdRef = useRef<string | null>(null);
  userIdRef.current = currentUserId;

  // userId 변경 시 SSE 인증 토큰을 새로 발급받아 연결
  useEffect(() => {
    setLocalDbUserId(currentUserId);
    if (currentUserId) {
      fetchAndSetSseToken(currentUserId).catch((err: unknown) => {
        console.warn('[SSE] token fetch failed — running anonymous SSE', err);
      });
    }
  }, [currentUserId]);

  const [appLoading, setAppLoading] = useState(true);
  const [connStatus, setConnStatus] = useState<NetUiStatus>('ok');
  // 네트워크 UI는 net-health 단일 소스 — 순간 단절 모달 폭풍 방지
  useEffect(() => subscribeNetUi(setConnStatus), []);
  // 스플래시 동안 메인/채팅 청크 미리 받아 화면 넘김 지연 제거
  useEffect(() => {
    void loadMainScreen();
    void loadChatScreen();
  }, []);

  // Participant-only History trap: Android Back / iOS swipe close overlays, not the SPA.
  useEffect(() => {
    const nav = participantNav;
    nav.install();
    const onPop = () => {
      if (!isParticipantAppPath(window.location.pathname, import.meta.env.BASE_URL.replace(/\/$/, ''))) return;
      nav.handlePopState();
    };
    window.addEventListener('popstate', onPop);
    return () => {
      window.removeEventListener('popstate', onPop);
    };
  }, [participantNav]);
  const [sessionActive, setSessionActive] = useState<boolean | null>(null);
  const sessionActiveRef = useRef<boolean | null>(null);
  // Existing users skip the waiting overlay entirely and go straight to main.
  // New users go straight to nickname setup — no waiting overlay.
  const [shownWaiting, setShownWaiting] = useState(() => {
    try {
      return Boolean(ls.getItem(MATCHING_USER_KEY) || readProfileSetupDraft().lastStep || localStorage.getItem('test_token_v1'));
    } catch {
      return Boolean(ls.getItem(MATCHING_USER_KEY) || readProfileSetupDraft().lastStep);
    }
  });
  const [profiles, setProfiles] = useState<Profile[]>(() => {
    try {
      const cached = ls.getItem(MATCHING_PROFILES_CACHE_KEY);
      if (!cached) return [];
      const parsed = JSON.parse(cached);
      return Array.isArray(parsed)
        ? excludeSwipeGestureVerifyProfiles(parsed as Profile[], ls.getItem(MATCHING_USER_KEY))
        : [];
    } catch { return []; }
  });
  const [shareEventNotif, setShareEventNotif] = useState<ShareEventNotificationData | null>(null);
  const [contactViewShare, setContactViewShare] = useState<{ share: ContactShare; profile: Profile } | null>(null);
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [view, setView] = useState<View>(() => {
    // localStorage UUID만으로 main 진입 금지 — 서버 프로필 검증 후 전환
    if (ls.getItem(MATCHING_USER_KEY) || ls.isReadUnavailable()) return 'loading-main';
    return 'entry-1';
  });
  const viewRef = useRef(view);
  viewRef.current = view;
  /** 프로필 부트스트랩: checking=검증 중, ok=완료, recover=복구번호 필요, register=신규 등록 필요 */
  const [profileBoot, setProfileBoot] = useState<'checking' | 'ok' | 'recover' | 'register'>(
    () => (ls.getItem(MATCHING_USER_KEY) || ls.isReadUnavailable() ? 'checking' : 'register'),
  );
  const [mainTab, setMainTab] = useState<MainTab>('profiles');
  const [coachReplayToken, setCoachReplayToken] = useState(0);
  const forceCoachParticipants = useCallback(() => setMainTab('profiles'), []);
  const navigateCoachTab = useCallback((tab: MainTab) => setMainTab(tab), []);
  const replayCoach = useCallback(() => {
    setMainTab('profiles');
    setCoachReplayToken(value => value + 1);
  }, []);
  const [fortuneModalTarget, setFortuneModalTarget] = useState<Profile | null>(null);
  const [showTutorialModal, setShowTutorialModal] = useState(false);
  const [showContactQr, setShowContactQr] = useState(false);
  const [showQrScanner, setShowQrScanner] = useState(false);
  const [scannedContactProfile, setScannedContactProfile] = useState<import('./types/app').Profile | null>(null);

  // ── 스캔한 연락처 (localStorage 영구 보관) ─────────────────────────────────
  const [scannedContacts, setScannedContacts] = useState<ScannedContact[]>(() => {
    try { return JSON.parse(ls.getItem(SCANNED_CONTACTS_KEY) ?? '[]') as ScannedContact[]; } catch { return []; }
  });
  const saveScannedContact = (profile: Profile) => {
    if (!profile.id) return;
    setScannedContacts(prev => {
      const next = upsertScannedContact(prev, profile, new Date().toISOString());
      try { ls.setItem(SCANNED_CONTACTS_KEY, JSON.stringify(next)); } catch { /* quota */ }
      return next;
    });
  };
  const isNewRegistration = useRef(false);
  // 항상 최신 profiles를 가리키는 ref (stale 클로저 방지)
  const profilesRef = useRef<Profile[]>([]);
  // loadProfiles 최신 참조 — loading-main 지수 백오프에서 stale 클로저 없이 사용
  const loadProfilesRef = useRef<() => Promise<Profile[]>>(async () => []);
  // SSE fallback polling refs — SSE 끊김 중 채팅·하트 polling에 사용 (stale 클로저 방지)
  const loadChatListRef = useRef<((userId: string) => Promise<void>) | null>(null);
  const loadGroupChatsRef = useRef<((userId: string) => Promise<void>) | null>(null);
  /** 채팅 탭·단톡 화면 밖이면 group catalog SSE reload 생략 */
  const groupCatalogHotRef = useRef(true);
  // 채팅방별 미전송 초안 보존 — 뒤로가기 후 재진입 시 복원
  const chatDraftRef = useRef<Map<string, string>>(new Map());
  const loadReceivedLikesRef = useRef<((userId: string) => Promise<void>) | null>(null);
  const loadLikesRef = useRef<((userId: string) => Promise<void>) | null>(null);
  const loadContactShareDataRef = useRef<((userId: string) => Promise<void>) | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeNotif, setActiveNotif] = useState<{ id: string; message: string; type: string; target: string } | null>(null);
  const [timerEndAt, setTimerEndAt] = useState<string | null>(null);
  const [timerLabel, setTimerLabel] = useState<string | null>(null);
  const [eventScheduleRaw, setEventScheduleRaw] = useState<string | null>(null);
  const [cycleMeta, setCycleMeta] = useState<{
    startedAt: string | null; resetComplete: boolean; archiveId: string | null; npcRefill: unknown;
  }>({ startedAt: null, resetComplete: true, archiveId: null, npcRefill: null });
  const acceptCycleMeta = useCallback((data: Record<string, unknown>) => {
    setCycleMeta(previous => ({
      startedAt: 'event_cycle_started_at' in data
        ? (typeof data.event_cycle_started_at === 'string' ? data.event_cycle_started_at : null) : previous.startedAt,
      resetComplete: 'event_cycle_reset_complete' in data
        ? data.event_cycle_reset_complete === true : previous.resetComplete,
      archiveId: 'event_cycle_archive_id' in data
        ? (typeof data.event_cycle_archive_id === 'string' ? data.event_cycle_archive_id : null) : previous.archiveId,
      npcRefill: 'npc_heart_refill' in data ? data.npc_heart_refill : previous.npcRefill,
    }));
  }, []);
  const [, setSulbunEvent] = useState<SulbunEventState | null>(null);
  // Quotas change at clock-slot boundaries even when the schedule JSON is unchanged.
  const [eventScheduleMinute, setEventScheduleMinute] = useState(() => Math.floor(Date.now() / 60_000));
  const [rejectionNotif, setRejectionNotif] = useState<string | null>(null); // nickname of person who rejected
  const [bottomNotif, setBottomNotif] = useState<BottomNotificationData | null>(null);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const confettiTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const confettiInnerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const triggerConfetti = useCallback(() => {
    // 뷰 전환 시 이전 타이머 취소 가능하도록 ref에 저장
    if (confettiTimerRef.current) clearTimeout(confettiTimerRef.current);
    if (confettiInnerTimerRef.current) clearTimeout(confettiInnerTimerRef.current);
    setShowConfetti(false);
    confettiTimerRef.current = setTimeout(() => {
      setShowConfetti(true);
      confettiTimerRef.current = null;
      // 애니메이션 완료 후 반드시 false로 리셋:
      // ConfettiOverlay가 view 전환(profile↔main)으로 언마운트→재마운트될 때
      // show=true 잔류 상태로 인해 폭죽이 재발사되는 버그를 방지한다.
      confettiInnerTimerRef.current = setTimeout(() => {
        confettiInnerTimerRef.current = null;
        setShowConfetti(false);
      }, 2100);
    }, 30);
  }, []);
  const eventScheduleRawForCycle = useMemo(() => {
    const minute = eventScheduleMinute > 0 ? eventScheduleMinute * 60_000 : Date.now();
    const npc = cycleMeta.npcRefill && typeof cycleMeta.npcRefill === 'object'
      && !Array.isArray(cycleMeta.npcRefill)
      ? cycleMeta.npcRefill as Record<string, unknown> : null;
    const verifiedNpc = !cycleMeta.resetComplete && Boolean(
      npc && currentUserId && npc.npcId === currentUserId && npc.archiveId === cycleMeta.archiveId
    );
    const keys = verifiedNpc
      ? ['red', 'blue', 'pink', 'green', 'rainbow']
      : [...eventCycleUnlocked({
        startedAt: cycleMeta.startedAt, resetComplete: cycleMeta.resetComplete, now: new Date(minute),
      })];
    return JSON.stringify({ timezone: 'Asia/Seoul', version: 2, slots: [], instant_unlock: keys });
  }, [cycleMeta.startedAt, cycleMeta.resetComplete, cycleMeta.npcRefill, cycleMeta.archiveId, currentUserId, eventScheduleMinute]);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [profileVisitors, setProfileVisitors] = useState<ProfileView[]>([]);
  const [newVisitCount, setNewVisitCount] = useState(0);
  const [userSignals, setUserSignals] = useState<UserSignal[]>([]);
  const [mySubTabHint, setMySubTabHint] = useState<'status' | 'chats' | null>(null);
  const [functionsLocked, setFunctionsLocked] = useState(false);
  const [moduleFlags, setModuleFlags] = useState<ModuleFlags>(DEFAULT_MODULE_FLAGS);
  const functionsLockedRef = useRef(false);
  functionsLockedRef.current = functionsLocked;
  const functionsLockedPrevRef = useRef(false);
  const [functionsLockToast, setFunctionsLockToast] = useState<string | null>(null);
  const functionsLockToastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showFunctionsLockToast = useCallback((msg: string = FUNCTIONS_LOCK_TOAST) => {
    if (functionsLockToastTimerRef.current) clearTimeout(functionsLockToastTimerRef.current);
    setFunctionsLockToast(msg);
    functionsLockToastTimerRef.current = setTimeout(() => {
      functionsLockToastTimerRef.current = null;
      setFunctionsLockToast(null);
    }, 1800);
  }, []);
  const [registrationError, setRegistrationError] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState(() => ls.getItem('dark_mode') === '1');
  // 테마 전환 시 dark_mode 동기화 (theme.tsx에서 storage 이벤트 발화)
  useDarkModeStorageSync(setDarkMode);

  // profile/privacy loaders + nickname/registration — App wires setState only
  const {
    loadProfiles,
    handleUserSignalUpdate,
    refreshProfilesTab,
  } = useProfilePrivacyLoaders({
    currentUserId,
    userIdRef,
    profilesRef,
    loadProfilesRef,
    setProfiles,
    setUserSignals,
    setBlockedUsers,
    setProfileVisitors,
  });

  const { handleNicknameSetup, handleProfileRecovery, reset } = useNicknameRegistration({
    isNewRegistration,
    setLoading,
    setRegistrationError,
    setProfiles,
    setUserSignals,
    setCurrentUserId,
    setProfileBoot,
    setView,
    setShownWaiting,
  });

  // loading-main profile boot / backoff — pure machine + thin hook; App applies results
  useProfileBootMachine({
    view,
    getUserId: () => userIdRef.current,
    getProfiles: () => profilesRef.current,
    loadProfiles: () => loadProfilesRef.current(),
    fetchProfileById: async (uid) => {
      const { data: direct } = await supabase.from('profiles').select(PROFILE_ROW_SELECT).eq('id', uid).maybeSingle();
      return (direct as Profile | null) ?? null;
    },
    mergeFetchedProfile: (me) => {
      setProfiles(prev => prev.some(p => p.id === me.id)
        ? prev.map(p => (p.id === me.id ? me : p))
        : mergeProfilesPreserveOrder(prev, [...prev, me]));
    },
    onEnterMain: () => {
      setProfileBoot('ok');
      setView('main');
    },
    onRegister: () => {
      if (ls.isReadUnavailable()) {setProfileBoot('checking');return;}
      setProfileBoot('register');
      setView('entry-1');
    },
    onRecoverCleared: () => {
      ls.removeItem(MATCHING_USER_KEY);
      ls.removeItem(MATCHING_DRAFT_KEY);
      setCurrentUserId(null);
      setProfileBoot('recover');
      setView('entry-recover');
    },
    onRecoverExhausted: () => {
      // A transient profile read failure is not a logout. Keep the stored
      // identity and let useProfileBootMachine retry in the background.
      setProfileBoot('checking');
      setView('loading-main');
    },
  });

  // SSE fallback poll: useSseFallbackPoll (wired after loaders below)

  // Track user's current table number for notification targeting (ref for stable access in channel callbacks)

  const profileMap = useMemo(() => new Map(profiles.map((p) => [p.id, p])), [profiles]);
  // 렌더마다 최신 profiles를 ref에 동기화 (stale 클로저 방지)
  profilesRef.current = profiles;

  // selectedProfile(= ChatScreen의 otherProfile) 동기화
  // 채팅 화면에 있는 동안 상대방이 프로필을 수정하면 profileMap이 갱신되므로
  // selectedProfile도 최신 데이터로 교체한다.
  useEffect(() => {
    if (!selectedProfile) return;
    const updated = profileMap.get(selectedProfile.id);
    if (updated && updated !== selectedProfile) setSelectedProfile(updated);
  }, [profileMap]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── 커스텀 훅 호출 ────────────────────────────────────────────────────────────

  const {
    chatId, setChatId, chatIdRef, messages, chatList, setChatList,
    unreadChatCounts, setUnreadChatCounts,
    loadChatList, openChat, sendMessage, sendImage,
    deleteChat, deleteAllChats, deleteMessage,
    hasMoreOlderMessages, loadingOlderMessages, loadOlderMessages,
  } = useChat({
    currentUserId: moduleFlags.direct_chat ? currentUserId : null,
    profilesRef,
    setSelectedProfile,
    setView,
    setBottomNotif,
    functionsLocked,
  });

  const {
    groupChats,
    activeGroupId,
    groupMessages,
    groupParticipants,
    unreadGroupCounts,
    openGroupChat,
    joinGroupChat,
    joiningGroupId,
    closeGroupChat,
    sendGroupMessage,
    leaveGroupChat,
    loadGroupChats,
  } = useGroupChat({
    currentUserId: moduleFlags.group_chat ? currentUserId : null,
    profilesRef,
    setBottomNotif,
    groupCatalogHotRef,
  });

  groupCatalogHotRef.current = mainTab === 'my' || view === 'group-chat' || !!activeGroupId;

  const {
    likedIds, setLikedIds, sentHeartTypes, setSentHeartTypes, sentHeartsPerPerson, setSentHeartsPerPerson,
    receivedHeartTypes, setReceivedHeartTypes, likeStatuses, setLikeStatuses,
    receivedLikers, setReceivedLikers, contactSharedWithIds,
    acknowledgedComplimentIds, setAcknowledgedComplimentIds, receivedContactShares, setReceivedContactShares,
    likeConfirmTarget, setLikeConfirmTarget, contactShareTarget, setContactShareTarget,
    loadLikes, loadReceivedLikes, loadContactShareData, getHeartUsage,
    handleLike, executeLike, handleHeartResponse, handleContactShare,
    likeError, setLikeError,
  } = useHearts(moduleFlags.hearts ? currentUserId : null, profiles, profileMap, openChat,
    eventScheduleRawForCycle, cycleMeta.npcRefill, cycleMeta.archiveId);

  const loadChatListForModules = useCallback((userId: string) => {
    if (!moduleFlags.direct_chat) return Promise.resolve();
    return Promise.resolve(loadChatList(userId));
  }, [loadChatList, moduleFlags.direct_chat]);
  const loadGroupChatsForModules = useCallback((userId: string) => {
    if (!moduleFlags.group_chat) return Promise.resolve();
    return Promise.resolve(loadGroupChats(userId));
  }, [loadGroupChats, moduleFlags.group_chat]);
  const loadLikesForModules = useCallback((userId: string) => {
    if (!moduleFlags.hearts) return Promise.resolve();
    return Promise.resolve(loadLikes(userId));
  }, [loadLikes, moduleFlags.hearts]);
  const loadReceivedLikesForModules = useCallback((userId: string) => {
    if (!moduleFlags.hearts) return Promise.resolve();
    return Promise.resolve(loadReceivedLikes(userId));
  }, [loadReceivedLikes, moduleFlags.hearts]);
  const loadContactShareDataForModules = useCallback((userId: string) => {
    if (!moduleFlags.hearts) return Promise.resolve();
    return Promise.resolve(loadContactShareData(userId));
  }, [loadContactShareData, moduleFlags.hearts]);
  useEffect(() => {
    if (!eventScheduleRaw) { setEventScheduleMinute(0); return; }
    let timer: number | undefined;
    const refresh = () => setEventScheduleMinute(Math.floor(Date.now() / 60_000));
    const schedule = () => {
      timer = window.setTimeout(() => { refresh(); schedule(); }, 60_000 - (Date.now() % 60_000) + 50);
    };
    refresh();
    schedule();
    return () => { if (timer !== undefined) window.clearTimeout(timer); };
  }, [eventScheduleRaw]);
  // Minute ticker drives recompute; never use epoch (minute===0) while a schedule exists.
  const scheduleNow = useMemo(
    () => new Date(eventScheduleMinute > 0 ? eventScheduleMinute * 60_000 : Date.now()),
    [eventScheduleMinute],
  );
  const heartOpsConfig = useMemo(
    () => {
      const canonical = parseHeartOps(eventScheduleRaw);
      const cycle = parseHeartOps(eventScheduleRawForCycle);
      return { ...canonical, slots: [], instant_unlock: cycle.instant_unlock, auto_unlock_from: undefined };
    },
    [eventScheduleRaw, eventScheduleRawForCycle],
  );
  const heartUsage = useMemo(() => getHeartUsage(), [getHeartUsage]);
  const participantHearts = useMemo(
    () => participantHeartState(heartOpsConfig, heartUsage, functionsLocked, scheduleNow),
    [heartOpsConfig, heartUsage, functionsLocked, scheduleNow],
  );
  // The schedule is also evaluated locally between SSE/ready heartbeats so a slot
  // boundary does not leave the buttons visually stale. The server remains authoritative.
  useEffect(() => {
    if (!eventScheduleRaw) return;
    const applySlotLock = () => {
      const now = new Date();
      setEventScheduleMinute(Math.floor(now.getTime() / 60_000));
      const lock = currentEventSlot(eventScheduleRaw, now)?.functions_locked;
      if (typeof lock === 'boolean') setFunctionsLocked(lock);
    };
    applySlotLock();
    const id = window.setInterval(applySlotLock, 1000);
    return () => window.clearInterval(id);
  }, [eventScheduleRaw]);

  // 하트 전송 실패 알림 — executeLike가 error를 set하면 바텀 토스트로 표시
  useEffect(() => {
    if (!likeError) return;
    setBottomNotif({ type: 'chat', nickname: '', message: likeError });
    const t = setTimeout(() => {
      setBottomNotif(prev => prev?.message === likeError ? null : prev);
      setLikeError(null);
    }, 4_000);
    return () => clearTimeout(t);
  }, [likeError, setLikeError]);

  // SSE fallback polling refs 동기화 — 렌더마다 최신 함수를 가리키도록 (stale 클로저 방지)
  loadChatListRef.current = loadChatListForModules;
  loadGroupChatsRef.current = loadGroupChatsForModules;
  loadReceivedLikesRef.current = loadReceivedLikesForModules;
  loadLikesRef.current = loadLikesForModules;
  loadContactShareDataRef.current = loadContactShareDataForModules;
  const heartsRealtimeApply = useHeartsRealtimeApply({
    currentUserId,
    userIdRef,
    profilesRef,
    loadReceivedLikesRef,
    loadContactShareData: loadContactShareDataForModules,
    triggerConfetti,
    setLikedIds,
    setSentHeartTypes,
    setLikeStatuses,
    setSentHeartsPerPerson,
    setReceivedHeartTypes,
    setReceivedLikers,
    setAcknowledgedComplimentIds,
    setReceivedContactShares,
    setBottomNotif,
    setRejectionNotif,
    likedIds,
    likeStatuses,
    receivedContactShares,
    receivedHeartTypes,
    sentHeartsPerPerson,
  });

  const profilesRealtimeApply = useProfilesRealtimeApply({
    userIdRef,
    setProfiles,
  });

  const privacySignalsRealtimeApply = usePrivacySignalsRealtimeApply({
    userIdRef,
    setBlockedUsers,
    setProfileVisitors,
    setUserSignals,
  });

  const {
    handleLikeGuarded,
    handleHeartResponseGuarded,
    handleContactShareGuarded,
    openChatGuarded,
    sendMessageGuarded,
    sendImageGuarded,
    leaveGroupChatGuarded,
    handleMainOpenGroupChat,
    handleMainJoinGroupChat,
    handleMainLeaveGroupChat,
    sendGroupMessageGuarded,
    handleMainTabChange,
    execLikeGuarded,
    handleContactShareOpen,
  } = useSocialLockGuards({
    functionsLocked,
    functionsLockedRef,
    moduleFlags,
    showFunctionsLockToast,
    handleLike,
    handleHeartResponse,
    handleContactShare,
    executeLike,
    triggerConfetti,
    setLikeConfirmTarget,
    setContactShareTarget,
    openChat,
    sendMessage,
    sendImage,
    openGroupChat,
    joinGroupChat,
    leaveGroupChat,
    closeGroupChat,
    sendGroupMessage,
    setView,
    setMainTab,
  });

  // 채팅 탭 진입 시 단톡 목록 로드
  useEffect(() => {
    if (moduleFlags.group_chat && mainTab === 'my' && currentUserId) {
      void loadGroupChats(currentUserId);
    }
  }, [moduleFlags.group_chat, mainTab, currentUserId, loadGroupChats]);

  const screenStackRef = useRef<Array<'profile' | 'chat' | 'group-chat'>>([]);
  const navDrivenViewRef = useRef(false);
  const closeChatLayerRef = useRef(() => {});
  const closeProfileLayerRef = useRef(() => {});
  const closeGroupLayerRef = useRef(() => {});

  closeChatLayerRef.current = () => {
    navDrivenViewRef.current = true;
    chatIdRef.current = null;
    setChatId(null);
    if (screenStackRef.current.at(-1) === 'chat') screenStackRef.current.pop();
    const prev = screenStackRef.current.at(-1);
    setView(prev === 'profile' ? 'profile' : 'main');
  };
  closeProfileLayerRef.current = () => {
    navDrivenViewRef.current = true;
    setLikeConfirmTarget(null);
    if (screenStackRef.current.at(-1) === 'profile') screenStackRef.current.pop();
    setView('main');
  };
  closeGroupLayerRef.current = () => {
    navDrivenViewRef.current = true;
    if (screenStackRef.current.at(-1) === 'group-chat') screenStackRef.current.pop();
    closeGroupChat();
    setView('main');
  };

  const goParticipantBack = useCallback(() => {
    if (participantNav.depth() > 0) participantNav.requestBack();
    else if (view === 'chat') closeChatLayerRef.current();
    else if (view === 'profile') closeProfileLayerRef.current();
    else if (view === 'group-chat') closeGroupLayerRef.current();
  }, [participantNav, view]);

  useEffect(() => {
    if (view === 'profile' || view === 'chat' || view === 'group-chat') {
      if (screenStackRef.current.at(-1) !== view) {
        screenStackRef.current.push(view);
        const close = view === 'chat'
          ? () => closeChatLayerRef.current()
          : view === 'profile'
            ? () => closeProfileLayerRef.current()
            : () => closeGroupLayerRef.current();
        participantNav.push(`screen:${view}`, close);
      }
      navDrivenViewRef.current = false;
      return;
    }
    if (navDrivenViewRef.current) {
      navDrivenViewRef.current = false;
      return;
    }
    const drop: string[] = [];
    while (true) {
      const top = screenStackRef.current.at(-1);
      if (top !== 'profile' && top !== 'chat' && top !== 'group-chat') break;
      screenStackRef.current.pop();
      drop.push(`screen:${top}`);
    }
    const extra = participantNav.layers().filter(id =>
      drop.includes(id) || id.startsWith('chat-') || id === 'group-leave',
    );
    const ids = [...new Set([...drop, ...extra])];
    if (ids.length) participantNav.dropMatching(ids);
  }, [view, participantNav]);

  // 오버레이를 display:none 으로 메인을 접지 않으므로, 뒤 스크롤만 잠근다.
  useEffect(() => {
    const sub = view === 'profile' || view === 'chat' || view === 'group-chat';
    if (!sub) return;
    const html = document.documentElement;
    const prev = html.style.overflow;
    html.style.overflow = 'hidden';
    return () => { html.style.overflow = prev; };
  }, [view]);

  // 잠금이 켜지는 순간에만 채팅·단톡·궁합 모달에서 참여자 탭으로 되돌림. 통계·랭킹·설정은 유지.
  useEffect(() => {
    const wasLocked = functionsLockedPrevRef.current;
    functionsLockedPrevRef.current = functionsLocked;
    const plan = planFunctionsLockTransition({
      wasLocked,
      nowLocked: functionsLocked,
      view,
      mainTab,
      hasFortuneModal: Boolean(fortuneModalTarget),
      hasLikeConfirm: Boolean(likeConfirmTarget),
      hasContactShare: Boolean(contactShareTarget),
    });
    if (plan.showUnlockToast) {
      showFunctionsLockToast(FUNCTIONS_UNLOCK_TOAST);
      return;
    }
    if (plan.closeChatOrGroup) {
      chatIdRef.current = null;
      setChatId(null);
      closeGroupChat();
      setView('main');
    }
    if (plan.resetMainTabToProfiles) setMainTab('profiles');
    if (plan.clearFortune) setFortuneModalTarget(null);
    if (plan.clearLikeConfirm) setLikeConfirmTarget(null);
    if (plan.clearContactShare) setContactShareTarget(null);
    if (plan.showKickToast) showFunctionsLockToast(FUNCTIONS_LOCK_KICK_TOAST);
  }, [functionsLocked, view, mainTab, fortuneModalTarget, likeConfirmTarget, contactShareTarget, chatIdRef, closeGroupChat, setChatId, setContactShareTarget, setLikeConfirmTarget, showFunctionsLockToast]);

  // ─── 차단·숨기기 처리 (pure planners + thin async wire) ───────────────────
  const handleBlock = useCallback(async (targetId: string, type: 'block' | 'hide') => {
    if (shouldSkipBlock({ currentUserId, targetId, type, blockedUsers })) return;
    const sessionOk = await ensureWriteSession();
    if (!sessionOk) {
      setBottomNotif({ type: 'system', message: BLOCK_SESSION_EXPIRED_MESSAGE });
      return;
    }
    const id = crypto.randomUUID();
    const row = buildBlockedUserRow({
      id,
      currentUserId: currentUserId!,
      targetId,
      type,
      createdAt: new Date().toISOString(),
    });
    // 낙관적 업데이트
    setBlockedUsers(prev => [...prev, row]);
    const { error } = await supabase.from('blocked_users').insert(row as never);
    if (error) {
      console.error('[handleBlock]', error);
      setBlockedUsers(prev => prev.filter(b => b.id !== id));
      setBottomNotif({ type: 'system', message: blockFailureMessage(type) });
    }
  }, [currentUserId, blockedUsers, setBottomNotif]);

  // ─── 차단·숨기기 해제 ────────────────────────────────────────────────────
  const handleUnblock = useCallback(async (blockId: string) => {
    const sessionOk = await ensureWriteSession();
    if (!sessionOk) {
      setBottomNotif({ type: 'system', message: BLOCK_SESSION_EXPIRED_MESSAGE });
      return;
    }
    setBlockedUsers(prev => prev.filter(b => b.id !== blockId));
    const { error } = await supabase.from('blocked_users').delete().eq('id', blockId as never);
    if (error) {
      console.error('[handleUnblock]', error);
      setBottomNotif({ type: 'system', message: unblockFailureMessage() });
      // 실패 시 재로드
      supabase.from('blocked_users').select('id, user_id, target_id, block_type, created_at').then(({ data }: { data: unknown }) => {
        if (Array.isArray(data) && currentUserId) {
          setBlockedUsers(filterBlockedUsersForMe(data as BlockedUser[], currentUserId));
        }
      }).catch(() => {});
    }
  }, [currentUserId, setBottomNotif]);

  // ─── 프로필 열 때 방문 기록 ───────────────────────────────────────────────
  // 카드 사진 탭(뒤집기)과 상세/사주 오픈이 연속되면 같은 상대에 대해 중복 INSERT 방지
  const recentProfileViewsRef = useRef<Map<string, number>>(new Map());
  const recordProfileView = useCallback(async (viewedId: string) => {
    const now = Date.now();
    const last = recentProfileViewsRef.current.get(viewedId) ?? 0;
    if (!shouldRecordProfileView({
      viewerId: currentUserId,
      viewedId,
      lastRecordedAt: last,
      now,
    })) return;
    recentProfileViewsRef.current.set(viewedId, now);
    const row: ProfileView = { id: crypto.randomUUID(), viewer_id: currentUserId!, viewed_id: viewedId, viewed_at: new Date().toISOString() };
    try { await supabase.from('profile_views').insert(row as never); } catch {}
  }, [currentUserId]);

  const handleSelectProfile = useCallback((p: Profile) => {
    setLikeConfirmTarget(null);
    setSelectedProfile(p);
    setView('profile');
    void recordProfileView(p.id);
  }, [recordProfileView, setLikeConfirmTarget]);

  const handleUpdateProfile = useCallback((update: Record<string, unknown> & { id: string }) => {
    setProfiles(prev => prev.map(p => p.id === update.id ? { ...p, ...update } : p));
  }, []);

  const handleToggleDark = useCallback(() => {
    setDarkMode(prev => {
      const next = !prev;
      ls.setItem('dark_mode', next ? '1' : '0');
      return next;
    });
  }, []);

  const handleClearScannedContact = useCallback((id: string) => {
    setScannedContacts(prev => {
      const next = prev.filter(c => c.id !== id);
      try { ls.setItem(SCANNED_CONTACTS_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  }, []);

  const handleShowTutorial = useCallback(() => {
    setShowTutorialModal(true);
  }, []);

  const handleClearChatUnread = useCallback((chatId: string) => {
    setUnreadChatCounts(prev => { const n = { ...prev }; delete n[chatId]; return n; });
  }, [setUnreadChatCounts]);

  const handleContactViewOpen = useCallback((share: ContactShare, profile: Profile) => {
    setContactViewShare({ share, profile });
  }, []);

  const handleViewFortuneFromCard = useCallback((p: Profile) => {
    if (functionsLockedRef.current) { showFunctionsLockToast(); return; }
    setFortuneModalTarget(p);
    void recordProfileView(p.id);
  }, [recordProfileView, showFunctionsLockToast]);

  const handleViewProfileCard = useCallback((p: Profile) => {
    void recordProfileView(p.id);
  }, [recordProfileView]);


  // Admin reset wipe — planner/runner; shared by /ready bootstrap + settings SSE apply.
  const applyResetSignal = useCallback((serverReset: string) => {
    if (!shouldApplyAdminResetSignal(serverReset, ls.getItem(MATCHING_LAST_RESET_KEY))) return;
    const me = profilesRef.current.find(p => p.id === userIdRef.current);
    // A delayed previous-cycle reset must not delete a newer admitted profile.
    if ((me && Date.parse(me.created_at) > Date.parse(serverReset))
      || (!userIdRef.current && preserveDraftForEarlierReset(serverReset))) {
      ls.setItem(MATCHING_LAST_RESET_KEY, serverReset);
      return;
    }
    runAdminResetWipe(planAdminResetWipe(serverReset), {
      setItem: (k, v) => ls.setItem(k, v),
      removeItem: (k) => ls.removeItem(k),
      clearAllGroupLastReads,
      setCurrentUserId,
      setShownWaiting,
      setProfilesEmpty: () => setProfiles([]),
      clearHeartsAndChats: () => {
        setLikedIds(new Set());
        setSentHeartTypes(new Map());
        setSentHeartsPerPerson(new Map());
        setAcknowledgedComplimentIds(new Set());
        setReceivedLikers([]);
        setChatList([]);
      },
      setActiveNotif,
      reloadProfiles: () => { void loadProfilesRef.current().catch(() => {}); },
      setView,
    });
  }, [setLikedIds, setSentHeartTypes, setSentHeartsPerPerson, setAcknowledgedComplimentIds, setReceivedLikers, setChatList]);

  useSessionReadyBootstrap({
    applyResetSignal,
    setAppLoading,
    setSessionActive,
    setSessionActiveRef: (v) => { sessionActiveRef.current = v; },
    setTimerEndAt,
    setTimerLabel,
    setEventSchedule: setEventScheduleRaw,
    setEventCycleMeta: acceptCycleMeta,
    setSulbunEvent,
    setFunctionsLocked,
    setModuleFlags,
  });

  // participant session-init — hearts clear, profile resolve, deferred loads, ?share= QR
  useSessionInit({
    currentUserId,
    contactQrEnabled: moduleFlags.contact_qr,
    isNewRegistration,
    viewRef,
    getProfiles: () => profilesRef.current,
    loadProfiles,
    loadLikes: loadLikesForModules,
    loadReceivedLikes: loadReceivedLikesForModules,
    loadContactShareData: loadContactShareDataForModules,
    loadChatList: loadChatListForModules,
    clearHeartsState: () => {
      setLikedIds(new Set());
      setSentHeartTypes(new Map());
      setSentHeartsPerPerson(new Map());
      setReceivedHeartTypes(new Map());
      setLikeStatuses(new Map());
      setReceivedLikers([]);
    },
    setProfileBoot,
    setView,
    setMainTab,
    setMySubTabHint,
    setCurrentUserId,
    setShownWaiting,
    setProfiles,
    saveScannedContact,
    setScannedContactProfile,
    confettiTimerRef,
    confettiInnerTimerRef,
  });


  // Participant SoT: visibility + SSE reconnect live in useParticipantSoTResync.
  // App only wires loaders + applySessionReady (no new useState for this peel).
  const applySessionReady = useCallback((patch: SessionReadySettingsPatch, source: 'visibility' | 'sse-reconnect') => {
    if (typeof patch.sessionActive === 'boolean') {
      sessionActiveRef.current = patch.sessionActive;
      setSessionActive(patch.sessionActive);
      if (source === 'sse-reconnect' && !patch.sessionActive && userIdRef.current) {
        setShownWaiting(false);
      }
    }
    if (patch.hasFunctionsLocked) {
      setFunctionsLocked(parseFunctionsLocked(patch.functionsLockedRaw));
    }
    if (patch.sulbunEvent !== undefined) setSulbunEvent(patch.sulbunEvent);
    if (patch.eventCycleMeta !== undefined) acceptCycleMeta(patch.eventCycleMeta);
    if (patch.moduleFlags) setModuleFlags(patch.moduleFlags);
    if (patch.includeTimers) {
      setTimerEndAt(patch.timerEndAt ?? null);
      setTimerLabel(patch.timerLabel ?? null);
      if (patch.eventScheduleRaw !== undefined) setEventScheduleRaw(patch.eventScheduleRaw ?? null);
    }
  }, [acceptCycleMeta]);

  useParticipantSoTResync({
    currentUserId,
    getStoredUserId: () => ls.getItem(MATCHING_USER_KEY),
    loadProfiles,
    loadChatList: loadChatListForModules,
    loadLikes: loadLikesForModules,
    loadReceivedLikes: loadReceivedLikesForModules,
    loadContactShareData: loadContactShareDataForModules,
    applySessionReady,
  });

  // profiles + likes/contact_shares + privacy + signals fan-in — App wires apply hooks; channel only routes.
  useUserRealtimeChannel({
    currentUserId,
    heartsEnabled: moduleFlags.hearts,
    ...profilesRealtimeApply,
    ...heartsRealtimeApply,
    ...privacySignalsRealtimeApply,
  });

  // app_settings + notifications + contact_share_events — App wires apply; channel only routes.
  const appShellRealtimeApply = useAppShellRealtimeApply({
    userIdRef,
    sessionActiveRef,
    applyResetSignal,
    loadContactShareData: loadContactShareDataForModules,
    setSessionActive,
    setShownWaiting,
    setView,
    setTimerEndAt,
    setTimerLabel,
    setEventScheduleRaw,
    setEventCycleMeta: acceptCycleMeta,
    setSulbunEvent,
    setFunctionsLocked,
    setModuleFlags,
    setActiveNotif,
    setShareEventNotif,
  });
  useAppShellRealtimeChannels(appShellRealtimeApply);

  // SSE unhealthy poll — App only wires loaders (mirrors SoT peel; no new useState).
  useSseFallbackPoll({
    connStatus,
    currentUserId,
    loadProfiles,
    loadChatList: loadChatListForModules,
    loadGroupChats: loadGroupChatsForModules,
    loadReceivedLikes: loadReceivedLikesForModules,
    loadLikes: loadLikesForModules,
    loadContactShareData: loadContactShareDataForModules,
  });

  // 설치된 PWA에서 이미 허용된 휴대폰 Push 구독을 재등록한다.
  // 새로운 권한은 설정 화면의 명시적인 사용자 클릭으로만 요청한다.
  useEffect(() => {
    if (!currentUserId || !moduleFlags.push || !getPushOptIn(currentUserId)) return;
    void registerPushSub(currentUserId);
    // 첫 진입에서 SSE 토큰 발급이 아직 끝나지 않은 경우, 재연결 시 서버 구독을 재시도.
    // webPush 쪽은 동시 요청·짧은 시간 중복을 자체 제한한다.
    return onSseReconnect(() => { void registerPushSub(currentUserId); });
  }, [currentUserId, moduleFlags.push]);


  // Soft detach applies immediately without deleting data/code.
  useEffect(() => {
    if (!moduleFlags.hearts) {
      setLikeConfirmTarget(null);
      setContactShareTarget(null);
    }
    if (!moduleFlags.contact_qr) {
      setShowContactQr(false);
      setShowQrScanner(false);
      setScannedContactProfile(null);
    }
    if (!moduleFlags.direct_chat && view === 'chat') {
      chatIdRef.current = null;
      setChatId(null);
      setView('main');
      setMainTab('my');
    }
    if (!moduleFlags.group_chat && view === 'group-chat') {
      closeGroupChat();
      setView('main');
      setMainTab('my');
    }
    if (!moduleFlags.stats && mainTab === 'stats') setMainTab('profiles');
    if (!moduleFlags.ranking && mainTab === 'ranking') setMainTab('profiles');
  }, [
    moduleFlags,
    view,
    mainTab,
    closeGroupChat,
    chatIdRef,
    setChatId,
    setContactShareTarget,
    setLikeConfirmTarget,
  ]);

  // PWA 알림 클릭 deep-link: 하트는 받은 하트 화면, 1:1 채팅은 해당 상대 채팅방.
  useEffect(() => {
    if (!currentUserId || profileBoot !== 'ok') return;
    const params = new URLSearchParams(window.location.search);
    const pushKind = params.get('push');
    if (!pushKind) return;

    const cleanUrl = () => {
      for (const key of ['push', 'from', 'peer', 'chat']) params.delete(key);
      const q = params.toString();
      window.history.replaceState(window.history.state, '', `${window.location.pathname}${q ? `?${q}` : ''}${window.location.hash}`);
    };

    if (pushKind === 'heart') {
      if (!moduleFlags.hearts) { cleanUrl(); return; }
      setView('main');
      setMainTab('my');
      setMySubTabHint('status');
      void loadReceivedLikes(currentUserId);
      void loadLikes(currentUserId);
      cleanUrl();
      return;
    }

    if (pushKind === 'chat') {
      if (!moduleFlags.direct_chat) { cleanUrl(); return; }
      const peerId = params.get('peer');
      const peer = peerId ? profileMap.get(peerId) : undefined;
      if (peer) {
        void openChatGuarded(peer);
        cleanUrl();
      } else if (peerId && peerId !== currentUserId) {
        // 새로 열린 PWA는 프로필 목록 로드가 끝나기 전에 알림 딥링크를 받을 수 있다.
        // 해당 상대 프로필 하나만 조회한 뒤 정확한 1:1 방으로 이동한다.
        // 조회 실패 시에는 해당 사용자의 채팅 목록으로 안전하게 폴백한다.
        void supabase.from('profiles').select(PROFILE_ROW_SELECT).eq('id', peerId).maybeSingle()
          .then(({ data }) => {
            if (data && userIdRef.current === currentUserId) {
              void openChatGuarded(data as Profile);
            } else if (userIdRef.current === currentUserId) {
              setView('main');
              setMainTab('my');
              setMySubTabHint('chats');
              void loadChatList(currentUserId);
            }
          })
          .catch(() => {
            if (userIdRef.current !== currentUserId) return;
            setView('main');
            setMainTab('my');
            setMySubTabHint('chats');
            void loadChatList(currentUserId);
          })
          .finally(cleanUrl);
      } else {
        setView('main');
        setMainTab('my');
        setMySubTabHint('chats');
        void loadChatList(currentUserId);
        cleanUrl();
      }
    }
  }, [
    currentUserId, profileBoot, profileMap, openChatGuarded,
    loadReceivedLikes, loadLikes, loadChatList, moduleFlags.hearts, moduleFlags.direct_chat,
  ]);


  // Manual refresh for status and chat tabs
  const refreshStatusTab = useCallback(() => {
    if (!currentUserId) return;
    loadReceivedLikes(currentUserId);
    loadLikes(currentUserId);
    loadContactShareData(currentUserId);
  }, [currentUserId, loadReceivedLikes, loadLikes, loadContactShareData]);

  const refreshChatTab = useCallback(() => {
    if (!currentUserId) return;
    loadChatList(currentUserId);
  }, [currentUserId, loadChatList]);


  // useMemo: 매 렌더마다 filter 재계산 방지 — 모든 early return 전에 선언 (Rules of Hooks 준수)
  const sentLikedProfiles = useMemo(
    () => profiles.filter((p) => likedIds.has(p.id)),
    [profiles, likedIds],
  );
  const pendingHeartsCount = useMemo(
    () => countPendingHearts(
      receivedLikers,
      receivedHeartTypes,
      acknowledgedComplimentIds,
      contactSharedWithIds,
    ),
    [receivedLikers, receivedHeartTypes, acknowledgedComplimentIds, contactSharedWithIds],
  );

  const privacyProfileIds = useMemo(
    () => derivePrivacyProfileIds(blockedUsers, currentUserId),
    [blockedUsers, currentUserId],
  );

  const myProfile = currentUserId ? profileMap.get(currentUserId) : null;
  const hasValidProfile = isCompleteProfile(myProfile ?? undefined);

  // 신규 방문자만 참여자 대기 랜딩. 더미/복구/재방문(userId 있음)은 loading-main → 메인
  const isTester = (() => {
    try { return Boolean(localStorage.getItem('test_token_v1')); } catch { return false; }
  })();
  const showWaiting = profileBoot !== "checking" && shouldShowWaitingOverlay({
    shownWaiting,
    currentUserId,
    hasValidProfile,
    isTester,
  });
  const showRecovery = shouldShowRecoveryScreen({
    hasValidProfile,
    profileBoot,
    view,
  });
  const showNicknameSetup = shouldShowNicknameSetup({
    currentUserId,
    hasValidProfile,
    view,
    shownWaiting,
  });

  // 테마 FAB: 프로필 설정 완료 후 메인에서만 (입장/대기/닉네임 화면 숨김)
  useEffect(() => {
    const ready = Boolean(
      currentUserId
      && hasValidProfile
      && profileBoot === 'ok'
      && !showWaiting
      && !showNicknameSetup,
    );
    if (ready) document.body.dataset.appReady = '1';
    else delete document.body.dataset.appReady;
    return () => { delete document.body.dataset.appReady; };
  }, [currentUserId, hasValidProfile, profileBoot, showWaiting, showNicknameSetup]);

  // 하트 확인 모달: MY FAB가 모바일에서 터치를 가로채지 않도록 overlay 표시
  useEffect(() => {
    if (!likeConfirmTarget) return;
    document.body.dataset.overlay = 'like-confirm';
    return () => { delete document.body.dataset.overlay; };
  }, [likeConfirmTarget]);

  const entryGate = renderAppEntryGates({
    appLoading,
    sessionActive,
    eventCycleStartedAt: cycleMeta.startedAt,
    eventCycleResetComplete: cycleMeta.resetComplete,
    showWaiting,
    showRecovery,
    showNicknameSetup,
    currentUserId,
    hasValidProfile,
    profileBoot,
    view,
    loading,
    registrationError,
    onRetryProfile: () => {
      const restored=ls.getItem(MATCHING_USER_KEY);
      if(restored){setCurrentUserId(restored);setProfileBoot("checking");setView("loading-main");}
      else if(!ls.isReadUnavailable()){setProfileBoot("register");setView("entry-1");}
      void loadProfilesRef.current().catch(()=>{});
    },
    onWaitingEnter: () => { setMainTab('profiles'); setShownWaiting(true); },
    onRecover: handleProfileRecovery,
    onRecoveryBackToRegister: () => { setProfileBoot('register'); setView('entry-1'); },
    onRecoveryBackToEntry: () => setView('entry-1'),
    onNicknameSubmit: handleNicknameSetup,
    onReset: reset,
    onShowRecovery: () => setView('entry-recover'),
  });
  if (entryGate) return entryGate;

    const isSubScreen = view === 'profile' || view === 'chat' || view === 'group-chat';

  return (
    <ParticipantNavProvider nav={participantNav}>
      <RainbowUnlockGuide userId={currentUserId} now={scheduleNow}
        available={view === 'main' && profileBoot === 'ok' && moduleFlags.hearts && !functionsLocked
          && participantHearts.unlocked.has('rainbow') && !showTutorialModal && !likeConfirmTarget
          && !showResetPassword && !contactShareTarget && !showContactQr && !showQrScanner}
        remaining={participantHearts.rainbowRemaining} dark={darkMode} />
      <AppOverlays
        isSubScreen={isSubScreen}
        mainTab={mainTab}
        showTutorialModal={showTutorialModal}
        setShowTutorialModal={setShowTutorialModal}
        activeNotif={activeNotif}
        setActiveNotif={setActiveNotif}
        showResetPassword={showResetPassword}
        setShowResetPassword={setShowResetPassword}
        likeConfirmTarget={likeConfirmTarget}
        setLikeConfirmTarget={setLikeConfirmTarget}
        contactShareTarget={contactShareTarget}
        setContactShareTarget={setContactShareTarget}
        contactViewShare={contactViewShare}
        setContactViewShare={setContactViewShare}
        showContactQr={showContactQr}
        setShowContactQr={setShowContactQr}
        showQrScanner={showQrScanner}
        setShowQrScanner={setShowQrScanner}
        scannedContactProfile={scannedContactProfile}
        setScannedContactProfile={setScannedContactProfile}
        fortuneModalTarget={fortuneModalTarget}
        setFortuneModalTarget={setFortuneModalTarget}
        connStatus={connStatus}
        onReconnectRetry={() => {
          resetNetUiForRetry();
          const uid = userIdRef.current;
          if (uid) {
            fetchAndSetSseToken(uid).catch(() => {});
            loadChatListRef.current?.(uid).catch(() => {});
            loadReceivedLikesRef.current?.(uid).catch(() => {});
            loadLikesRef.current?.(uid).catch(() => {});
            loadContactShareDataRef.current?.(uid).catch(() => {});
            loadGroupChatsRef.current?.(uid).catch(() => {});
            loadProfilesRef.current().catch(() => {});
          } else {
            window.location.reload();
          }
        }}
        rejectionNotif={rejectionNotif}
        setRejectionNotif={setRejectionNotif}
        functionsLockToast={functionsLockToast}
        bottomNotif={bottomNotif}
        setBottomNotif={setBottomNotif}
        setMySubTabHint={setMySubTabHint}
        handleMainTabChange={handleMainTabChange}
        coachReplayToken={coachReplayToken}
        onForceCoachParticipants={forceCoachParticipants}
        onNavigateCoachTab={navigateCoachTab}
        profiles={profiles}
        receivedLikers={receivedLikers}
        setSelectedProfile={setSelectedProfile}
        setView={setView}
        openChatGuarded={openChatGuarded}
        reset={reset}
        view={view}
        selectedProfile={selectedProfile}
        currentUserId={currentUserId}
        likedIds={likedIds}
        sentHeartTypes={sentHeartTypes}
        sentHeartsPerPerson={sentHeartsPerPerson}
        receivedHeartTypes={receivedHeartTypes}
        functionsLocked={functionsLocked}
        userSignals={userSignals}
        handleLike={handleLike}
        goParticipantBack={goParticipantBack}
        showFunctionsLockToast={showFunctionsLockToast}
        activeGroupId={activeGroupId}
        groupChats={groupChats}
        groupMessages={groupMessages}
        groupParticipants={groupParticipants}
        profileMap={profileMap}
        darkMode={darkMode}
        sendGroupMessageGuarded={sendGroupMessageGuarded}
        leaveGroupChatGuarded={leaveGroupChatGuarded}
        chatId={chatId}
        setChatId={setChatId}
        chatIdRef={chatIdRef}
        messages={messages}
        sendMessageGuarded={sendMessageGuarded}
        sendImageGuarded={sendImageGuarded}
        deleteMessage={deleteMessage}
        hasMoreOlderMessages={hasMoreOlderMessages}
        loadingOlderMessages={loadingOlderMessages}
        loadOlderMessages={loadOlderMessages}
        receivedContactShares={receivedContactShares}
        contactSharedWithIds={contactSharedWithIds}
        setProfiles={setProfiles}
        chatDraftRef={chatDraftRef}
        getHeartUsage={getHeartUsage}
        execLikeGuarded={execLikeGuarded}
        showConfetti={showConfetti}
        shareEventNotif={shareEventNotif}
        setShareEventNotif={setShareEventNotif}
        handleContactShareGuarded={handleContactShareGuarded}
        saveScannedContact={saveScannedContact}
        privacyProfileIds={privacyProfileIds}
        heartOpsConfig={heartOpsConfig}
        participantHeartsLocked={participantHearts.heartsLocked}
        moduleFlags={moduleFlags}
      >
        <AppMainShell
          isSubScreen={isSubScreen}
          onBoundaryReset={() => { setView('main'); setMainTab('profiles'); }}
          profiles={profiles}
          currentUserId={currentUserId}
          likedIds={likedIds}
          sentHeartsPerPerson={sentHeartsPerPerson}
          likeStatuses={likeStatuses}
          profileMap={profileMap}
          mainTab={mainTab}
          onTabChange={handleMainTabChange}
          onReplayCoach={replayCoach}
          onLike={handleLikeGuarded}
          onSelect={handleSelectProfile}
          onReset={reset}
          onOpenResetPassword={() => setShowResetPassword(true)}
          receivedLikers={receivedLikers}
          receivedHeartTypes={receivedHeartTypes}
          sentHeartTypes={sentHeartTypes}
          sentLikedProfiles={sentLikedProfiles}
          contactSharedWithIds={contactSharedWithIds}
          acknowledgedComplimentIds={acknowledgedComplimentIds}
          receivedContactShares={receivedContactShares}
          pendingHeartsCount={pendingHeartsCount}
          chatList={chatList}
          onContactShareOpen={handleContactShareOpen}
          onContactViewOpen={handleContactViewOpen}
          onHeartResponse={handleHeartResponseGuarded}
          onDeleteChat={deleteChat}
          onDeleteAllChats={deleteAllChats}
          onOpenChat={openChatGuarded}
          timerEndAt={timerEndAt}
          timerLabel={timerLabel}
          heartOpsConfig={heartOpsConfig}
          heartUsage={heartUsage}
          eventScheduleRaw={eventScheduleRaw}
          eventCycleStartedAt={cycleMeta.startedAt}
          eventCycleResetComplete={cycleMeta.resetComplete}
          onRefreshStatus={refreshStatusTab}
          onRefreshChat={refreshChatTab}
          onUpdateProfile={handleUpdateProfile}
          onRefreshProfiles={refreshProfilesTab}
          darkMode={darkMode}
          onToggleDark={handleToggleDark}
          scannedContacts={scannedContacts}
          onClearScannedContact={handleClearScannedContact}
          functionsLocked={functionsLocked}
          onShowTutorial={handleShowTutorial}
          unreadChatCounts={unreadChatCounts}
          onClearChatUnread={handleClearChatUnread}
          onViewFortune={handleViewFortuneFromCard}
          onViewProfile={handleViewProfileCard}
          groupChats={groupChats}
          unreadGroupCounts={unreadGroupCounts}
          onOpenGroupChat={handleMainOpenGroupChat}
          onJoinGroupChat={handleMainJoinGroupChat}
          onLeaveGroupChat={handleMainLeaveGroupChat}
          joiningGroupId={joiningGroupId}
          userSignals={userSignals}
          onUserSignalUpdate={handleUserSignalUpdate}
          mySubTabHint={mySubTabHint}
          onMySubTabHintConsumed={() => setMySubTabHint(null)}
          blockedUserIds={privacyProfileIds.blockedUserIds}
          hiddenByIds={privacyProfileIds.hiddenByIds}
          profileVisitors={profileVisitors}
          newVisitCount={newVisitCount}
          onClearVisitCount={() => setNewVisitCount(0)}
          onBlock={handleBlock}
          myBlockList={blockedUsers.filter(b => b.user_id === currentUserId)}
          onUnblock={handleUnblock}
          moduleFlags={moduleFlags}
        />
      </AppOverlays>
    </ParticipantNavProvider>
  );
}



// ─── Profile Detail ───────────────────────────────────────────────────────────


export default App;
