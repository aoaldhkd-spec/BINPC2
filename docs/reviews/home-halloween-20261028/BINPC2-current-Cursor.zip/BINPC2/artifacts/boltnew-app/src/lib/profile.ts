// ─── 프로필 관련 공유 헬퍼 ────────────────────────────────────────────────────
// App.tsx, AdminApp.tsx, StatsTabs.tsx 등에 흩어져 있던
// 동일한 함수들을 이 파일 하나에 통합했습니다.

// ─── 포지션 (탑/바텀) ────────────────────────────────────────────────────────
export function getPositionLabel(score: number): string {
  if (score < 0)   return '비선호';
  if (score <= 0)  return '개바텀';
  if (score <= 24) return '바텀';
  if (score <= 49) return '올텀';
  if (score === 50) return '올';
  if (score <= 64) return '탑에 가까운 올';
  if (score <= 89) return '올탑';
  if (score <= 98) return '탑';
  return '퓨어탑';
}

export function getPositionBg(score: number): string {
  if (score < 0)   return '#6b7280';
  if (score <= 0)  return '#15803d';
  if (score <= 24) return '#22c55e';
  if (score <= 49) return '#84cc16';
  if (score <= 55) return '#eab308';
  if (score <= 75) return '#f59e0b';
  if (score <= 89) return '#3b82f6';
  if (score <= 98) return '#2563eb';
  return '#1d4ed8';
}

// ─── 포지션 배지 스타일 (파스텔 — 가독성 개선) ───────────────────────────────
export function getPositionStyle(score: number): { bg: string; text: string; border: string } {
  if (score < 0)   return { bg: '#f3f4f6', text: '#374151', border: '#d1d5db' };
  if (score <= 24) return { bg: '#f0fdf4', text: '#15803d', border: '#86efac' };   // green
  if (score <= 49) return { bg: '#f7fee7', text: '#4d7c0f', border: '#bef264' };   // lime
  if (score <= 55) return { bg: '#fefce8', text: '#a16207', border: '#fde68a' };   // yellow
  if (score <= 75) return { bg: '#fff7ed', text: '#c2410c', border: '#fed7aa' };   // orange
  if (score <= 89) return { bg: '#eff6ff', text: '#1d4ed8', border: '#bfdbfe' };   // blue
  if (score <= 98) return { bg: '#eef2ff', text: '#3730a3', border: '#c7d2fe' };   // indigo
  return           { bg: '#f5f3ff', text: '#6d28d9', border: '#ddd6fe' };           // violet
}

// ─── 나이 계산 ────────────────────────────────────────────────────────────────
export { formatKoreanAge as getKoreanAge } from './korean-age';

import { AVATAR_COLOR_COUNT } from './avatar-color-catalog';
import { genNpcTextAvatar, isNpcTextAvatar } from './npc-text-avatar';

export { isNpcTextAvatar, genNpcTextAvatar, NPC_TEXT_AVATAR_SENTINEL, NPC_TEXT_AVATAR_LABEL } from './npc-text-avatar';

// ─── 아바타 SVG 생성 ─────────────────────────────────────────────────────────
/** 닉네임 전체를 해시 — 첫 글자만 쓰면 한글 닉네임이 주황색에 몰림 */
function avatarPaletteIndex(nickname: string): number {
  let h = 0;
  for (let i = 0; i < nickname.length; i++) {
    h = ((h << 5) - h + nickname.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

/** 부드러운 파스텔 그라디언트 (닉네임별로 다양하게 분산, 텍스트 없음) */
export const AVATAR_PALETTE: Array<{ from: string; to: string }> = [
  { from: '#dbeafe', to: '#bfdbfe' },
  { from: '#cffafe', to: '#a5f3fc' },
  { from: '#d1fae5', to: '#a7f3d0' },
  { from: '#ecfccb', to: '#d9f99d' },
  { from: '#fef3c7', to: '#fde68a' },
  { from: '#fce7f3', to: '#fbcfe8' },
  { from: '#ede9fe', to: '#ddd6fe' },
  { from: '#ffe4e6', to: '#fecdd3' },
  { from: '#e0e7ff', to: '#c7d2fe' },
  { from: '#ccfbf1', to: '#99f6e4' },
  { from: '#fae8ff', to: '#f5d0fe' },
  { from: '#ffedd5', to: '#fed7aa' },
];

export type AvatarColorProfile = {
  nickname: string;
  avatar_color?: number | null;
};

function isAvatarColorIndex(value: unknown): value is number {
  return typeof value === 'number'
    && Number.isInteger(value)
    && value >= 0
    && value < AVATAR_COLOR_COUNT;
}

/** 사용자 지정 색 또는 닉네임 해시 기본값 */
export function resolveAvatarColorIndex(profile: AvatarColorProfile): number {
  if (isAvatarColorIndex(profile.avatar_color)) return profile.avatar_color;
  const nick = profile.nickname.trim() || '?';
  return avatarPaletteIndex(nick) % AVATAR_PALETTE.length;
}

function getAvatarGradientForProfile(profile: AvatarColorProfile): { from: string; to: string } {
  return AVATAR_PALETTE[resolveAvatarColorIndex(profile)];
}

export function getAvatarGradientCssForProfile(profile: AvatarColorProfile): string {
  const { from, to } = getAvatarGradientForProfile(profile);
  return `linear-gradient(135deg, ${from} 0%, ${to} 100%)`;
}

/** 실제 업로드·프리셋 webp·NPC 텍스트 아바타만 사진으로 취급 — null/dicebear/구형 SVG → genAvatar */
export function hasUploadedPhoto(url: string | null | undefined): boolean {
  if (!url || !url.trim()) return false;
  if (isNpcTextAvatar(url)) return true;
  if (url.includes('dicebear')) return false;
  if (url.startsWith('data:image/svg')) return false;
  return true;
}

/** Bundled square WebP preset. Large non-square views should contain, not crop, it. */
export function isPresetAvatar(url: string | null | undefined): boolean {
  if (!url) return false;
  return /(?:^|\/)avatars\/av\d+\.webp(?:[?#]|$)/i.test(url);
}

export function getAvatarGradient(nickname: string, colorIndex?: number | null): { from: string; to: string } {
  return getAvatarGradientForProfile({ nickname, avatar_color: colorIndex ?? undefined });
}


export function getAvatarSrc(
  url: string | null | undefined,
  nick: string,
  cacheBust?: string | number,
  colorIndex?: number | null,
): string {
  if (isNpcTextAvatar(url)) return genNpcTextAvatar();
  if (!hasUploadedPhoto(url)) return genAvatar(nick, colorIndex);
  const src = url!;
  if (
    cacheBust == null ||
    !src.includes('/api/db/storage-image') ||
    src.startsWith('data:')
  ) {
    return src;
  }
  return `${src}${src.includes('?') ? '&' : '?'}v=${encodeURIComponent(String(cacheBust))}`;
}

/** Playwright smoke marker from scripts/verify-chat-gestures.mjs — never show in the live deck. */
export const SWIPE_GESTURE_VERIFY_MARKER = 'swipe-gesture-verify';

function normalizeFixtureText(value: unknown): string {
  if (value == null) return '';
  if (Array.isArray(value)) return value.map(normalizeFixtureText).join('\n');
  if (typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).map(normalizeFixtureText).join('\n');
  }
  // ProfileCard / ProfileDetail prefix `#` onto bio·interest tags — strip it before matching.
  return String(value).toLowerCase().replace(/#/g, '').trim();
}

function collectRenderableProfileText(p: object): string {
  const rec = p as Record<string, unknown>;
  const named = [
    rec.bio,
    rec.nickname,
    rec.interests,
    rec.display_name,
    rec.displayName,
    rec.name,
    rec.status_msg,
    rec.status_message,
    rec.tagline,
  ];
  const parts = named.map(normalizeFixtureText);
  for (const [key, val] of Object.entries(rec)) {
    if (key === 'id' || key === 'photo_url' || key === 'created_at' || key === '_device_secret') continue;
    if (typeof val === 'string' || Array.isArray(val)) parts.push(normalizeFixtureText(val));
  }
  return parts.join('\n');
}

export function isSwipeGestureVerifyProfile(p: {
  bio?: string | null;
  interests?: string | string[] | null;
  nickname?: string | null;
  display_name?: string | null;
  name?: string | null;
  status_msg?: string | null;
} | null | undefined): boolean {
  if (!p) return false;
  const blob = collectRenderableProfileText(p);
  if (blob.includes(SWIPE_GESTURE_VERIFY_MARKER)) return true;
  return blob.split(/[\s,，、]+/).some((token) => token === SWIPE_GESTURE_VERIFY_MARKER);
}

/** True only when bio or nickname is exactly the smoke marker (optional leading #). Safe for admin delete. */
export function isExactSwipeGestureVerifyFixture(p: {
  bio?: string | null;
  nickname?: string | null;
  interests?: string | string[] | null;
}): boolean {
  const fields = [p.bio, p.nickname, ...(Array.isArray(p.interests) ? p.interests : [p.interests])];
  return fields.some((field) => normalizeFixtureText(field) === SWIPE_GESTURE_VERIFY_MARKER);
}

/** Drop leftover swipe-gesture fixtures. Keep `keepId` so a smoke-test session still has its own row. */
export function excludeSwipeGestureVerifyProfiles<T extends {
  id?: string;
  bio?: string | null;
  interests?: string | string[] | null;
  nickname?: string | null;
}>(list: T[], keepId?: string | null): T[] {
  return list.filter((p) => {
    if (!isSwipeGestureVerifyProfile(p)) return true;
    return Boolean(keepId && p.id === keepId);
  });
}

/** Card/menu gate: year alone enables 12지신·오행; MBTI enables personality compat. */
export function hasProfileFortuneCompatData(p: {
  birth_year?: number | null;
  birth_month?: number | null;
  birth_day?: number | null;
  mbti?: string | null;
} | null | undefined): boolean {
  if (!p) return false;
  if (p.birth_year != null && p.birth_year > 0) return true;
  return Boolean(p.mbti?.trim());
}

export function genAvatar(nickname: string, colorIndex?: number | null): string {
  const nick = nickname.trim() || '?';
  const { from, to } = getAvatarGradient(nick, colorIndex);
  // 1:1 SVG — ProfileCard uses full-bleed cover/pastel on the photo frame
  const svg = [
    '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">',
    `<defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">`,
    `<stop offset="0%" stop-color="${from}"/><stop offset="100%" stop-color="${to}"/></linearGradient></defs>`,
    '<rect width="400" height="400" fill="url(#g)"/>',
    '</svg>',
  ].join('');
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
