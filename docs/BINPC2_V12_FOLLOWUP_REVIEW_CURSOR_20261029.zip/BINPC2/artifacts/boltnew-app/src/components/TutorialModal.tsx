import React, { useState, useEffect } from 'react';
import { X, ArrowLeft, ArrowRight, PlayCircle, Sparkles } from 'lucide-react';
import { TutorialVideo } from './TutorialVideo';
import { DEFAULT_MODULE_FLAGS, type ModuleFlags } from '../lib/module-flags';

type Tip = { icon: string; title: string; desc: string };
type Section = { emoji: string; title: string; tips: Tip[]; footer?: string; variant?: 'rules' | 'tabs' | 'default' };
type FillerKind = 'guide' | 'chat' | 'group' | 'pin' | 'hidden' | 'heart';

type Topic = {
  id: string;
  emoji: string;
  label: string;
  title: string;
  color: string;
  tips: Tip[];
  video?: number[];
  videoHint?: string;
  sections?: Section[];
  footer?: string;
  filler?: FillerKind;
};

const BASIC: Topic[] = [
  {
    id: 'guide',
    emoji: '📋',
    label: '안내',
    title: '오늘만 이 정도는 지켜줘',
    color: 'from-teal-500 to-cyan-600',
    tips: [],
    filler: 'guide',
    sections: [
      {
        emoji: '📌',
        title: '오늘의 규칙',
        variant: 'rules',
        tips: [
          { icon: '🍺', title: '술 강요 없음', desc: '마시고 싶은 만큼만.' },
          { icon: '🗳️', title: '정치·종교', desc: '토크 패스. 영구밴.' },
          { icon: '🚫', title: '지역·패드립', desc: '바로 영구밴.' },
          { icon: '🗣️', title: '욕설·반말', desc: '존댓말로. 영구밴.' },
        ],
      },
      {
        emoji: '🗂️',
        title: '탭 안내',
        variant: 'tabs',
        tips: [
          { icon: '👥', title: '참여자', desc: '오늘 온 사람 카드.' },
          { icon: '💝', title: '하트, 채팅', desc: '내 상태·내 채팅.' },
          { icon: '📊', title: '통계', desc: '하트 수·비율.' },
          { icon: '🏆', title: '랭킹', desc: 'TOP 10.' },
          { icon: '⚙️', title: '설정', desc: '프로필·생월생일.' },
        ],
      },
    ],
  },
  {
    id: 'heart',
    emoji: '❤️',
    label: '하트',
    title: '하트 보내기',
    color: 'from-pink-500 to-rose-500',
    video: [6, 7, 8],
    videoHint: '받기 · 보내기 · 무지개하트',
    tips: [
      { icon: '🤍', title: '보내고 확인', desc: '참여자 카드 아래 하트로 보내고, 하트, 채팅 → 내 상태에서 확인.' },
      { icon: '❤️', title: '일반 하트 4종', desc: '❤️호감 💙친구 💗뜨밤 💚칭찬. 종류마다 딱 한 번 보낼 수 있어요.' },
      { icon: '🔒', title: '시간마다 해금', desc: '잠긴 하트는 정해진 시간에 열려요. 다음 해금 시간과 남은 시간은 화면 위 안내줄에.' },
      { icon: '🌈', title: '무지개는 4번', desc: '해금되면 4번. 누르면 위 4종 중 하나를 골라 보내고, 일반 하트는 줄지 않아요.' },
    ],
  },
  {
    id: 'settings',
    emoji: '⚙️',
    label: '설정',
    title: '설정 · 프로필',
    color: 'from-cyan-500 to-sky-600',
    video: [1, 2],
    videoHint: '아바타 · 한마디 · 이상형 칩',
    tips: [
      { icon: '🔑', title: '고유번호', desc: '맨 위 4자리. 폰 바꾸면 복구.' },
      { icon: '📷', title: '사진·아바타', desc: '업로드 또는 기본 아바타.' },
      { icon: '🏷️', title: '닉네임', desc: '2~6글자. 1회만 변경.' },
      { icon: '🎯', title: '관심사', desc: '2~5개. 프로필 카드에 표시.' },
      { icon: '📋', title: '연락처', desc: '카톡·인스타·전화. 수락 시 전달.' },
      { icon: '🔮', title: '생월·생일', desc: '월·일. 2회만 변경. 사주·궁합 반영.' },
      { icon: '💬', title: '한마디', desc: '⚡ 빠른 선택·직접 입력. 전광판.' },
      { icon: '💘', title: '이상형', desc: '얼굴·체형·매력·성격 칩.' },
      { icon: '🌟', title: '내 특징', desc: '대분류 → 소분류 → 태그 순서로 선택.' },
      { icon: '❔', title: '도움말·화면 설정', desc: '튜토리얼 다시 보기 · 다크 모드.' },
      { icon: '🚫', title: '차단', desc: '차단 시 서로 프로필·채팅 불가.' },
    ],
  },
  {
    id: 'chat',
    emoji: '💬',
    label: '채팅',
    title: '채팅, 이렇게만 알면 됨',
    color: 'from-blue-500 to-indigo-500',
    video: [3, 4, 5],
    videoHint: '이모지·스티커 · 사진 · 스와이프 답장',
    tips: [
      { icon: '💬', title: '여는 곳', desc: '하트, 채팅 → 내 채팅 · 단톡은 옆' },
      { icon: '😊', title: '이모지', desc: '입력줄 옆 😊에 붙여 넣음' },
      { icon: '🎨', title: '스티커', desc: '+ 다음 🎨 · 이모지와 다름' },
      { icon: '📷', title: '사진', desc: '+ 다음 이미지로 전송' },
      { icon: '⚡', title: '빠른 메시지', desc: '+ 다음 ⚡ 한 줄 전송' },
      { icon: '📱', title: '연락처·궁합', desc: '위 공유 · 🔮 궁합' },
      { icon: '👉', title: '스와이프 답장', desc: '옆으로 밀면 그 말 답장' },
      { icon: '👆', title: '길게 누르기', desc: '길게 → 답장·복사·삭제' },
    ],
  },
  {
    id: 'group',
    emoji: '👥',
    label: '단톡',
    title: '단톡, 두 방은 자동',
    color: 'from-teal-500 to-emerald-600',
    filler: 'group',
    tips: [
      { icon: '📍', title: '여는 곳', desc: '하트, 채팅 → 내 채팅 → 단체 채팅' },
      { icon: '✨', title: '자동 입장', desc: '년생 모임 · N대 모임, 두 방' },
      { icon: '🚪', title: '2차', desc: '술·클럽 각 1방. 나가기·입장 자유' },
      { icon: '4️⃣', title: '한도', desc: '자동 2 + 2차 2 · 정원 무제한' },
    ],
  },
];

export function tutorialBasicTopics(moduleFlags: ModuleFlags = DEFAULT_MODULE_FLAGS): Topic[] {
  return BASIC
    .filter((topic) => {
      if (topic.id === 'heart') return moduleFlags.hearts;
      if (topic.id === 'chat') return moduleFlags.direct_chat;
      if (topic.id === 'group') return moduleFlags.group_chat;
      return true;
    })
    .map((topic) => {
      if (topic.id !== 'guide') return topic;
      return {
        ...topic,
        sections: topic.sections?.map((section) => (
          section.variant !== 'tabs'
            ? section
            : {
                ...section,
                tips: section.tips.filter((tip) => (
                  (tip.title !== '통계' || moduleFlags.stats)
                  && (tip.title !== '랭킹' || moduleFlags.ranking)
                )),
              }
        )),
      };
    });
}

const HIDDEN: Topic[] = [
  {
    id: 'pin',
    emoji: '🔑',
    label: '고유번호',
    title: '고유번호 캡처 필수',
    color: 'from-amber-500 to-orange-500',
    filler: 'pin',
    tips: [
      { icon: '📍', title: '어디에', desc: '설정 탭 맨 위 4자리. 입장 핀이랑 다름.' },
      { icon: '📱', title: '폰 바꿈', desc: '다시 만들지 마. 이 번호로 복구.' },
    ],
    footer: '입장 핀이랑 고유번호는 다른 거예요',
  },
  {
    id: 'hidden',
    emoji: '✨',
    label: '숨은기능',
    title: '몰라도 되는데 알면 이득',
    color: 'from-violet-500 to-purple-600',
    filler: 'hidden',
    tips: [
      { icon: '🔄', title: '카드 뒤집기', desc: '사진 탭하면 뒷면에 이상형.' },
      { icon: '👁', title: '방문자', desc: '하트, 채팅 → 내 상태. 목록만, 알림 없음.' },
      { icon: '🚫', title: '차단·숨기기', desc: '차단은 서로. 👻는 상대만 못 봄.' },
    ],
  },
];

const KR_WRAP = 'break-keep [word-break:keep-all] [line-break:strict] [overflow-wrap:break-word] text-pretty';

/** Fixed shell — identical height on every topic/mode (tips + video). No inner scroll. */
const MODAL_SHELL =
  'w-[min(28rem,calc(100vw-2rem))] max-w-md h-[min(560px,calc(85dvh-var(--safe-top,0px)-var(--safe-bottom,0px)))]';

/** One tip-card size on every topic so the densest page still fits without scrolling. */
const TIP_BOX = 'h-[2.75rem] items-center';
/** 안내 탭은 2섹션(9칸). 한 줄짜리 설명만 있어 축소해도 안전. */
const TIP_BOX_DENSE = 'h-[2.25rem] items-center';

type TopicAccent = {
  cardLight: string;
  cardDark: string;
  iconLight: string;
  iconDark: string;
  bar: string;
  chipIdle: string;
  chipIdleDark: string;
};

const TOPIC_ACCENTS: Record<string, TopicAccent> = {
  guide: {
    cardLight: 'bg-gradient-to-br from-teal-50/90 to-cyan-50/60 border-teal-100/80 shadow-[0_1px_2px_rgba(13,148,136,0.08)]',
    cardDark: 'bg-gradient-to-br from-teal-950/40 to-slate-800/80 border-teal-800/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-teal-500 to-cyan-600 shadow-sm shadow-teal-300/50',
    iconDark: 'bg-gradient-to-br from-teal-600 to-cyan-700 shadow-sm shadow-teal-900/40',
    bar: 'from-teal-400 to-cyan-500',
    chipIdle: 'bg-teal-50/60 border-teal-100/60 text-teal-700/70',
    chipIdleDark: 'bg-teal-950/30 border-teal-900/40 text-teal-300/70',
  },
  heart: {
    cardLight: 'bg-gradient-to-br from-rose-50/90 to-pink-50/60 border-rose-100/80 shadow-[0_1px_2px_rgba(244,63,94,0.08)]',
    cardDark: 'bg-gradient-to-br from-rose-950/40 to-slate-800/80 border-rose-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-pink-500 to-rose-500 shadow-sm shadow-rose-300/50',
    iconDark: 'bg-gradient-to-br from-pink-600 to-rose-600 shadow-sm shadow-rose-900/40',
    bar: 'from-pink-400 to-rose-500',
    chipIdle: 'bg-rose-50/60 border-rose-100/60 text-rose-700/70',
    chipIdleDark: 'bg-rose-950/30 border-rose-900/40 text-rose-300/70',
  },
  settings: {
    cardLight: 'bg-gradient-to-br from-sky-50/90 to-cyan-50/60 border-sky-100/80 shadow-[0_1px_2px_rgba(14,165,233,0.08)]',
    cardDark: 'bg-gradient-to-br from-sky-950/40 to-slate-800/80 border-sky-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-cyan-500 to-sky-600 shadow-sm shadow-cyan-300/50',
    iconDark: 'bg-gradient-to-br from-cyan-600 to-sky-700 shadow-sm shadow-cyan-900/40',
    bar: 'from-cyan-400 to-sky-500',
    chipIdle: 'bg-sky-50/60 border-sky-100/60 text-sky-700/70',
    chipIdleDark: 'bg-sky-950/30 border-sky-900/40 text-sky-300/70',
  },
  chat: {
    cardLight: 'bg-gradient-to-br from-indigo-50/90 to-blue-50/60 border-indigo-100/80 shadow-[0_1px_2px_rgba(99,102,241,0.08)]',
    cardDark: 'bg-gradient-to-br from-indigo-950/40 to-slate-800/80 border-indigo-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-blue-500 to-indigo-500 shadow-sm shadow-indigo-300/50',
    iconDark: 'bg-gradient-to-br from-blue-600 to-indigo-600 shadow-sm shadow-indigo-900/40',
    bar: 'from-blue-400 to-indigo-500',
    chipIdle: 'bg-indigo-50/60 border-indigo-100/60 text-indigo-700/70',
    chipIdleDark: 'bg-indigo-950/30 border-indigo-900/40 text-indigo-300/70',
  },
  group: {
    cardLight: 'bg-gradient-to-br from-emerald-50/90 to-teal-50/60 border-emerald-100/80 shadow-[0_1px_2px_rgba(16,185,129,0.08)]',
    cardDark: 'bg-gradient-to-br from-emerald-950/40 to-slate-800/80 border-emerald-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-teal-500 to-emerald-600 shadow-sm shadow-emerald-300/50',
    iconDark: 'bg-gradient-to-br from-teal-600 to-emerald-700 shadow-sm shadow-emerald-900/40',
    bar: 'from-teal-400 to-emerald-500',
    chipIdle: 'bg-emerald-50/60 border-emerald-100/60 text-emerald-700/70',
    chipIdleDark: 'bg-emerald-950/30 border-emerald-900/40 text-emerald-300/70',
  },
  pin: {
    cardLight: 'bg-gradient-to-br from-amber-50/90 to-orange-50/60 border-amber-100/80 shadow-[0_1px_2px_rgba(245,158,11,0.08)]',
    cardDark: 'bg-gradient-to-br from-amber-950/40 to-slate-800/80 border-amber-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-amber-500 to-orange-500 shadow-sm shadow-amber-300/50',
    iconDark: 'bg-gradient-to-br from-amber-600 to-orange-600 shadow-sm shadow-amber-900/40',
    bar: 'from-amber-400 to-orange-500',
    chipIdle: 'bg-amber-50/60 border-amber-100/60 text-amber-700/70',
    chipIdleDark: 'bg-amber-950/30 border-amber-900/40 text-amber-300/70',
  },
  hidden: {
    cardLight: 'bg-gradient-to-br from-violet-50/90 to-purple-50/60 border-violet-100/80 shadow-[0_1px_2px_rgba(139,92,246,0.08)]',
    cardDark: 'bg-gradient-to-br from-violet-950/40 to-slate-800/80 border-violet-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
    iconLight: 'bg-gradient-to-br from-violet-500 to-purple-600 shadow-sm shadow-violet-300/50',
    iconDark: 'bg-gradient-to-br from-violet-600 to-purple-700 shadow-sm shadow-violet-900/40',
    bar: 'from-violet-400 to-purple-500',
    chipIdle: 'bg-violet-50/60 border-violet-100/60 text-violet-700/70',
    chipIdleDark: 'bg-violet-950/30 border-violet-900/40 text-violet-300/70',
  },
};

const SECTION_VARIANTS: Record<'rules' | 'tabs' | 'default', { bar: string; headerLight: string; headerDark: string }> = {
  rules: {
    bar: 'from-rose-400 to-amber-400',
    headerLight: 'text-rose-700 bg-rose-50/80 border-rose-100',
    headerDark: 'text-rose-200 bg-rose-950/40 border-rose-900/50',
  },
  tabs: {
    bar: 'from-teal-400 to-cyan-500',
    headerLight: 'text-teal-700 bg-teal-50/80 border-teal-100',
    headerDark: 'text-teal-200 bg-teal-950/40 border-teal-900/50',
  },
  default: {
    bar: 'from-slate-300 to-slate-400',
    headerLight: 'text-slate-700 bg-slate-50/80 border-slate-100',
    headerDark: 'text-slate-200 bg-slate-800/60 border-slate-700',
  },
};

function topicAccent(topic: Topic): TopicAccent {
  return TOPIC_ACCENTS[topic.id] ?? TOPIC_ACCENTS.guide;
}

function topicTipCount(topic: Topic): number {
  const sectionTips = (topic.sections ?? []).reduce((n, s) => n + s.tips.length, 0);
  return topic.tips.length + sectionTips;
}

function topicLayout(topic: Topic) {
  const count = topicTipCount(topic);
  // 하트 탭은 설명 한 줄이 길어 2열에서는 line-clamp로 잘린다. 카드 수가 적어 1열도 모달 안에 들어간다.
  const dense = topic.id === 'guide' || (count >= 4 && topic.id !== 'heart');
  const gapFill = topic.id === 'heart' || topic.id === 'chat' || topic.id === 'pin' || topic.id === 'group' || topic.id === 'hidden';
  return {
    twoColumn: dense,
    // 안내(9칸+푸터)·설정(11칸)은 행이 5~6줄이라 gap-1이면 360×640에서 마지막 줄이 잘린다.
    tightGap: topic.id === 'guide' || topic.id === 'settings',
    tipBox: topic.id === 'guide' ? TIP_BOX_DENSE : TIP_BOX,
    compact: true,
    fillVertical: false,
    fillerCompact: Boolean(topic.filler),
    scrollable: false,
    gapFill,
    gapFillKind: (topic.filler ?? (topic.id === 'heart' ? 'heart' : topic.id === 'chat' ? 'chat' : undefined)) as FillerKind | undefined,
  };
}

function TipCard({
  tip,
  accent,
  text,
  muted,
  darkMode,
  spanFull,
  compact: _compact,
  fill: _fill,
  sectionBar,
  longDesc,
  boxClass,
}: {
  tip: Tip;
  accent: TopicAccent;
  text: string;
  muted: string;
  darkMode?: boolean;
  spanFull?: boolean;
  compact?: boolean;
  fill?: boolean;
  sectionBar?: string;
  longDesc?: boolean;
  boxClass?: string;
}) {
  const desc = tip.desc.replace(/([.·])\s+/g, '$1\u200b ');
  const cardCls = darkMode ? accent.cardDark : accent.cardLight;
  const iconCls = darkMode ? accent.iconDark : accent.iconLight;
  const barCls = sectionBar ?? accent.bar;
  const iconShell = 'w-6 h-6 text-[11px] rounded-xl flex-shrink-0 flex items-center justify-center text-white ring-1 ring-white/25 ' + iconCls;
  const titleCls = 'text-[11px]';
  const descCls = longDesc ? 'text-[10px] leading-snug' : 'text-[10px] leading-snug';
  const pad = 'px-2 py-1';
  const stretchCls = boxClass ?? TIP_BOX;

  const body = (
    <div className="flex gap-1.5 min-w-0 flex-1 pl-1 items-center">
      <span className={iconShell}>{tip.icon}</span>
      <div className="min-w-0 flex-1">
        <p className={`${titleCls} font-bold leading-tight line-clamp-1 ${KR_WRAP} ${text}`}>{tip.title}</p>
        <p className={`${descCls} mt-px line-clamp-2 ${KR_WRAP} ${muted}`}>{desc}</p>
      </div>
    </div>
  );

  if (spanFull) {
    return (
      <div className={`relative col-span-2 flex rounded-xl border ${stretchCls} ${pad} ${cardCls}`}>
        <span className={`absolute left-0 top-2.5 bottom-2.5 w-0.5 rounded-full bg-gradient-to-b ${barCls}`} aria-hidden />
        {body}
      </div>
    );
  }

  return (
    <div className={`relative flex rounded-xl border ${stretchCls} ${pad} ${cardCls}`}>
      <span className={`absolute left-0 top-2.5 bottom-2.5 w-0.5 rounded-full bg-gradient-to-b ${barCls}`} aria-hidden />
      {body}
    </div>
  );
}

function TipGrid({
  tips,
  accent,
  text,
  muted,
  darkMode,
  twoColumn,
  compact,
  fill,
  sectionBar,
  longDescTitle,
  boxClass,
  tightGap,
}: {
  tips: Tip[];
  accent: TopicAccent;
  text: string;
  muted: string;
  darkMode?: boolean;
  twoColumn?: boolean;
  compact?: boolean;
  fill?: boolean;
  sectionBar?: string;
  longDescTitle?: string;
  boxClass?: string;
  tightGap?: boolean;
}) {
  const useTwoCol = twoColumn ?? tips.length >= 4;
  const oddLast = useTwoCol && tips.length % 2 === 1;
  const gap = tightGap ? 'gap-0.5' : 'gap-1';
  const stretchCls = fill ? 'flex-1 min-h-0 h-full' : '';

  if (!useTwoCol) {
    return (
      <div className={`flex flex-col ${gap} ${stretchCls}`}>
        {tips.map((tip) => (
          <TipCard
            key={tip.title}
            tip={tip}
            accent={accent}
            text={text}
            muted={muted}
            darkMode={darkMode}
            compact={compact}
            fill={fill}
            sectionBar={sectionBar}
            longDesc={longDescTitle === tip.title}
            boxClass={boxClass}
          />
        ))}
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-2 ${gap} auto-rows-fr ${stretchCls}`}>
      {tips.map((tip, i) => (
        <TipCard
          key={tip.title}
          tip={tip}
          accent={accent}
          text={text}
          muted={muted}
          darkMode={darkMode}
          compact={compact}
          fill={fill}
          sectionBar={sectionBar}
          spanFull={oddLast && i === tips.length - 1}
          longDesc={longDescTitle === tip.title}
          boxClass={boxClass}
        />
      ))}
    </div>
  );
}


/** Bottom gap filler for chat topic — full-width phone mock so the fixed tip box looks packed. */
function ChatPhoneMock({ darkMode }: { darkMode?: boolean }) {
  return (
    <div
      className={`flex-1 min-h-0 overflow-hidden flex items-stretch gap-2.5 px-2.5 py-2 rounded-2xl border ${
        darkMode
          ? 'bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 border-indigo-800/60'
          : 'bg-gradient-to-br from-indigo-50 via-sky-50 to-white border-indigo-100 shadow-sm shadow-indigo-100/40'
      }`}
      data-testid="tutorial-chat-phone-mock"
      aria-hidden
    >
      <div className="relative w-[5.25rem] flex-shrink-0 rounded-[1.1rem] border-[2.5px] overflow-hidden shadow-lg border-gray-300 bg-gray-100">
        <div className="h-full flex flex-col bg-gray-100">
          <div className="bg-white shadow-sm px-1 pt-1 pb-0.5">
            <div className="flex items-center gap-1">
              <span className="text-[7px] text-gray-700">←</span>
              <span className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 ring-1 ring-gray-200" />
              <p className="text-[6px] font-semibold text-gray-900 truncate">하늘다람쥐</p>
            </div>
            <div className="flex gap-0.5 mt-0.5">
              <span className="px-0.5 py-px bg-amber-50 text-amber-600 text-[4.5px] font-bold rounded border border-amber-200">사주</span>
              <span className="px-0.5 py-px bg-violet-50 text-violet-600 text-[4.5px] font-bold rounded border border-violet-200">궁합</span>
            </div>
          </div>
          <div className="flex-1 min-h-0 px-1 py-0.5 flex flex-col justify-end gap-1">
            <div className="flex justify-start">
              <span className="bg-white text-gray-900 text-[5.5px] font-semibold px-1.5 py-1 rounded-2xl rounded-bl-md shadow-sm max-w-[90%]">오늘 반가웠어요!</span>
            </div>
            <div className="flex justify-end">
              <span className="bg-cyan-500 text-white text-[5.5px] font-semibold px-1.5 py-1 rounded-2xl rounded-br-md">저도요 😊</span>
            </div>
          </div>
          <div className="bg-white border-t border-gray-200 px-0.5 py-0.5 flex items-center gap-0.5">
            <span className="w-3 h-3 rounded-full text-[6px] text-gray-400 flex items-center justify-center">+</span>
            <span className="w-3 h-3 rounded-full text-[7px] flex items-center justify-center">😊</span>
            <span className="flex-1 h-3 rounded-2xl border border-gray-300 bg-white" />
            <span className="w-3 h-3 rounded-full bg-cyan-500 text-[6px] text-white flex items-center justify-center">➤</span>
          </div>
        </div>
      </div>
      <div className="min-w-0 flex-1 flex flex-col justify-center gap-1 py-0.5">
        <p className={`font-black text-[11px] leading-snug ${darkMode ? 'text-white' : 'text-slate-800'}`}>
          실제 채팅 화면과 같아요
        </p>
        <p className={`text-[10px] font-semibold leading-snug line-clamp-2 ${darkMode ? 'text-indigo-200/90' : 'text-indigo-700/80'}`}>
          하트, 채팅 → 내 채팅 · 옆으로 밀면 답장
        </p>
        <div className="flex flex-wrap gap-1 mt-0.5">
          {['😊 이모지', '🎨 스티커', '⚡ 빠른말'].map((chip) => (
            <span
              key={chip}
              className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full border ${
                darkMode
                  ? 'border-indigo-700/70 bg-indigo-950/60 text-indigo-200'
                  : 'border-indigo-200 bg-white text-indigo-700 shadow-sm'
              }`}
            >
              {chip}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function FillerArt({ kind, darkMode }: { kind: FillerKind; darkMode?: boolean }) {
  // Compact square art — fill 모드에서 텍스트 옆 골짜기로 이모지가 새지 않게 아이콘 박스 안에 모은다.
  if (kind === 'heart') {
    return (
      <div className="relative h-12 w-12 mb-0 flex-shrink-0" aria-hidden>
        <div className={`absolute inset-0 rounded-2xl rotate-[-10deg] ${darkMode ? 'bg-rose-900/70' : 'bg-rose-100'}`} />
        <div className={`relative w-12 h-12 rounded-2xl flex items-center justify-center overflow-hidden ${darkMode ? 'bg-rose-950 ring-1 ring-rose-400/40' : 'bg-white ring-1 ring-rose-200'} shadow-md`}>
          <span className="text-[20px] leading-none">❤️</span>
        </div>
        <span className="absolute -top-1 -right-1 text-[11px] leading-none drop-shadow-sm">🌈</span>
        <span className="absolute -bottom-0.5 -left-1 text-[10px] leading-none drop-shadow-sm">💙</span>
      </div>
    );
  }
  if (kind === 'guide') {
    return (
      <div className="relative h-12 w-12 mb-0 flex-shrink-0" aria-hidden>
        <div className={`absolute inset-0 rounded-2xl rotate-[-8deg] ${darkMode ? 'bg-amber-900/40' : 'bg-amber-100/90'}`} />
        <div className={`relative w-12 h-12 rounded-2xl flex items-center justify-center overflow-hidden ${darkMode ? 'bg-slate-800 ring-1 ring-white/10' : 'bg-white ring-1 ring-teal-100'} shadow-md`}>
          <span className="text-[20px] leading-none">🥂</span>
        </div>
        <span className="absolute -top-1 -right-1 text-[10px] leading-none animate-pulse">✨</span>
        <span className="absolute -bottom-0.5 -left-1 text-[10px] leading-none">🌙</span>
      </div>
    );
  }
  if (kind === 'chat') {
    return (
      <div className="relative h-12 w-12 mb-0 flex-shrink-0" aria-hidden>
        <div className={`relative w-12 h-12 rounded-2xl flex flex-col items-center justify-center gap-0.5 overflow-hidden ${darkMode ? 'bg-indigo-950 ring-1 ring-indigo-400/40' : 'bg-white ring-1 ring-indigo-200'} shadow-md`}>
          <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${darkMode ? 'bg-slate-700 text-slate-200' : 'bg-slate-100 text-slate-600'}`}>안녕</span>
          <span className="text-[10px] leading-none">💌</span>
        </div>
        <span className="absolute -top-1 -right-1 text-[10px] leading-none">💭</span>
      </div>
    );
  }
  if (kind === 'group') {
    return (
      <div className="relative h-12 w-12 mb-0 flex-shrink-0" aria-hidden>
        <div className={`absolute inset-0 rounded-2xl rotate-[-10deg] ${darkMode ? 'bg-teal-900/70' : 'bg-teal-100/90'}`} />
        <div className={`relative w-12 h-12 rounded-2xl flex items-center justify-center overflow-hidden ${darkMode ? 'bg-emerald-950 ring-1 ring-emerald-400/40' : 'bg-white ring-1 ring-teal-200'} shadow-md`}>
          <span className="text-[18px] leading-none">👥</span>
        </div>
        <span className="absolute -top-1 -right-1 text-[10px] leading-none">🍻</span>
        <span className="absolute -bottom-0.5 -left-1 text-[10px] leading-none">🚪</span>
      </div>
    );
  }
  if (kind === 'pin') {
    return (
      <div className="relative h-12 w-12 mb-0 flex-shrink-0 flex items-center justify-center" aria-hidden>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-[16px] shadow-md ${darkMode ? 'bg-amber-900/70 ring-2 ring-amber-500/50' : 'bg-gradient-to-br from-amber-100 to-orange-100 ring-2 ring-amber-300'}`}>🔑</div>
      </div>
    );
  }
  return (
    <div className="relative h-12 w-12 mb-0 flex-shrink-0" aria-hidden>
      <div className={`absolute inset-0 rounded-xl rotate-[-10deg] ${darkMode ? 'bg-violet-900/80' : 'bg-violet-200/90'}`} />
      <div className={`relative w-12 h-12 rounded-xl flex items-center justify-center overflow-hidden ${darkMode ? 'bg-fuchsia-950 ring-1 ring-fuchsia-400/40' : 'bg-white ring-1 ring-fuchsia-200'} shadow-md`}>
        <span className="text-[16px] leading-none">🔄</span>
      </div>
    </div>
  );
}

const FILLERS: Record<FillerKind, { title: string; line: string; quote: string; shell: string; darkShell: string }> = {
  heart: {
    title: '일반 1회 · 무지개 4회',
    line: '잠긴 하트는 시간에 해금 · 남은 시간은 위 안내줄',
    quote: '무지개를 써도 일반 하트는 그대로',
    shell: 'bg-gradient-to-br from-rose-50 via-pink-50 to-white border border-rose-100/80 shadow-sm shadow-rose-100/30',
    darkShell: 'bg-gradient-to-br from-slate-800/90 via-rose-950/50 to-slate-900 border border-rose-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
  },
  guide: {
    title: '오늘 하나만 건져도 이득',
    line: '규칙은 짧게, 텐션은 자유롭게',
    quote: '존댓말로 시작하면 반은 먹고 들어감',
    shell: 'bg-gradient-to-br from-teal-50 via-white to-amber-50/80 border border-teal-100/80 shadow-sm shadow-teal-100/30',
    darkShell: 'bg-gradient-to-br from-slate-800/90 via-slate-800/60 to-teal-950/40 border border-teal-800/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
  },
  chat: {
    title: '말 거는 게 제일 어려움 인정',
    line: '하트랑 채팅은 따로. 그냥 먼저 쳐도 됨',
    quote: '한 줄이면 충분, 소설 쓸 필요 없음',
    shell: 'bg-gradient-to-br from-sky-50 via-indigo-50 to-white border border-indigo-100/80 shadow-sm shadow-indigo-100/30',
    darkShell: 'bg-gradient-to-br from-slate-800/90 via-indigo-950/50 to-slate-900 border border-indigo-900/60 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
  },
  group: {
    title: '두 방은 알아서 들어감',
    line: '2차 클럽·2차 술만 직접 입장',
    quote: '년생·N대 자동, 2차는 들락날락',
    shell: 'bg-gradient-to-br from-teal-50 via-emerald-50 to-white border border-teal-100/80 shadow-sm shadow-teal-100/30',
    darkShell: 'bg-gradient-to-br from-slate-800/90 via-teal-950/50 to-slate-900 border border-teal-900/60 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
  },
  pin: {
    title: '모르면?',
    line: '관리자에게 닉네임 말하고 찾아 달라고',
    quote: '입장 핀이랑 다른 거예요. 캡처 필수',
    shell: 'bg-gradient-to-br from-amber-50 via-orange-50 to-white border border-amber-100/80 shadow-sm shadow-amber-100/30',
    darkShell: 'bg-gradient-to-br from-slate-800/90 via-amber-950/40 to-slate-900 border border-amber-900/50 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
  },
  hidden: {
    title: '몰라도 되는데, 알면 이득',
    line: '카드 뒤집기 · 방문자 · 차단·숨기기',
    quote: '프로필 카드와 방문자 기능을 함께 확인해보세요',
    shell: 'bg-gradient-to-br from-violet-50 via-fuchsia-50 to-white border border-violet-100/80 shadow-sm shadow-violet-100/30',
    darkShell: 'bg-gradient-to-br from-slate-800/90 via-violet-950/50 to-slate-900 border border-violet-900/60 shadow-[0_1px_2px_rgba(0,0,0,0.25)]',
  },
};

function FillerPanel({ kind, darkMode, compact, fill }: { kind: FillerKind; darkMode?: boolean; compact?: boolean; fill?: boolean }) {
  const f = FILLERS[kind];
  const pin = kind === 'pin';
  if (fill) {
    if (kind === 'chat') return <ChatPhoneMock darkMode={darkMode} />;
    return (
      <div className={`flex-1 min-h-0 overflow-hidden flex items-center gap-3 px-3 py-2 rounded-2xl ${darkMode ? f.darkShell : f.shell}`}>
        <div className="flex-shrink-0 flex flex-col items-center gap-1">
          {pin && (
            <span className="inline-flex items-center justify-center rounded-full font-bold tracking-tight text-white shadow-md bg-gradient-to-r from-amber-500 to-orange-500 px-2 py-0.5 text-[11px]">
              관리자문의
            </span>
          )}
          <FillerArt kind={kind} darkMode={darkMode} />
        </div>
        <div className="min-w-0 flex-1 text-left">
          <p className={`font-bold text-xs leading-snug line-clamp-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>{f.title}</p>
          <p className={`text-[11px] leading-snug mt-0.5 line-clamp-2 ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>{f.line}</p>
        </div>
      </div>
    );
  }
  return (
    <div
      className={`flex-shrink-0 flex items-center rounded-2xl ${
        compact ? 'gap-2 px-2.5 py-1.5 text-left' : 'flex-col justify-center gap-1 px-3.5 py-2.5 text-center'
      } ${darkMode ? f.darkShell : f.shell}`}
    >
      {pin && (
        <span className={`inline-flex flex-shrink-0 items-center justify-center rounded-full font-bold tracking-tight text-white shadow-md bg-gradient-to-r from-amber-500 to-orange-500 ${compact ? 'px-2 py-0.5 text-[11px]' : 'mb-0.5 px-2.5 py-0.5 text-xs'}`}>
          관리자문의
        </span>
      )}
      {!compact && <FillerArt kind={kind} darkMode={darkMode} />}
      <div className={compact ? 'min-w-0 flex-1' : ''}>
        <p className={`font-bold tracking-tight leading-snug ${KR_WRAP} ${compact ? 'text-[11px]' : 'text-xs'} ${darkMode ? 'text-white' : 'text-slate-800'}`}>
          {f.title}
        </p>
        {!compact && (
          <p className={`text-xs leading-snug mt-0.5 ${KR_WRAP} ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
            {f.line.replace(/([.·])\s+/g, '$1\u200b ')}
          </p>
        )}
      </div>
    </div>
  );
}

function TopicSubTabs({
  subView,
  onChange,
  hasVideo,
  darkMode,
  topicColor,
}: {
  subView: 'tips' | 'video';
  onChange: (v: 'tips' | 'video') => void;
  hasVideo: boolean;
  darkMode?: boolean;
  topicColor: string;
}) {
  const base = 'flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all duration-200 active:scale-[0.97]';
  const idle = darkMode ? 'text-slate-400' : 'text-gray-500';
  const activeTips = darkMode
    ? 'bg-slate-700 text-white shadow-md ring-1 ring-white/10'
    : 'bg-white text-gray-900 shadow-md ring-1 ring-gray-200/70';
  const activeVideo = `bg-gradient-to-r ${topicColor} text-white shadow-lg shadow-black/10`;

  return (
    <div className={`flex-shrink-0 h-11 px-4 pb-1.5 ${darkMode ? 'bg-slate-900/80' : 'bg-gradient-to-b from-white to-slate-50/80'}`}>
      {hasVideo ? (
        <div className={`grid grid-cols-2 gap-1 p-0.5 rounded-xl h-8 ${darkMode ? 'bg-slate-800/80 ring-1 ring-slate-700/60' : 'bg-gray-100/90 ring-1 ring-gray-200/60'}`}>
          <button type="button" onClick={() => onChange('tips')} className={`${base} ${subView === 'tips' ? activeTips : idle}`}>
            📋 설명
          </button>
          <button type="button" onClick={() => onChange('video')} className={`${base} ${subView === 'video' ? activeVideo : idle}`}>
            <PlayCircle className="w-3.5 h-3.5" />
            동영상
          </button>
        </div>
      ) : (
        <div className={`h-8 rounded-xl flex items-center justify-center gap-1.5 px-3 ${darkMode ? 'bg-slate-800/50 ring-1 ring-slate-700/50' : 'bg-slate-100/80 ring-1 ring-slate-200/70'}`}>
          <span className={`text-[11px] font-semibold tracking-tight ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>📋 설명으로 안내해요</span>
        </div>
      )}
    </div>
  );
}

function SectionHeader({
  section,
  compact: _compact,
  darkMode,
}: {
  section: Section;
  compact?: boolean;
  darkMode?: boolean;
}) {
  const variant = SECTION_VARIANTS[section.variant ?? 'default'];
  const headerCls = darkMode ? variant.headerDark : variant.headerLight;
  return (
    <div className={`flex items-center gap-1.5 mb-1 rounded-lg border px-2 py-0.5 ${headerCls}`}>
      <span className="leading-none text-sm">{section.emoji}</span>
      <p className={`font-bold text-[11px] ${KR_WRAP}`}>{section.title}</p>
      <span className={`ml-auto h-1 flex-1 max-w-16 rounded-full bg-gradient-to-r ${variant.bar} opacity-70`} aria-hidden />
    </div>
  );
}

export function TutorialModal({
  onClose,
  darkMode,
  moduleFlags = DEFAULT_MODULE_FLAGS,
  applicationMode,
  applicationOpen = true,
}: {
  applicationMode?: "halloween" | "tour" | "normal";
  applicationOpen?: boolean;
  page?: number;
  onChangePage?: (p: number) => void;
  onClose: () => void;
  darkMode?: boolean;
  moduleFlags?: ModuleFlags;
}) {
  const [mode, setMode] = useState<'basic' | 'hidden'>('basic');
  const [topicIdx, setTopicIdx] = useState(0);
  const [subView, setSubView] = useState<'tips' | 'video'>('tips');

  const topics: Topic[] = applicationMode ? [{id:'application',emoji:'📋',label:'신청 방법',title:'술번개 신청 방법',color:'from-teal-500 to-cyan-600',tips:[
    {icon:'1',title:applicationOpen?'행사 선택·날짜 확인':'현재는 접수 전',desc:applicationOpen?'할로윈 금·토 양일과 전국투어 1차는 웹 신청 대상입니다. 접수 시작 후 행사·날짜를 선택하세요. 투어 2차는 별도 오픈채팅, 3차는 현장 안내입니다.':'웹·오픈채팅 모두 신규 신청을 받지 않습니다. 아래 내용은 오픈 후 이용 방법입니다. 운영자 오픈 확인 전에는 신청하거나 송금하지 마세요.'},
    {icon:'2',title:'참가 자격',desc:'1991~2007년생 기본 범위. 이전 출생자는 관리자 사전 문의·개별 검토가 필요합니다.'},
    {icon:'3',title:'개인정보·기본정보',desc:'수집 안내에 동의한 뒤 닉네임·년생·지역·연락처·입금자명을 입력합니다.'},
    {icon:'4',title:'필독 공지·동의',desc:'행사 공지에 동의한 다음 화면에서 처음 금액이 공개됩니다.'},
    {icon:'5',title:applicationMode==='tour'?'선입금 확인':'개인별 회비 확인',desc:!applicationOpen?'현재 송금은 받지 않습니다. 기존 신청·입금 내역은 관리자 문의로 확인하세요.':applicationMode==='tour'?'운영자가 입력한 선입금액만 납부합니다. 최종 1/N 정산은 운영자가 직접 안내합니다.':'고정 회비·선착순 혜택을 확인합니다. 1등 무료도 관리자 별도 승인이 필요합니다.'},
    {icon:'6',title:'신청 접수·입금 신고',desc:!applicationOpen?'운영자 오픈 확인 이후 이용할 수 있습니다. 이미 신청·입금한 내역은 보존하며 다시 신청하거나 송금하지 마세요.':'서버 저장 완료를 확인하고 입금 내역을 신고합니다. 이미 이체했다면 다시 보내지 마세요. 신고는 승인이 아닙니다.'},
    {icon:'7',title:'관리자 확인',desc:'은행 대조·승인 후 참가 확정됩니다. 운영자 근무·숙면 중 지연될 수 있습니다.'},
    {icon:'8',title:'대기방·프로필·현장',desc:'신청은 재접속해 이어볼 수 있습니다. 승인 후 장소를 확인하고 필수 프로필·현장 체크인을 완료합니다.'},
    {icon:'9',title:applicationMode==='tour'?'추억의 뽑기':'할로윈 경품 뽑기',desc:applicationMode==='tour'?'금·토 1차 유효 선착순10명만 무료 두 장(할인권1장·꽝1장). 목·일은 없습니다. 할인권 실제 적용은 운영자가 직접 합니다.':applicationMode==='halloween'?'현장 입장 후 무료 카드3장. 추가 유료 뽑기 없음. 하리보는 별도로1개.':'행사별 안내와 관리자 문의를 확인하세요.'},
  ]}].flatMap(topic => [0, 1, 2].map(page => ({...topic, id: `application-${page}`, label: `${page + 1}/3`, title: `술번개 신청 방법 · ${page + 1}/3`, tips: topic.tips.slice(page * 3, page * 3 + 3)}))) : mode === 'basic' ? tutorialBasicTopics(moduleFlags) : HIDDEN;
  const safeIdx = Math.min(topicIdx, topics.length - 1);
  const topic = topics[safeIdx];
  const accent = topicAccent(topic);
  const isLast = safeIdx === topics.length - 1;
  const hasVideo = Boolean(topic.video?.length);
  const showChips = topics.length > 1;
  const layout = topicLayout(topic);

  useEffect(() => {
    setSubView('tips');
  }, [mode, safeIdx]);

  const muted = darkMode ? 'text-slate-400' : 'text-gray-500';
  const text = darkMode ? 'text-slate-200' : 'text-gray-800';

  const switchMode = (next: 'basic' | 'hidden') => {
    setMode(next);
    setTopicIdx(0);
    setSubView('tips');
  };

  const selectTopic = (idx: number) => {
    setTopicIdx(idx);
    setSubView('tips');
  };

  const modalShell = MODAL_SHELL;

  const tipsContent = (
    <div className="flex flex-col flex-1 min-h-0 h-full overflow-hidden gap-1">

      {topic.filler && topic.id !== 'hidden' && topic.id !== 'guide' && (
        <FillerPanel kind={topic.filler} darkMode={darkMode} compact={layout.fillerCompact} />
      )}

      {(topic.sections ?? []).map((section) => {
        const variant = SECTION_VARIANTS[section.variant ?? 'default'];
        return (
          <div key={section.title}>
            <SectionHeader section={section} compact={layout.compact} darkMode={darkMode} />
            <TipGrid
              tips={section.tips}
              accent={accent}
              text={text}
              muted={muted}
              darkMode={darkMode}
              twoColumn={layout.twoColumn}
              compact={layout.compact}
              fill={layout.fillVertical}
              sectionBar={variant.bar}
              boxClass={layout.tipBox}
              tightGap={layout.tightGap}
            />
            {section.footer && (
              <p className={`mt-1 px-1 leading-snug ${KR_WRAP} text-[11px] ${darkMode ? 'text-slate-400' : 'text-gray-500'}`}>
                {section.footer.replace(/([.·])\s+/g, '$1\u200b ')}
              </p>
            )}
          </div>
        );
      })}

      {topic.tips.length > 0 && (
        <TipGrid
          tips={topic.tips}
          accent={accent}
          text={text}
          muted={muted}
          darkMode={darkMode}
          twoColumn={applicationMode ? false : layout.twoColumn}
          compact={layout.compact}
          fill={layout.fillVertical}
          longDescTitle="차단·숨기기"
          boxClass={applicationMode ? "min-h-12 h-auto py-3 items-center" : layout.tipBox}
          tightGap={layout.tightGap}
        />
      )}

      {topic.footer && (
        <p className={`flex-shrink-0 leading-snug px-2 py-1 rounded-lg border text-[10px] line-clamp-2 ${KR_WRAP} ${
          darkMode ? 'text-slate-400 bg-slate-800/40 border-slate-700/60' : 'text-gray-500 bg-slate-50/80 border-slate-100'
        }`}>
          {topic.footer.replace(/([.·])\s+/g, '$1\u200b ')}
        </p>
      )}

      {(layout.gapFill || topic.id === 'guide') && (layout.gapFillKind || topic.id === 'guide') && (
        <FillerPanel kind={topic.id === 'guide' ? 'guide' : layout.gapFillKind!} darkMode={darkMode} fill />
      )}
    </div>
  );

  const videoContent = topic.video ? (
    <div className="flex flex-col flex-1 min-h-0 overflow-hidden scrollbar-hide rounded-2xl">
      <TutorialVideo
        key={`${mode}-${topic.id}-video`}
        embedded
        compact
        fill
        sceneIndices={topic.video}
        onClose={() => setSubView('tips')}
      />
    </div>
  ) : null;

  return (
    <div
      className={`fixed inset-0 z-[10050] flex items-center justify-center bg-slate-950/75 backdrop-blur-md overflow-hidden overscroll-none animate-[fadeIn_0.2s_ease-out] ${applicationMode ? "application-tutorial" : ""}`}
      style={{
        padding:
          'max(1rem, var(--safe-top, 0px)) max(1rem, var(--safe-right, 0px)) max(1rem, var(--safe-bottom, 0px)) max(1rem, var(--safe-left, 0px))',
      }}
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="tutorial-modal-title"
        className={`relative ${modalShell} rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-[scaleIn_0.25s_ease-out] ${
          darkMode
            ? 'bg-gradient-to-b from-slate-900 to-slate-950 ring-1 ring-slate-700/50'
            : 'bg-gradient-to-b from-white to-slate-50/90 ring-1 ring-black/[0.04]'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="touch-target absolute top-2.5 right-2.5 z-10 flex items-center justify-center w-8 h-8 rounded-full bg-black/25 hover:bg-black/45 text-white backdrop-blur-md ring-1 ring-white/25 shadow-sm transition-all active:scale-95"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className={`relative bg-gradient-to-br ${topic.color} px-4 pt-2.5 pb-2 pr-12 flex-shrink-0 overflow-hidden transition-all duration-300`}>
          <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-white/10 blur-2xl pointer-events-none" aria-hidden />
          <div className="absolute -left-4 bottom-0 w-16 h-16 rounded-full bg-black/10 blur-xl pointer-events-none" aria-hidden />
          <div className="relative flex items-start gap-2.5">
            <span className="flex-shrink-0 w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md ring-1 ring-white/35 flex items-center justify-center text-xl shadow-lg shadow-black/10">
              {topic.emoji}
            </span>
            <div className="min-w-0 flex-1 pt-0.5">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/15 text-white/90 text-[11px] font-bold tracking-wide ring-1 ring-white/10">
                  <Sparkles className="w-3 h-3" />
                  도움말
                </span>
                <span className="inline-flex items-center gap-1" aria-hidden>
                  {topics.map((_, i) => (
                    <span
                      key={topics[i].id}
                      className={`h-1 rounded-full transition-all duration-300 ${
                        i === safeIdx ? 'w-3.5 bg-white' : 'w-1.5 bg-white/35'
                      }`}
                    />
                  ))}
                </span>
              </div>
              <h2 id="tutorial-modal-title" className={`text-white font-bold text-sm leading-snug mt-0.5 line-clamp-1 ${KR_WRAP}`}>
                {topic.title}
              </h2>
            </div>
          </div>
        </div>

        {/* Mode toggle */}
        {!applicationMode && <div
          className={`flex-shrink-0 h-[2.75rem] px-4 pt-2 pb-1.5 flex items-end ${darkMode ? 'bg-slate-900/80' : 'bg-gradient-to-b from-white to-slate-50/80'}`}
        >
          <div className={`grid grid-cols-2 p-1 rounded-2xl gap-1 w-full h-[2.125rem] ${darkMode ? 'bg-slate-800/80 ring-1 ring-slate-700/60' : 'bg-gray-100/90 ring-1 ring-gray-200/60'}`}>
            <button
              type="button"
              onClick={() => switchMode('basic')}
              className={`rounded-xl text-xs font-bold transition-all duration-200 active:scale-[0.97] ${
                mode === 'basic'
                  ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-white shadow-md shadow-cyan-500/25'
                  : darkMode ? 'text-slate-400' : 'text-gray-500'
              }`}
            >
              기본
            </button>
            <button
              type="button"
              onClick={() => switchMode('hidden')}
              className={`rounded-xl text-xs font-bold transition-all duration-200 active:scale-[0.97] ${
                mode === 'hidden'
                  ? 'bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-md shadow-violet-500/25'
                  : darkMode ? 'text-slate-400' : 'text-gray-500'
              }`}
            >
              ✨ 숨은기능
            </button>
          </div>
        </div>

        }
        {/* Topic chips — edge-to-edge segmented tabs, no inter-tab gaps */}
        {showChips && (
          <div className={`flex-shrink-0 border-b ${darkMode ? 'border-slate-700/80 bg-slate-900/60' : 'border-gray-100/80 bg-white/80'}`}>
            <div
              className="grid w-full"
              style={{ gridTemplateColumns: `repeat(${topics.length}, minmax(0, 1fr))` }}
            >
              {topics.map((t, i) => {
                const tAccent = topicAccent(t);
                const active = i === safeIdx;
                const divider =
                  i > 0 ? (active || i - 1 === safeIdx ? 'border-transparent' : darkMode ? 'border-l border-slate-700/45' : 'border-l border-gray-200/80') : '';
                return (
                  <button
                    key={t.id}
                    type="button"
                    aria-current={active ? 'true' : undefined}
                    onClick={() => selectTopic(i)}
                    className={`relative flex flex-col items-center justify-center min-h-[2.75rem] py-1 px-0 gap-px text-center transition-all duration-200 active:brightness-95 ${divider} ${
                      active
                        ? `bg-gradient-to-b ${t.color} text-white shadow-[inset_0_-1px_0_rgba(255,255,255,0.15)]`
                        : darkMode
                          ? `${tAccent.chipIdleDark} border-0 hover:brightness-110`
                          : `${tAccent.chipIdle} border-0 hover:brightness-[1.02]`
                    }`}
                  >
                    <span className="text-[15px] leading-none">{t.emoji}</span>
                    <span className={`text-[10px] font-semibold leading-none tracking-tight ${KR_WRAP}`}>{t.label}</span>
                    {t.video?.length ? (
                      <span className={`absolute top-0.5 right-0.5 text-[7px] leading-none ${active ? 'opacity-90' : 'opacity-40'}`} aria-hidden>▶</span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <TopicSubTabs subView={subView} onChange={setSubView} hasVideo={hasVideo} darkMode={darkMode} topicColor={topic.color} />

        {/* Content */}
        <div className={`flex-1 min-h-0 px-3 pt-1.5 pb-1 flex flex-col overflow-hidden ${
          darkMode ? 'bg-gradient-to-b from-slate-900/80 to-slate-950' : 'bg-gradient-to-b from-slate-50/80 to-white'
        }`}>
          {subView === 'video' && hasVideo ? videoContent : tipsContent}
        </div>

        {/* Footer */}
        <div className={`flex-shrink-0 h-[3.75rem] px-4 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] flex items-start gap-2 border-t ${
          darkMode ? 'border-slate-700/80 bg-slate-900/95 backdrop-blur-sm' : 'border-gray-100/80 bg-white/95 backdrop-blur-sm'
        }`}>
          {safeIdx > 0 ? (
            <button
              onClick={() => selectTopic(safeIdx - 1)}
              className={`touch-target flex-[2] flex items-center justify-center gap-1 py-2.5 rounded-2xl text-sm font-semibold border transition-all active:scale-[0.98] ${
                darkMode ? 'border-slate-700 text-slate-300 bg-slate-800/60 hover:bg-slate-800' : 'border-gray-200 text-gray-600 bg-white hover:bg-gray-50 shadow-sm'
              }`}
            >
              <ArrowLeft className="w-4 h-4" /> 이전
            </button>
          ) : mode === 'hidden' ? (
            <button
              onClick={() => switchMode('basic')}
              className={`touch-target flex-[2] py-2.5 rounded-2xl text-sm font-semibold border transition-all active:scale-[0.98] ${
                darkMode ? 'border-slate-700 text-slate-300 bg-slate-800/60' : 'border-gray-200 text-gray-600 bg-white shadow-sm'
              }`}
            >
              기본으로
            </button>
          ) : (
            <button
              onClick={onClose}
              className={`touch-target flex-[2] py-2.5 rounded-2xl text-sm font-semibold border transition-all active:scale-[0.98] ${
                darkMode ? 'border-slate-700 text-slate-400 bg-slate-800/40' : 'border-gray-200 text-gray-500 bg-white shadow-sm'
              }`}
            >
              닫기
            </button>
          )}
          <button
            onClick={() => {
              if (!isLast) { selectTopic(safeIdx + 1); return; }
              if (mode === 'basic' && !applicationMode) { switchMode('hidden'); return; }
              onClose();
            }}
            className={`touch-target flex-[3] flex items-center justify-center gap-1 py-2.5 rounded-2xl text-sm font-bold text-white bg-gradient-to-r ${topic.color} shadow-lg shadow-black/15 transition-all active:scale-[0.98] hover:brightness-105`}
          >
            {applicationMode && isLast ? '알겠어요' : isLast && mode === 'hidden' ? '알겠어요' : isLast && mode === 'basic' ? '숨은기능 보기' : <>다음 <ArrowRight className="w-4 h-4" /></>}
          </button>
        </div>
      </div>
    </div>
  );
}
