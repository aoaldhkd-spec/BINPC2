import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { MUTUAL_HEART_TOAST } from '../lib/heart-toast';
import { shouldAutoSkipWaiting } from '../lib/entry-gate';
import { MAX_GROUPS_PER_USER } from '../lib/group-rooms';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const read = (rel: string) => readFileSync(join(root, rel), 'utf8');
const fileExists = (rel: string) => existsSync(join(root, rel));

const HEART_BALANCE_BANNED = [
  'heart_balances',
  'myHeartCount',
  'heart_initial_count',
  'admin_reset_heart',
] as const;

describe('heart_balances recurrence guard (client)', () => {
  it('global heart pool symbols stay out of participant app sources', () => {
    const files = [
      'App.tsx',
      'components/MainScreen.tsx',
      'lib/db-auth-tables.ts',
      'hooks/useHearts.ts',
    ];
    for (const rel of files) {
      const src = read(rel);
      for (const token of HEART_BALANCE_BANNED) {
        expect(src, `${rel} must not contain ${token}`).not.toContain(token);
      }
    }
  });
});

describe('product copy + notification invariants', () => {
  it('mutual heart toast uses 서로 하트 not 서로 시그널', () => {
    const heartToast = read('lib/heart-toast.ts');
    const bottom = read('components/BottomNotification.tsx');
    expect(MUTUAL_HEART_TOAST).toContain('서로 하트');
    expect(MUTUAL_HEART_TOAST).not.toContain('서로 시그널');
    expect(heartToast).not.toContain('서로 시그널');
    expect(bottom).not.toContain("type: 'signal'");
  });

  it('튜토리얼 하단 탭은 참여자·하트, 채팅·통계·랭킹·설정 5개', () => {
    const modal = read('components/TutorialModal.tsx');
    const video = read('components/TutorialVideo.tsx');
    const main = read('components/MainScreen.tsx');
    expect(modal).not.toContain("id: 'signal'");
    expect(video).toContain("l: '하트, 채팅'");
    expect(video).toContain("l: '설정'");
    expect(video).toContain('하트, 채팅 → 내 상태');
    expect(video).not.toContain('function MyFab');
    expect(video).not.toContain('MY →');
    expect(modal).toContain("label: '설정'");
    expect(main).toContain("label: '설정'");
    expect(main).toContain("label: '하트, 채팅'");
  });

  it('profile photo upload uses sessionToken via localdb (Netlify cookie gap)', () => {
    const main = read('components/MainScreen.tsx');
    const db = read('lib/localdb.ts');
    const routes = read('../../api-server/src/routes/db.ts');
    expect(main).toContain('uploadStorageDataUrl');
    expect(db).toContain('uploadStorageDataUrl');
    expect(db).toMatch(/storage-upload[\s\S]*sessionToken/);
    expect(db).toMatch(/uploadStorageDataUrl[\s\S]*_waitForSession/);
    expect(routes).toMatch(/resolveAuthUserId\(req, body\)/);
  });

  it('chat image display uses withChatImageAuth (Netlify cookie gap for <img>)', () => {
    const db = read('lib/localdb.ts');
    const row = read('components/ChatMessageRow.tsx');
    const routes = read('../../api-server/src/routes/db.ts');
    expect(db).toContain('withChatImageAuth');
    expect(row).toContain('withChatImageAuth');
    expect(routes).toMatch(/req\.query\.sessionToken/);
    expect(routes).toMatch(/verifySessionToken\(qUserId,\s*qSessionToken\)/);
  });

  it('BottomNotification sits above ChatScreen', () => {
    const toast = read('components/BottomNotification.tsx');
    const chat = read('components/ChatScreen.tsx');
    expect(toast).toContain('z-[10050]');
    expect(chat).toContain('z-[9999]');
    // participant-tabbar already includes tab height + safe inset — no double 4.5rem stack
    expect(toast).toContain('var(--participant-tabbar');
    expect(toast).not.toMatch(/4\.5rem\+var\(--participant-tabbar/);
  });

  it('LikeConfirmDialog sits above FABs and hides competing MY FAB on mobile', () => {
    const dialog = read('components/LikeConfirmDialog.tsx');
    const app = read('App.tsx');
    const css = read('index.css');
    const card = read('components/ProfileCard.tsx');
    expect(dialog).toContain('z-[10070]');
    expect(dialog).toContain('bindMobileTap');
    expect(dialog).toContain('selectedRef');
    expect(app).toContain("dataset.overlay = 'like-confirm'");
    expect(css).toContain('data-overlay="like-confirm"');
    expect(css).not.toContain('theme-switcher');
    expect(css).toContain('.participant-fab-my');
    expect(card).toContain('bindMobileTap');
    expect(card).toContain('profile-card-heart-btn');
    expect(card).toContain('onLike(profile.id, profile)');
    expect(card).toContain('profile-card-menu-btn');
    expect(card).toContain('bindMobileTap((e) => openMenuFromButton');
    expect(card).not.toContain('touch-target');
    const deck = read('components/ProfileDeckGrid.tsx');
    expect(deck).toContain('hasProfileFortuneCompatData');
  });

  it('단톡 is quiet: no group-message modal popup', () => {
    const groupHook = read('hooks/useGroupChat.ts');
    const app = read('App.tsx');
    const notif = read('lib/notification-active.ts');
    expect(groupHook).not.toMatch(/setBottomNotif\(\{\s*type:\s*'message'/);
    expect(groupHook).not.toMatch(/setActiveNotif/);
    expect(read('components/AppOverlays.tsx')).toContain('NotifModal');
    expect(app).toContain('useAppShellRealtimeApply');
    expect(read('hooks/useAppShellRealtimeApply.ts')).toContain('shouldShowBroadcastNotif');
    expect(notif).toMatch(/n\.target === 'all'/);
  });

  it('닉네임 설정 1단계 이전하기는 대기 랜딩으로 돌아가고 회식 중 설정 갱신에 덮이지 않는다', () => {
    const nick = read('components/NicknameSetupScreen.tsx');
    const app = read('App.tsx');
    const gate = read('lib/entry-gate.ts');
    const settingsRt = read('lib/app-settings-realtime.ts');
    expect(nick).toContain("step === 1 ? '이전하기' : '이전'");
    expect(nick).toContain('else onReset()');
    expect(app).toContain('onReset={reset}');
    expect(app).toContain('useAppShellRealtimeApply');
    expect(read('hooks/useAppShellRealtimeApply.ts')).toContain('planAppSettingsRealtimeUpdate');
    expect(read('hooks/useAppShellRealtimeApply.ts')).toContain('autoSkipWaiting');
    expect(app).toContain('shownWaiting,');
    expect(settingsRt).toContain('shouldAutoSkipWaiting');
    expect(gate).toContain('opts.shownWaiting === false');
    // V4 keeps the landing even when the real session first starts.
    for(const previous of [null,false,true])expect(shouldAutoSkipWaiting({sessionActive:true,wasSessionActive:previous,hasStoredUser:false})).toBe(false);
  });

  it('처음으로 돌아가기 is a dim popup over mounted MainScreen', () => {
    const reset = read('components/ResetButton.tsx');
    const app = read('App.tsx');
    const overlays = read('components/AppOverlays.tsx');
    const mainShell = read('components/AppMainShell.tsx');
    expect(reset).toContain("backgroundColor: 'rgba(0, 0, 0, 0.4)'");
    expect(reset).toContain('data-password-overlay="dim"');
    expect(reset).not.toContain("backgroundColor: '#000000'");
    expect(reset).not.toMatch(/className="[^"]*\bbg-black(?:\s|")/);
    expect(reset).not.toContain('backdrop-blur');
    expect(overlays).not.toMatch(/showResetPassword \?/);
    expect(overlays).toContain('{showResetPassword && (');
    expect(app).toContain('<AppMainShell');
    expect(mainShell).toContain('<MainScreen');
  });

  it('user header gates: logo=reset, npc=admin, sulbun=plain title without age easter egg', () => {
    const reset = read('components/ResetButton.tsx');
    const main = read('components/MainScreen.tsx');
    expect(reset).toContain('data-gate="logo-reset"');
    expect(reset).toContain('data-gate="npc-admin"');
    expect(reset).toContain('data-gate="sulbun-none"');
    expect(reset).toContain('openResetGate');
    expect(reset).toContain('openAdminGate');
    expect(reset).not.toContain('handleSulbunClick');
    expect(reset).not.toContain('술번개 공식 영수증');
    expect(reset).not.toContain('playEasterEggSting');
    expect(reset).not.toMatch(/navigateToAppPath\('test'\)/);
    expect(main).not.toContain('hostBirthYearFromProfiles(profiles)');
  });



  it('waiting logo goes to tester; main logo stays reset', () => {
    const waiting = read('components/WaitingOverlay.tsx');
    const reset = read('components/ResetButton.tsx');
    expect(waiting).toContain('data-gate="waiting-logo-tester"');
    expect(waiting).toContain("verifyPanelPassword('test'");
    expect(waiting).toContain("navigateToAppPath('test')");
    expect(waiting).not.toMatch(/data-gate="waiting-logo-tester"[\s\S]{0,200}onClick=\{\(\) => navigateToAppPath\('test'\)\}/);
    expect(waiting).not.toContain('data-gate="logo-reset"');
    expect(reset).toContain('data-gate="logo-reset"');
    expect(reset).toContain('openResetGate');
    expect(reset).not.toMatch(/navigateToAppPath\('test'\)/);
  });

  it('waiting has no visible test/admin shortcut buttons', () => {
    const waiting = read('components/WaitingOverlay.tsx');
    for (const src of [waiting]) {
      expect(src).not.toMatch(/href="\/test"/);
      expect(src).not.toMatch(/href="\/admin"/);
      expect(src).not.toContain('>테스트</a>');
      expect(src).not.toContain('>관리자</a>');
    }
  });

  it('admin fixed nickname survives event-end reset on server and client', () => {
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    const admin = read('AdminApp.tsx');
    const app = read('App.tsx');
    expect(db).toContain('ADMIN_FIXED_NICKNAME');
    expect(db).toContain('withFixedAdminNickname');
    expect(db).toContain('ensureAdminProfile');
    expect(db).toContain('clearAdminNpcRelationships');
    expect(db).toContain('admin_event_end_reset');
    expect(db).toContain('admin_clear_profiles');
    expect(db).toContain('bumpResetSignalAndBroadcast');
    expect(admin).toContain('ADMIN_FIXED_NICKNAME');
    expect(admin).toContain('admin_clear_profiles');
    expect(app).toContain('applyResetSignal');
    expect(app).toContain('loadProfilesRef.current()');
  });

  it('숨은기능: 방문자·차단 안내만 남고 NPC 나이 이스터에그는 제거', () => {
    const modal = read('components/TutorialModal.tsx');
    expect(modal).toContain("title: '방문자'");
    expect(modal).toContain("title: '차단·숨기기'");
    expect(modal).not.toContain("title: 'NPC 나이'");
    expect(modal).not.toContain('HOST_AGE_EASTER_EGG_HINT');
    expect(modal).not.toMatch(/title: '칭찬 하트'/);
    expect(fileExists('lib/host-age-easter-egg.ts')).toBe(false);
  });

  it('첫 이용 코치는 참여자 이후 my/stats/ranking/settings SCREEN_STEPS를 순회한다', () => {
    const coach = read('components/FirstEntryCoachMarks.tsx');
    const marks = read('lib/coach-marks.ts');
    const guards = read('hooks/useSocialLockGuards.ts');
    expect(coach).toContain('const SCREEN_STEPS');
    expect(coach).toContain("onNavigateTab");
    expect(coach).toContain('markHomeCoachDone');
    expect(coach).toContain('first-entry-heart-primer');
    expect(coach).toContain('오늘 하트는 이렇게 써요');
    expect(marks).toContain('isHomeCoachPending');
    expect(guards).toContain('isHomeCoachPending');
  });

  it('튜토리얼 채팅 하단은 폰 목업으로 채우고 동영상은 LIVE UI 2026.09', () => {
    const modal = read('components/TutorialModal.tsx');
    const video = read('components/TutorialVideo.tsx');
    expect(modal).toContain('function ChatPhoneMock');
    expect(modal).toContain("topic.id === 'chat'");
    expect(modal).toContain('data-testid="tutorial-chat-phone-mock"');
    expect(video).toContain('UI 2026.09');
    expect(video).toContain('function ChatWallpaper');
    expect(video).toContain('하트 잠금→해금 · 무지개 4');
    expect(video).toContain('하트 보내기');
    expect(video).toContain('받은 하트');
    expect(video).toContain('function S8');
    expect(video).toContain('function S9');
    expect(video).toContain('LIVE');
  });

  it('튜토리얼은 고정 모달·통일 팁박스·내부 스크롤 없음', () => {
    const modal = read('components/TutorialModal.tsx');
    expect(modal).toContain('const MODAL_SHELL');
    expect(modal).toContain("h-[min(560px,calc(85dvh-var(--safe-top,0px)-var(--safe-bottom,0px)))]");
    expect(modal).not.toContain('MODAL_SHELL_HIDDEN');
    expect(modal).toContain("const TIP_BOX = 'h-[2.75rem] items-center'");
    expect(modal).toContain('scrollable: false');
    expect(modal).not.toContain('scrollable: isHidden');
    expect(modal).not.toContain('overflow-y-auto');
    expect(modal).toContain('flex-1 min-h-0 px-3 pt-1.5 pb-1 flex flex-col overflow-hidden');
    expect(modal).toContain('longDescTitle=');
    expect(modal).toContain('longDesc?: boolean');
    expect(modal).toContain('const showChips = topics.length > 1');
  });

  it('multi-theme switcher is removed; dark_mode toggle remains in App', () => {
    const app = read('App.tsx');
    const mainEntry = read('main.tsx');
    expect(fileExists('components/ThemeSwitcher.tsx')).toBe(false);
    expect(mainEntry).not.toContain('ThemeSwitcher');
    expect(mainEntry).not.toContain('ThemeProvider');
    expect(mainEntry).toContain('clearLegacyThemeArtifacts');
    expect(app).toContain("dataset.appReady = '1'");
    expect(app).toContain("ls.getItem('dark_mode')");
    expect(app).toContain('handleToggleDark');
  })

  it('채팅 탭 진입만으로 미읽음 숫자를 지우지 않는다', () => {
    const main = read('components/MainScreen.tsx');
    const chats = read('components/MainChatsTab.tsx');
    expect(main).not.toMatch(/if \(mainTab === 'chats'\) onClearMsgCount/);
    expect(main).not.toMatch(/if \(t === 'chats'\) \{ onClearMsgCount/);
    expect(main).toContain('sumUnreadCounts(unreadChatCounts)');
    expect(main).toContain('sumUnreadCounts(unreadGroupCounts)');
    expect(chats).toContain('unreadForChat');
  });

  it('단톡 입장 즉시 열고 나가기·키보드·읽음 숫자가 연결된다', () => {
    const app = read('App.tsx');
    const guards = read('hooks/useSocialLockGuards.ts');
    const group = read('components/GroupChatScreen.tsx');
    const hook = read('hooks/useGroupChat.ts');
    expect(app).toContain('leaveGroupChatGuarded');
    expect(app).toContain('onLeaveGroupChat');
    expect(app).toContain('useSocialLockGuards');
    expect(guards).toContain("setView('group-chat')");
    expect(guards).toMatch(/void openGroupChat\(groupId\);\s*setView\('group-chat'\)/);
    expect(group).toContain('visualViewport');
    expect(group).toContain('unreadMemberCount');
    expect(group).toContain('functionsLocked');
    expect(group).toContain('disabled={composerLocked}');
    expect(hook).toContain('markGroupRead');
    expect(hook).toContain('last_read_at');
    expect(hook).toContain('siblingGroupIds');
    expect(hook).toContain('recentlyLeftRef');
    expect(hook).toContain('syncCatalogJoined');
    expect(hook).toContain('patchCatalogMembership');
    expect(hook).toContain('onSseReconnect');
    expect(hook).toContain('isSseHealthy');
    expect(hook).toContain('resyncGroupState');
    expect(app).toMatch(/closeGroupChat\(\);\s*setView\('main'\)/);
    expect(group).toContain('GroupRoomIcon');
    expect(read('components/MainChatsTab.tsx')).toContain('GroupRoomIcon');
    expect(read('lib/group-rooms.ts')).not.toContain('🪩');
    expect(read('components/GroupRoomIcon.tsx')).toContain('ClubNeonIcon');
  });

  it('단톡 catalog is year + decade + opt-in 2차, cap 4', () => {
    expect(MAX_GROUPS_PER_USER).toBe(4);
    const chats = read('components/MainChatsTab.tsx');
    expect(chats).not.toContain('관심사·나이 / 같은 해 방은 자동');
    expect(chats).toContain('년생·나이대 방은 자동');
  });

  it('functions_locked covers MY/group re-entry, kick, and live settings', () => {
    const lock = read('lib/functions-lock.ts');
    const main = read('components/MainScreen.tsx');
    const app = read('App.tsx');
    const chatHook = read('hooks/useChat.ts');
    const dash = read('admin/DashboardTab.tsx');
    const detail = read('components/ProfileDetail.tsx');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    const settingsView = readFileSync(join(root, '../../api-server/src/lib/db-app-settings-view.ts'), 'utf8');
    expect(lock).toContain('FUNCTIONS_UNLOCK_TOAST');
    expect(lock).toContain('isFunctionsLockedOpError');
    expect(lock).toContain("'my'");
    expect(lock).not.toContain("'fortune'");
    expect(lock).not.toContain("'stats'");
    expect(lock).not.toContain("'ranking'");
    expect(lock).not.toContain("'settings'");
    expect(main).toContain('SOCIAL_LOCKED_TABS');
    expect(main).toContain('guardLockedAction');
    expect(app).toContain('FUNCTIONS_UNLOCK_TOAST');
    expect(app).toContain('functionsLockedPrevRef');
    expect(app).toContain('currentUserId: moduleFlags.direct_chat ? currentUserId : null');
    expect(app).toContain('functionsLocked,');
    expect(chatHook).toMatch(/functionsLocked[\s\S]*flushPendingQueue/);
    expect(chatHook).toContain('isFunctionsLockedOpError');
    expect(app).toContain('useSocialLockGuards');
    expect(app).toContain('useHeartsRealtimeApply');
    expect(app).toContain('...heartsRealtimeApply');
    expect(app).toContain('openChatGuarded');
    expect(app).toContain('sendMessageGuarded');
    expect(app).toContain('sendImageGuarded');
    expect(app).toContain('sendGroupMessageGuarded');
    expect(app).toContain('handleMainJoinGroupChat');
    expect(app).toContain('leaveGroupChatGuarded');
    expect(read('hooks/useSocialLockGuards.ts')).toContain('joinGroupChatGuarded');
    expect(read('hooks/useHeartsRealtimeApply.ts')).toContain('MUTUAL_HEART_TOAST');
    expect(chatHook).toContain('MESSAGE_ROW_SELECT');
    expect(chatHook).not.toMatch(/from\('messages'\)\.select\('\*'\)/);
    expect(app).toContain('onLeaveGroupChat');
    expect(app).toContain('handleMainTabChange');
    expect(app).toContain('FUNCTIONS_LOCK_KICK_TOAST');
    expect(read('components/AppOverlays.tsx')).toContain("handleMainTabChange('my')");
    expect(app).toContain('setMySubTabHint');
    expect(read('components/AppOverlays.tsx')).toContain('openChatGuarded(p)');
    expect(app).toContain('setContactShareTarget');
    expect(read('components/AppOverlays.tsx')).toContain('setContactShareTarget(null)');
    expect(app).toContain('useSessionReadyBootstrap');
    expect(app).toContain('useAppShellRealtimeChannels');
    expect(app).toContain('useAppShellRealtimeApply');
    expect(app).toContain('usePrivacySignalsRealtimeApply');
    expect(app).toContain('useProfilesRealtimeApply');
    expect(app).not.toContain('planAppSettingsRealtimeUpdate');
    expect(read('hooks/useAppShellRealtimeApply.ts')).toContain('planAppSettingsRealtimeUpdate');
    const shellHook = read('hooks/useAppShellRealtimeChannels.ts');
    expect(shellHook).toContain("table: 'app_settings'");
    const readyBoot = read('hooks/useSessionReadyBootstrap.ts');
    expect(readyBoot).toContain('settingsPoll');
    expect(readyBoot).toContain('/api/db/ready');
    expect(read('components/AppOverlays.tsx')).toContain('{showResetPassword && (');
    expect(dash).toContain('MY·단톡 사용 불가');
    expect(dash).toContain('통계·랭킹·설정');
    expect(detail).toContain('onViewFortune');
    expect(db).toContain('FUNCTIONS_LOCKED_INSERT_TABLES');
    expect(db).toContain('FUNCTIONS_LOCKED_ERROR');
    expect(db).toContain("from '../lib/db-app-settings-view'");
    expect(settingsView).toContain("code: 'FUNCTIONS_LOCKED'");
    expect(db).toContain('broadcastAll({ type: \'change\', table: \'app_settings\'');
  });


  it('hearts/group peels + db ring/map/policy stay wired (no inline fat)', () => {
    const app = read('App.tsx');
    const heartsApply = read('hooks/useHeartsRealtimeApply.ts');
    const guards = read('hooks/useSocialLockGuards.ts');
    const chatHook = read('hooks/useChat.ts');
    const groupHook = read('hooks/useGroupChat.ts');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    expect(app).toContain('useHeartsRealtimeApply');
    expect(app).toContain('useSocialLockGuards');
    expect(app).toContain('...heartsRealtimeApply');
    expect(app).not.toContain('planSentLikeInsert');
    expect(app).not.toContain('MUTUAL_HEART_TOAST');
    expect(heartsApply).toContain('MUTUAL_HEART_TOAST');
    expect(guards).toContain('joinGroupChatGuarded');
    expect(chatHook).toContain('MESSAGE_ROW_SELECT');
    expect(groupHook).toContain('GROUP_MESSAGE_ROW_SELECT');
    expect(db).toContain("from '../lib/db-sse-ring'");
    expect(db).toContain("from '../lib/db-merged-id-map'");
    expect(db).toContain("from '../lib/db-table-policy'");
    expect(db).not.toMatch(/function _ringAdd\(/);
    expect(db).not.toMatch(/const ALLOWED_OP_TABLES = new Set\(/);
  });

  it('registration/privacy loaders + db fanout/op-request stay wired (no inline fat)', () => {
    const app = read('App.tsx');
    const reg = read('hooks/useNicknameRegistration.ts');
    const loaders = read('hooks/useProfilePrivacyLoaders.ts');
    const planners = read('lib/nickname-registration.ts');
    const cols = read('lib/profile-select.ts');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    expect(app).toContain('useNicknameRegistration');
    expect(app).toContain('useProfilePrivacyLoaders');
    expect(app).toContain('PROFILE_ROW_SELECT');
    expect(app).not.toMatch(/from\('profiles'\)\.select\('\*'\)/);
    expect(app).not.toContain('이미 사용 중인 닉네임입니다');
    expect(reg).toContain('buildRegistrationProfileInsert');
    expect(reg).toContain('mapRegistrationErrorMessage');
    expect(loaders).toContain('PROFILE_ROW_SELECT');
    expect(loaders).toContain('USER_SIGNAL_ROW_SELECT');
    expect(planners).toContain('buildRegistrationSignalRow');
    expect(cols).toContain('PROFILE_ROW_SELECT');
    expect(db).toContain("from '../lib/db-sse-fanout-policy'");
    expect(db).toContain("from '../lib/db-op-request'");
    expect(db).toContain('planSmartBroadcastLocal');
    expect(db).toContain('normalizeOpFilters');
    expect(db).not.toMatch(/const PRIVATE_TABLES = new Set\(/);
    expect(db).not.toMatch(/const ALLOWED_OPS = new Set\(\['select'/);
  });


  it('session-init peeled to useSessionInit + planners (no inline #52 effect)', () => {
    const app = read('App.tsx');
    const hook = read('hooks/useSessionInit.ts');
    const planners = read('lib/session-init.ts');
    expect(app).toContain('useSessionInit');
    expect(app).toContain('clearHeartsState');
    expect(app).not.toContain('#52: 계정 전환 시 이전 유저의 하트 상태가 잠깐 보이는 현상 방지');
    expect(app).not.toContain('[share-profile] QR 스캔 프로필 로드 실패');
    expect(hook).toContain('planSessionInitAfterProfiles');
    expect(hook).toContain('shouldProcessPendingShare');
    expect(hook).toContain('SESSION_INIT_CONTACT_DELAY_MS');
    expect(planners).toContain('planSessionInitMissingRetry');
    expect(planners).toContain('shouldForceMainOnExistingComplete');
  });

  it('admin identity/wipe-plan + Admin/TestDashboard selects stay narrowed', () => {
    const admin = read('AdminApp.tsx');
    const testDash = read('TestDashboard.tsx');
    const notif = read('admin/NotificationTab.tsx');
    const cols = read('lib/profile-select.ts');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    expect(db).toContain("from '../lib/db-admin-identity'");
    expect(db).toContain("from '../lib/db-admin-wipe-plan'");
    expect(db).toContain('planClearAdminNpcRelationships');
    expect(db).not.toMatch(/const ADMIN_FIXED_NICKNAME = /);
    expect(cols).toContain('APP_SETTINGS_ADMIN_SELECT');
    expect(cols).toContain('LIKE_ROW_SELECT');
    expect(admin).toContain('APP_SETTINGS_ADMIN_SELECT');
    expect(admin).toContain('PROFILE_ROW_SELECT');
    expect(admin).not.toMatch(/\.select\('\*'\)/);
    expect(testDash).toContain('LIKE_ROW_SELECT');
    expect(testDash).not.toMatch(/\.select\('\*'\)/);
    expect(notif).toContain('NOTIFICATION_ROW_SELECT');
    expect(notif).not.toMatch(/\.select\('\*'\)/);
  });

  it('participant hearts/overlays/StatsTabs selects + settings-merge/tokens stay narrowed', () => {
    const hearts = read('hooks/useHearts.ts');
    const apply = read('hooks/useHeartsRealtimeApply.ts');
    const overlays = read('components/AppOverlays.tsx');
    const stats = read('components/StatsTabs.tsx');
    const cols = read('lib/profile-select.ts');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    expect(cols).toContain('CONTACT_SHARE_ROW_SELECT');
    expect(hearts).toContain('PROFILE_ROW_SELECT');
    expect(hearts).toContain('CONTACT_SHARE_ROW_SELECT');
    expect(hearts).not.toMatch(/\.select\('\*'\)/);
    expect(apply).toContain('PROFILE_ROW_SELECT');
    expect(apply).not.toMatch(/\.select\('\*'\)/);
    expect(overlays).toContain('PROFILE_ROW_SELECT');
    expect(overlays).not.toMatch(/\.select\('\*'\)/);
    expect(stats).toContain('PROFILE_ROW_SELECT');
    expect(stats).not.toMatch(/\.select\('\*'\)/);
    expect(db).toContain("from '../lib/db-app-settings-merge'");
    expect(db).toContain("from '../lib/db-panel-tokens'");
    expect(db).toContain('mergeAppSettingsPure');
    expect(db).not.toMatch(/const PRODUCTION_QR_BASE = /);
    expect(db).not.toMatch(/function deriveAdminToken\(/);
    expect(db).toContain("from '../lib/db-app-settings-view'");
    expect(db).toContain('planAppSettingsFromDbRows');
    expect(db).not.toMatch(/function publicAppSettingsView\(/);
    expect(db).not.toMatch(/function settingsFunctionsLocked\(/);
    expect(db).not.toMatch(/function tableFingerprint\(/);
    expect(db).not.toMatch(/function pickLatestAppSettingsRow\(/);
    expect(db).toContain("from '../lib/db-group-leave-plan'");
    expect(db).toContain('hasGroupOptOutPure');
    expect(db).toContain('participantRowsToLeavePure');
    expect(db).toContain('countUserGroupSlotsPure');
    expect(db).not.toMatch(/const yearOrAge = \/\^\\d\{4\}년생 모임\$/);
    expect(db).toContain("from '../lib/db-profile-reject'");
    expect(db).toContain('profileBirthYearRejectedPure');
    expect(db).toContain('profileAvatarColorRejectedPure');
    expect(db).toContain('profileNpcAvatarRejectedPure');
    expect(db).toContain("from '../lib/db-chat-read-block'");
    expect(db).toContain('stampChatReadAtPure');
    expect(db).toContain('isChatPairBlockedPure');
    expect(db).not.toMatch(/const ADULT_BIRTH_YEAR_ERROR = \{/);
    expect(db).not.toMatch(/const AVATAR_COLOR_COUNT = 12/);
    expect(db).toContain("from '../lib/db-reference-check'");
    expect(db).toContain('mergeRefreshedRowsPure');
    expect(db).toContain('missingWriteRefsByTable');
    expect(db).toContain('evaluateWriteReferences');
    expect(db).toContain("from '../lib/db-kv-hydrate'");
    expect(db).toContain('mergeKvRowsIntoStorePure');
    expect(db).toContain('seedLikesLastInsertMapPure');
    expect(db).not.toMatch(/type ReferenceCheck = \{ ok: true \}/);
    expect(db).not.toMatch(/function realtimeTraceMeta\(/);
    expect(db).not.toMatch(/const SYSTEM_KV_TABLES = new Set\(\['rate_limits'/);
    expect(db).toContain("from '../lib/db-session-tokens'");
    expect(db).toContain('issueSessionTokenPure');
    expect(db).toContain('classifySseTokenPure');
    expect(db).toContain('consumePinBucketPure');
    expect(db).toContain("from '../lib/db-image-magic'");
    expect(db).toContain('dataUrlMimeAndMagic');
    expect(db).not.toMatch(/const SSE_TOKEN_EXPIRY_SEC = 3600/);
    expect(db).not.toMatch(/const IMAGE_MAGIC: Record<string/);
    expect(db).not.toMatch(/const ALLOWED_IMAGE_MIMES = new Set\(\['image\/jpeg'/);
    expect(db).toContain("from '../lib/db-unread-counts'");
    expect(db).toContain('computeUnreadCountsForUser');
    expect(db).toContain("from '../lib/db-push-plan'");
    expect(db).toContain('planPushForEvent');
    expect(db).toContain('verifyAdminPanelToken');
    expect(db).toContain('verifyTestPanelToken');
    expect(db).not.toMatch(/payload = \{ title: `💬 \$\{nick\}`/);
    expect(db).not.toMatch(/const msgsByChatId = new Map<string, typeof store\[string\]>/);
    expect(db).toContain("from '../lib/db-admin-ensure-plan'");
    expect(db).toContain('planEnsureAdminProfile');
    expect(db).toContain('planRestoreAdminProfileAfterWipe');
    expect(db).toContain("from '../lib/db-app-settings-boot'");
    expect(db).toContain('buildDefaultAppSettings');
    expect(db).toContain('planAppSettingsSecretsPatch');
    expect(db).not.toMatch(/personality_score: 50,/);
    expect(db).not.toMatch(/admin_phone:\s*['"]01\d[-\d]+['"]/);
    expect(db).toContain("from '../lib/db-op-result-shape'");
    expect(db).toContain('orderLimitShape');
    expect(db).toContain('sanitizeBroadcastValue');
    expect(db).toContain("from '../lib/db-op-select-scope'");
    expect(db).toContain('scopeSignalSendsRows');
    expect(db).toContain('dedupeParticipantChatRows');
    expect(db).not.toMatch(/function sanitizeBroadcastValue\(val: unknown, depth = 0\)/);
    expect(db).not.toMatch(/const seenPairs = new Set<string>\(\);/);
    expect(db).toContain("from '../lib/db-op-update-ownership'");
    expect(db).toContain('checkUpdateRowOwnership');
    expect(db).toContain("from '../lib/db-op-delete-ownership'");
    expect(db).toContain('checkDeleteRowOwnership');
    expect(db).not.toMatch(/IDOR: messages UPDATE without requesterId blocked/);
    expect(db).not.toMatch(/Forbidden: 자신이 보낸 하트만 취소할 수 있습니다\./);
    expect(db).toContain("from '../lib/db-op-insert-ownership'");
    expect(db).toContain('planMessagesInsertOwnership');
    expect(db).toContain("from '../lib/db-op-upsert-ownership'");
    expect(db).toContain('planUpsertRelationshipRow');
    expect(db).not.toMatch(/IDOR: messages INSERT without requesterId blocked/);
    expect(db).not.toMatch(/Forbidden: use insert for signal actions/);
    expect(db).toContain("from '../lib/db-op-select-access'");
    expect(db).toContain("from '../lib/db-session-tokens'");
    expect(db).toContain('validateAuthLoginBody');
    expect(db).toContain('planStorageUploadAuthPath');
    expect(db).toContain('buildHealthAlarms');
    expect(db).toContain('planPushSubscribeStore');
    expect(db).toContain('planNotifyOtherInstances');
    expect(db).toContain('planAutoMatchJoinSpecs');
    expect(db).toContain('opBusyReject');
    expect(db).toContain('validateRpcName');
    expect(db).toContain('validatePushSubscribeBody');
    expect(db).toContain('buildInsertedRow');
    expect(db).not.toMatch(/이미 다른 기기에서 등록된 계정입니다/);
    expect(db).not.toMatch(/Server busy — retry in 1s/);

    expect(db).toContain('mapMessagesOntoCanonicalChatId');
    expect(db).toContain("from '../lib/db-op-likes-limits'");
    expect(db).toContain('likesHeartLimitReject');
    expect(db).toContain("from '../lib/db-pin-lookup'");
    expect(db).toContain("from '../lib/db-storage-path'");
    expect(db).toContain("from '../lib/db-broadcast-validate'");
    expect(db).toContain("from '../lib/db-rpc-allowlist'");
    expect(db).not.toMatch(/같은 종류의 하트는 최대 2명에게만 보낼 수 있습니다/);
    expect(db).not.toMatch(/const ALLOWED_RPCS = new Set/);
  });




  it('privacy/signal/profile/shell apply + db-image-store stay peeled', () => {
    const app = read('App.tsx');
    const privacy = read('hooks/usePrivacySignalsRealtimeApply.ts');
    const profiles = read('hooks/useProfilesRealtimeApply.ts');
    const shellApply = read('hooks/useAppShellRealtimeApply.ts');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    const imageStore = readFileSync(join(root, '../../api-server/src/lib/db-image-store.ts'), 'utf8');
    expect(app).toContain('usePrivacySignalsRealtimeApply');
    expect(app).toContain('useProfilesRealtimeApply');
    expect(app).toContain('useAppShellRealtimeApply');
    expect(app).toContain('...privacySignalsRealtimeApply');
    expect(app).toContain('...profilesRealtimeApply');
    expect(app).toContain('useAppShellRealtimeChannels(appShellRealtimeApply)');
    expect(app).not.toContain('mergeUserSignalRow');
    expect(app).not.toContain('planAppSettingsRealtimeUpdate');
    expect(app).not.toContain('planProfilesAfterInsert');
    expect(privacy).toContain('onBlockedUserInsert');
    expect(privacy).toContain('mergeUserSignalRow');
    expect(profiles).toContain('planProfilesAfterUpdate');
    expect(shellApply).toContain('planAppSettingsRealtimeUpdate');
    expect(shellApply).toContain('planContactShareEvent');
    expect(db).toContain("from '../lib/db-image-store'");
    expect(db).toContain('createImageStore');
    expect(db).not.toMatch(/function pruneImageStore\(/);
    expect(db).not.toMatch(/const imageStore = new Map/);
    expect(imageStore).toContain('createImageStore');
    expect(imageStore).toContain('IMAGE_STORE_MAX_ENTRIES_DEFAULT');
  });


  it('ProfileCard keeps compact heart/chat buttons (no min-h-11 bloat)', () => {
    const card = read('components/ProfileCard.tsx');
    expect(card).not.toMatch(/min-h-11/);
    expect(card).not.toMatch(/\bw-8 h-8\b/);
    expect(card).toMatch(/w-5 h-5/);
    expect(card).toMatch(/py-0\.5/);
  });

  it('ProfileCard pauses offscreen ticker and MainScreen uses signal Map lookup', () => {
    const card = read('components/ProfileCard.tsx');
    expect(card).toContain('IntersectionObserver');
    expect(card).toContain('tickerAnimActive');
    expect(card).toContain('contentVisibility');
    const main = read('components/MainScreen.tsx');
    expect(main).toContain('signalByUserId');
    expect(main).toContain('deckProfiles');
    expect(main).not.toMatch(/userSignals\.find\(s => s\.user_id === profile\.id\)/);
  });

  it('ProfileCards follow App darkMode only; multi-theme chrome removed', () => {
    const theme = read('lib/theme.tsx');
    const card = read('components/ProfileCard.tsx');
    const surfaces = read('lib/profile-card-theme.ts');
    const main = read('components/MainScreen.tsx');
    expect(theme).toContain('clearLegacyThemeArtifacts');
    expect(theme).not.toContain('ThemeProvider');
    expect(theme).not.toContain('isDarkTheme');
    expect(surfaces).toContain('export function isProfileCardDark');
    expect(surfaces).toContain('return darkMode');
    expect(card).toContain('isProfileCardDark(darkMode)');
    expect(card).toContain('profileCardSurfaces(darkMode)');
    expect(card).toContain('darkMode = false');
    expect(card).not.toContain('useTheme');
    expect(main).toContain('darkMode={darkMode}');
    expect(surfaces).toContain('bg-white border-gray-100');
    expect(surfaces).toContain('bg-slate-900');
    expect(surfaces).toMatch(/rgba\(15,\s*23,\s*42/);
  })

  it('App must not re-add SignalNudgeBanner heart nudge overlay', () => {
    const app = read('App.tsx');
    expect(app).not.toContain('SignalNudgeBanner');
  });

  it('BottomNotification has no signal toast type', () => {
    const bottom = read('components/BottomNotification.tsx');
    expect(bottom).not.toContain("type: 'signal'");
    expect(bottom).not.toContain('onGoToSignal');
    expect(bottom).not.toContain('SIGNAL_EMOJI');
  });

  it('realtime E2E script uses Render for SSE not Netlify proxy', () => {
    const script = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), '../../../../scripts/test-realtime-two-user.mjs'),
      'utf8',
    );
    expect(script).toMatch(/SSE_ORIGIN|SSE_API/);
    expect(script).toMatch(/`\$\{SSE_API\}\/events/);
    expect(script).not.toMatch(/\$\{API\}\/events/);
    expect(script).toContain('binpc2.onrender.com');
  });

  it('endurance soak guards SSE idle drop and mid-run FUNCTIONS_LOCKED SKIP', () => {
    const scriptsRoot = join(dirname(fileURLToPath(import.meta.url)), '../../../../scripts');
    const endurance = readFileSync(join(scriptsRoot, 'endurance-5h.mjs'), 'utf8');
    const lock = readFileSync(join(scriptsRoot, 'lib/functions-lock.mjs'), 'utf8');
    const watchdog = readFileSync(join(scriptsRoot, 'endurance-watchdog.mjs'), 'utf8');
    const launcher = readFileSync(join(scriptsRoot, 'start-endurance-8h.mjs'), 'utf8');
    expect(endurance).toMatch(/ensureConnected/);
    expect(endurance).toMatch(/isOpFunctionsLocked|FUNCTIONS_LOCKED mid-run/);
    expect(endurance).toMatch(/result\.locked|locked: true/);
    expect(endurance).toMatch(/recoverContext|isRecoverableOpFailure/);
    expect(endurance).toMatch(/admin_event_end_reset/);
    expect(endurance).toMatch(/acquireEnduranceLock/);
    expect(endurance).toMatch(/ENDURANCE_DEADLINE_AT|deadlineAt/);
    expect(endurance).toMatch(/CYCLE_TIMEOUT_MS|ENDURANCE_CYCLE_TIMEOUT_MS/);
    expect(endurance).toMatch(/429|Rate limit/i);
    expect(lock).toContain('isOpFunctionsLocked');
    expect(watchdog).toMatch(/detached:\s*true/);
    expect(watchdog).toMatch(/STALL_MS|ENDURANCE_STALL_MS/);
    expect(watchdog).toMatch(/spawnEndurance|ENDURANCE_DEADLINE_AT/);
    expect(launcher).toMatch(/detached:\s*true/);
    expect(launcher).toMatch(/ENDURANCE_SESSION_DEADLINE/);
  });

  it('E2E reconnect scripts stay wired in verify-all-features', () => {
    const verify = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), '../../../../scripts/verify-all-features.mjs'),
      'utf8',
    );
    for (const script of [
      'test-chat-disconnect-recovery.mjs',
      'e2e-heart-sse-consistency.mjs',
      'test-mutual-chat-hearts.mjs',
    ]) {
      expect(verify).toContain(script);
    }
  });

  it('status contact pills open center popup modal not bottom sheet', () => {
    const main = read('components/MainScreen.tsx');
    expect(main).toContain('status-quick-modal-title');
    expect(main).toMatch(/safe-overlay fixed inset-0[\s\S]*items-center justify-center/);
    expect(main).not.toMatch(/statusQuickSheet[\s\S]{0,400}items-end/);
  });

  it('Supabase public tables RLS enabled on API startup', () => {
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    const policy = readFileSync(join(root, '../../api-server/src/lib/db-table-policy.ts'), 'utf8');
    expect(db).toContain('ensurePublicTableRls');
    expect(db).toContain('buildPublicTableRlsSql');
    expect(policy).toMatch(/ENABLE ROW LEVEL SECURITY/);
    expect(policy).toMatch(/REVOKE ALL ON public/);
  });

  it('legacy KV tables and heart_balances blocklist are cleaned on startup', () => {
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    const cleanup = readFileSync(join(root, '../../api-server/src/lib/db-legacy-cleanup.ts'), 'utf8');
    expect(db).toContain('cleanupLegacyTables()');
    expect(db).toMatch(/dbReadyPromise[\s\S]{0,120}\.then\(\(\) => cleanupLegacyTables\(\)\)/);
    expect(db).toContain('legacy_leftovers');
    for (const token of ['heart_balances', 'heart_drain_enabled', 'seats_snapshot']) {
      expect(cleanup).toContain(token);
    }
  });

  it('mobile safe-area: Galaxy tabbar + iOS 16px input + viewport-fit=cover', () => {
    const html = readFileSync(join(root, '../index.html'), 'utf8');
    const css = read('index.css');
    const main = read('components/MainScreen.tsx');
    expect(html).toContain('viewport-fit=cover');
    expect(css).toMatch(/font-size:\s*max\(16px/);
    expect(css).toContain('--tabbar-safe-bottom');
    expect(css).toContain('.participant-tabbar');
    expect(main).toContain('--participant-tabbar');
    expect(main).toContain('--tabbar-safe-bottom');
  });

  it('MY tab scrolls full content with bottom clearance (MY FAB + tab bar)', () => {
    const main = read('components/MainScreen.tsx');
    expect(main).toMatch(/mainTab === 'my'[\s\S]{0,240}pb-24/);
    expect(main).toContain('flex-1 min-h-0 px-3 min-[360px]:px-4 overflow-y-auto overscroll-y-contain scrollbar-hide pb-[calc(8.5rem+var(--tabbar-safe-bottom))]');
    expect(main).not.toContain('flex-1 min-h-0 flex flex-col px-3 min-[360px]:px-4 overflow-y-auto');
  });

  it('통계·랭킹 tabs scroll full content with bottom clearance (MY FAB + tab bar)', () => {
    const statsTabs = read('components/StatsTabs.tsx');
    const main = read('components/MainScreen.tsx');
    const ranking = read('lib/stats-ranking.ts');
    const utils = read('lib/utils.ts');
    expect(statsTabs).toMatch(/export function StatsTab[\s\S]*?mx-auto space-y-4 pb-24/);
    expect(statsTabs).toMatch(/export function RankingTab[\s\S]*?mx-auto space-y-4 pb-24/);
    expect(statsTabs).toContain('getMbtiStyle(m).color');
    expect(main).toContain('profiles={statsProfiles}');
    expect(ranking).not.toContain('p.nickname === ADMIN_FIXED_NICKNAME');
    expect(utils).toContain("letters[3] === 'J' ? 'SJ' : 'SP'");
  });

  it('HEIC upload rejected with user-facing message', () => {
    const photo = read('lib/profile-photo.ts');
    expect(photo).toMatch(/HEIC|heic/);
    expect(photo).toContain('JPG, PNG, WebP');
  });

  it('profile-card-grid density modes stay wired and tested', () => {
    const grid = read('lib/profile-card-grid.ts');
    const gridTest = read('lib/profile-card-grid.test.ts');
    const main = read('components/MainScreen.tsx');
    const deck = read('components/ProfileDeckGrid.tsx');
    expect(grid).toContain("'compact'");
    expect(grid).toContain("'2'");
    expect(grid).toContain("'3'");
    expect(gridTest).toContain('grid-cols-2');
    expect(gridTest).toContain('grid-cols-3');
    expect(main).toContain('readProfileCardGridMode');
    expect(main).toContain('ProfileDeckGrid');
    expect(deck).toContain('profileGridClassName');
  });

  it('verify scripts treat admin password mismatch and FUNCTIONS_LOCKED as SKIP', () => {
    const verify = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), '../../../../scripts/verify-all-features.mjs'),
      'utf8',
    );
    expect(verify).toContain('SKIP (local password mismatch');
    expect(verify).toContain('SKIP (FUNCTIONS_LOCKED)');
  });

  it('localdb uses optional VITE_SSE_ORIGIN for Render-direct SSE', () => {
    const db = read('lib/localdb.ts');
    expect(db).toContain('VITE_SSE_ORIGIN');
    expect(db).toMatch(/SSE_ORIGIN[\s\S]*events/);
  });

  it('participant system Back uses History API and does not wrap AdminApp', () => {
    const app = read('App.tsx');
    const mainEntry = read('main.tsx');
    const nav = read('lib/participant-nav-history.ts');
    expect(app).toContain('createParticipantNav');
    expect(app).toContain('goParticipantBack');
    expect(app).toContain('screen:${view}');
    expect(app).toContain('ParticipantNavProvider');
    expect(nav).toContain('trapped-root');
    expect(nav).toContain('handlePopState');
    expect(mainEntry).not.toContain('createParticipantNav');
    expect(mainEntry).toContain('AdminApp');
  });

  it('프로필·채팅 화면 넘김은 메인 언마운트 없이 CSS transform 이다', () => {
    const app = read('App.tsx');
    const css = read('index.css');
    const main = read('components/MainScreen.tsx');
    expect(css).toContain('binpc-screen-in');
    expect(css).toContain('translate3d(100%, 0, 0)');
    expect(read('components/AppOverlays.tsx')).toContain('binpc-screen-in');
    expect(read('components/AppMainShell.tsx')).toContain('inert={isSubScreen');
    expect(read('components/AppMainShell.tsx')).toContain("className={isSubScreen ? 'pointer-events-none' : undefined}");
    expect(main).toContain('KeepTab');
    expect(main).toContain("visitedTabsRef.current.has('profiles')");
    expect(main).toContain("mainTab === 'my'");
    expect(main).toContain("mainTab === 'settings'");
  });
});

describe('Korean age recurrence guard', () => {
  it('나이 계산은 korean-age 모듈 한 곳(+1)을 쓰고 만 나이(연도 차만) 중복이 없다', () => {
    const ageLib = read('lib/korean-age.ts');
    const profile = read('lib/profile.ts');
    const groupRooms = read('lib/group-rooms.ts');
    const stats = read('lib/stats-ranking.ts');
    const db = readFileSync(join(root, '../../api-server/src/routes/db.ts'), 'utf8');
    const groupRoomPlan = readFileSync(join(root, '../../api-server/src/lib/db-group-room-plan.ts'), 'utf8');
    const serverAge = readFileSync(join(root, '../../api-server/src/lib/korean-age.ts'), 'utf8');

    expect(ageLib).toMatch(/\+\s*1/);
    expect(ageLib).toContain('koreanAgeFromBirthYear');
    expect(profile).toContain("from './korean-age'");
    expect(groupRooms).toContain("from './korean-age'");
    expect(stats).toContain("from './korean-age'");
    // ageBandFromYear lives in db-group-room-plan (peeled); still uses groupAgeDecadeBand
    expect(groupRoomPlan).toContain('groupAgeDecadeBand');
    expect(db).toContain("from '../lib/db-group-room-plan'");
    expect(serverAge).toMatch(/\+\s*1/);

    for (const [rel, src] of [
      ['lib/profile.ts', profile],
      ['lib/group-rooms.ts', groupRooms],
      ['lib/stats-ranking.ts', stats],
      ['api-server db.ts', db],
      ['api-server db-group-room-plan.ts', groupRoomPlan],
    ] as const) {
      expect(src, `${rel} must not inline intl age (year diff without +1)`).not.toMatch(
        /getFullYear\(\)\s*-\s*\w+\s*;(?![\s\S]{0,40}\+\s*1)/,
      );
    }
  });
});

describe('test persona nicknames (scripts)', () => {
  it('never appends numeric suffixes to visible nicknames', async () => {
    const personas = await import(
      '../../../../scripts/lib/test-personas.mjs'
    ) as typeof import('../../../../scripts/lib/test-personas.mjs');
    personas.resetNicknameRegistry();
    const src = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), '../../../../scripts/lib/test-personas.mjs'),
      'utf8',
    );
    expect(src).toContain('NO numeric suffixes');
    expect(src).toContain('nicknameEndsWithDigit');
    expect(src).not.toContain('padStart(');
    const samples: string[] = [];
    for (let i = 0; i < 80; i += 1) samples.push(personas.makeNickname({ index: i, attempt: i % 5 }));
    for (let i = 0; i < 40; i += 1) samples.push(personas.reserveNickname({ index: 1000 + i }));
    const bad = samples.filter((n) => personas.nicknameEndsWithDigit(n) || /\d$/u.test(n));
    expect(bad).toEqual([]);
  });
});

describe('participant profile list order invariants', () => {
  it('deck filter uses stable sort; App/loaders merge profiles instead of blind prepend/replace', () => {
    const deck = read('lib/profile-deck-filter.ts');
    const order = read('lib/profile-list-order.ts');
    const apply = read('lib/profile-realtime-apply.ts');
    const app = read('App.tsx');
    const loaders = read('hooks/useProfilePrivacyLoaders.ts');
    expect(deck).toContain('sortProfilesStable');
    expect(order).toContain('mergeProfilesPreserveOrder');
    expect(order).toContain('patchProfileInPlace');
    expect(order).toContain('created_at');
    expect(apply).toContain('planProfilesAfterInsert');
    expect(apply).toContain('patchProfileInPlace');
    expect(app).toContain('mergeProfilesPreserveOrder');
    expect(app).toContain('useProfilesRealtimeApply');
    expect(app).not.toContain('planProfilesAfterUpdate');
    expect(read('hooks/useProfilesRealtimeApply.ts')).toContain('planProfilesAfterUpdate');
    expect(app).not.toMatch(/return \[incoming, \.\.\.prev\]/);
    expect(loaders).toContain('mergeProfilesPreserveOrder(prev, visible)');
    expect(app).toContain('useProfilePrivacyLoaders');
  });
});
