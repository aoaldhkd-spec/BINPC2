import { describe, expect, it } from 'vitest';
import { planAppSettingsRealtimeUpdate } from './app-settings-realtime';

describe('planAppSettingsRealtimeUpdate', () => {
  it('returns reset when admin reset_signal changes', () => {
    const plan = planAppSettingsRealtimeUpdate(
      { reset_signal: 'r2', session_active: true },
      {
        localReset: 'r1',
        wasSessionActive: true,
        hasStoredUser: true,
      },
    );
    expect(plan).toEqual({ kind: 'reset', resetSignal: 'r2', sulbunEvent: null });
  });

  it('plans session on→off returnToWaiting and timers', () => {
    const plan = planAppSettingsRealtimeUpdate(
      {
        session_active: false,
        timer_end_at: 't1',
        timer_label: 'L',
        reset_signal: 'r1',
        functions_locked: true,
      },
      {
        localReset: 'r1',
        wasSessionActive: true,
        hasStoredUser: true,
      },
    );
    expect(plan.kind).toBe('patch');
    if (plan.kind !== 'patch') return;
    expect(plan.setSessionActive).toBe(true);
    expect(plan.sessionActive).toBe(false);
    expect(plan.returnToWaiting).toBe(true);
    expect(plan.autoSkipWaiting).toBe(false);
    expect(plan.timerEndAt).toBe('t1');
    expect(plan.timerLabel).toBe('L');
    expect(plan.hasFunctionsLocked).toBe(true);
    expect(plan.functionsLockedRaw).toBe(true);
  });

  it('keeps explicit entry on false→true without stored user', () => {
    const plan = planAppSettingsRealtimeUpdate(
      { session_active: true, reset_signal: null },
      {
        localReset: null,
        wasSessionActive: false,
        hasStoredUser: false,
      },
    );
    expect(plan.kind).toBe('patch');
    if (plan.kind !== 'patch') return;
    expect(plan.autoSkipWaiting).toBe(false);
    expect(plan.returnToWaiting).toBe(false);
  });

  it('applies module flags immediately from app_settings SSE', () => {
    const plan = planAppSettingsRealtimeUpdate(
      {
        module_flags: JSON.stringify({ hearts: false, stats: false }),
        reset_signal: null,
      },
      { localReset: null, wasSessionActive: true, hasStoredUser: true },
    );
    expect(plan.kind).toBe('patch');
    if (plan.kind !== 'patch') return;
    expect(plan.setModuleFlags).toBe(true);
    expect(plan.moduleFlags.hearts).toBe(false);
    expect(plan.moduleFlags.stats).toBe(false);
    expect(plan.moduleFlags.direct_chat).toBe(true);
  });

  it('applies sulbun_event on SSE without treating it as a heart-ops field', () => {
    const plan = planAppSettingsRealtimeUpdate(
      {
        sulbun_event: {
          cycle_id: 'c1',
          opened_at: '2026-09-20T13:00:00.000Z',
          auto_reset_at: '2026-09-21T08:00:00.000Z',
          auto_reset_enabled: true,
          reset_done: false,
        },
        reset_signal: null,
      },
      { localReset: null, wasSessionActive: true, hasStoredUser: true },
    );
    expect(plan.kind).toBe('patch');
    if (plan.kind !== 'patch') return;
    expect(plan.setSulbunEvent).toBe(true);
    expect(plan.sulbunEvent?.cycle_id).toBe('c1');
    expect(plan.sulbunEvent?.auto_reset_enabled).toBe(true);
  });
});
