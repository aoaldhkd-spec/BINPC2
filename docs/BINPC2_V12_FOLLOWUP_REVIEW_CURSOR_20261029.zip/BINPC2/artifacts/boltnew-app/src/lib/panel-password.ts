import { supabase } from './supabase';

export async function verifyPanelPassword(
  kind: 'reset' | 'admin' | 'test',
  password: string,
): Promise<'ok' | 'bad' | 'limited'> {
  try {
    const { data, error } = await supabase.rpc('verify_panel_password', {
      p_kind: kind,
      p_password: password,
    });
    const msg = String((error as { message?: string } | null)?.message ?? '');
    if (/429|너무 많|RATE_LIMIT/i.test(msg)) return 'limited';
    if (error) return 'bad';
    return (data as { ok?: boolean } | null)?.ok ? 'ok' : 'bad';
  } catch {
    return 'bad';
  }
}

export function navigateToAppPath(path: 'admin' | 'test'): void {
  const base = import.meta.env.BASE_URL;
  window.history.pushState({}, '', `${base}${path}`);
  window.dispatchEvent(new PopStateEvent('popstate'));
}

export const ADMIN_FIXED_NICKNAME = '범일NPC';

/** Numeric PIN/password fields — mobile numeric keyboard (iOS/Android) while type="password" masks input. */
export const PANEL_PIN_INPUT_PROPS = {
  inputMode: 'numeric' as const,
  pattern: '[0-9]*',
  autoComplete: 'one-time-code' as const,
};

/** App-wide alias — entry codes, panel gates, admin credentials. */

/** Single-digit PIN box (profile recovery, waiting overlay). */
export const PIN_DIGIT_INPUT_PROPS = {
  inputMode: 'numeric' as const,
  pattern: '\\d*',
} as const;
