// ─── 공유 상수 ────────────────────────────────────────────────────────────────

// ─── localStorage 키 ────────────────────────────────────────────────────────
export const MATCHING_USER_KEY = 'matching_app_user_id';
export const MATCHING_DRAFT_KEY = 'matching_app_draft_step1';
export const MATCHING_LAST_RESET_KEY = 'matching_app_last_reset_signal';
export const MATCHING_PROFILES_CACHE_KEY = 'matching_profiles_cache';
export const SCANNED_CONTACTS_KEY = 'matching_scanned_contacts';

// ─── MBTI 목록 ───────────────────────────────────────────────────────────────
export const MBTI_LIST = [
  'INTJ', 'INTP', 'ENTJ', 'ENTP',
  'INFJ', 'INFP', 'ENFJ', 'ENFP',
  'ISTJ', 'ISFJ', 'ESTJ', 'ESFJ',
  'ISTP', 'ISFP', 'ESTP', 'ESFP',
] as const;



// ─── 하트 유형 ───────────────────────────────────────────────────────────────
export type HeartType = 'red' | 'blue' | 'pink' | 'green';

export const HEART_TYPES: {
  type: HeartType;
  label: string;
  desc: string;
  bg: string;
  border: string;
  ring: string;
  text: string;
  fillText: string;
  solidBg: string;
  solidHover: string;
  emoji: string;
}[] = [
  { type: 'red', label: '호감', desc: '로맨틱한 호감을 표현해요', bg: 'bg-rose-50', border: 'border-rose-300', ring: 'ring-rose-200', text: 'text-rose-700', fillText: 'fill-rose-400 text-rose-400', solidBg: 'bg-rose-500', solidHover: 'hover:bg-rose-600', emoji: '❤️' },
  { type: 'blue', label: '친구', desc: '친구가 되고 싶을 때 보내요', bg: 'bg-blue-50', border: 'border-blue-300', ring: 'ring-blue-200', text: 'text-blue-700', fillText: 'fill-blue-400 text-blue-400', solidBg: 'bg-blue-500', solidHover: 'hover:bg-blue-600', emoji: '💙' },
  { type: 'pink', label: '뜨밤', desc: '함께 밤을 보내고 싶어요', bg: 'bg-pink-50', border: 'border-pink-300', ring: 'ring-pink-200', text: 'text-pink-700', fillText: 'fill-pink-400 text-pink-400', solidBg: 'bg-pink-500', solidHover: 'hover:bg-pink-600', emoji: '💗' },
  { type: 'green', label: '칭찬', desc: '칭찬만 전달 (연락처 공유 불가)', bg: 'bg-emerald-50', border: 'border-emerald-300', ring: 'ring-emerald-200', text: 'text-emerald-700', fillText: 'fill-emerald-400 text-emerald-400', solidBg: 'bg-emerald-500', solidHover: 'hover:bg-emerald-600', emoji: '💚' },
];

export const HEART_META = {
  red: { label: '호감', emoji: '❤️', color: '#ef4444' },
  blue: { label: '친구', emoji: '💙', color: '#3b82f6' },
  pink: { label: '뜨밤', emoji: '💗', color: '#ec4899' },
  green: { label: '칭찬', emoji: '💚', color: '#10b981' },
} as const;

/** Convenience wrapper — looks up full metadata for a HeartType */
export const heartMeta = (t: HeartType) => HEART_TYPES.find(h => h.type === t)!;

/** Participant picker / notifications — classic 호감·친구·뜨밤·칭찬 names. */
export const HEART_TYPE_META: Record<string, { emoji: string; label: string; color: string; bg: string }> = {
  red: { emoji: '❤️', label: '호감', color: 'text-rose-600', bg: 'bg-rose-100' },
  blue: { emoji: '💙', label: '친구', color: 'text-blue-600', bg: 'bg-blue-100' },
  pink: { emoji: '💗', label: '뜨밤', color: 'text-pink-600', bg: 'bg-pink-100' },
  green: { emoji: '💚', label: '칭찬', color: 'text-emerald-600', bg: 'bg-emerald-100' },
};

/** Header / admin color chips only — never used as LikeConfirmDialog names. */
export const HEART_COLOR_LABELS: Record<HeartType, { emoji: string; label: string }> = {
  red: { emoji: '❤️', label: '호감' },
  blue: { emoji: '💙', label: '친구' },
  pink: { emoji: '💗', label: '뜨밤' },
  green: { emoji: '💚', label: '칭찬' },
};
