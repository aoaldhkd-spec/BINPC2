import { HEART_TYPES, type HeartType } from './constants';

/** Stored in app_settings.event_schedule (version 2). */
export type HeartUnlockKey = HeartType | 'rainbow';

export type HeartOpsDirectNotice = {
  id: string;
  text: string;
  at?: string;
  enabled?: boolean;
};

export type HeartOpsSlot = {
  id: string;
  /** Seoul HH:mm — 24:00 / 24:30 allowed (next calendar day after midnight). Unlock clock. */
  at: string;
  /** Display-only notice clock. Unlock still uses `at`. */
  notice_at?: string;
  /** When true, participant banner may show this slot's notice time. */
  show_notice?: boolean;
  unlock: HeartUnlockKey[];
};

export type HeartOpsBannerDisplay = {
  show_notice_time: boolean;
  show_unlock_time: boolean;
  show_countdown: boolean;
};

export type HeartOpsConfig = {
  timezone: 'Asia/Seoul';
  version: 2;
  slots: HeartOpsSlot[];
  /** Immediate unlocks persisted across saves. */
  instant_unlock?: HeartUnlockKey[];
  /** Operator broadcast (separate from auto schedule copy). */
  direct_notice?: string;
  /** Scheduled operator notices. Banner shows the first due enabled row. */
  direct_notices?: HeartOpsDirectNotice[];
  /**
   * Event-minute hold after 해금 초기화 (same event night only).
   * Slots with `at` ≤ this stay locked unless listed in `instant_unlock`.
   * A leftover hold from a previous night (nowEventMinute < hold) does not block today.
   */
  auto_unlock_from?: number;
  /** Participant auto-notice: 공지시간. Default off. */
  show_notice_time?: boolean;
  /** Participant auto-notice: 해금시간. Default on. */
  show_unlock_time?: boolean;
  /** Participant auto-notice: 해금까지 카운트다운. Default on. */
  show_countdown?: boolean;
};

export type HeartUsage = {
  grantUsed: Record<HeartType, boolean>;
  rainbowUsed: number;
};

export const RAINBOW_MAX_USES = 4;

export const HEART_OPS_ROW_KEYS: HeartUnlockKey[] = ['red', 'blue', 'pink', 'green', 'rainbow'];

export const DEFAULT_HEART_OPS_SLOTS: HeartOpsSlot[] = [
  { id: 'slot-1', at: '23:00', unlock: ['red'] },
  { id: 'slot-2', at: '23:00', unlock: ['blue'] },
  { id: 'slot-3', at: '23:00', unlock: ['pink', 'green'] },
  { id: 'slot-4', at: '24:00', unlock: ['rainbow'] },
];

export function defaultHeartOpsAt(key: HeartUnlockKey): string {
  return key === 'rainbow' ? '24:00' : '23:00';
}

export const DEFAULT_HEART_OPS: HeartOpsConfig = {
  timezone: 'Asia/Seoul',
  version: 2,
  slots: DEFAULT_HEART_OPS_SLOTS.map(s => ({ ...s, unlock: [...s.unlock] })),
  instant_unlock: [],
  direct_notice: '',
};

const TYPES: HeartType[] = ['red', 'blue', 'pink', 'green'];
/** HH:mm including 24:00–24:59 for post-midnight event slots. */
export const HEART_OPS_AT_RE = /^([01]\d|2[0-4]):([0-5]\d)$/;

/** Split stored `HH:MM` (including 24:xx) for hour/minute editors. */
export function parseHeartOpsClock(at: string): { hour: number; minute: number } {
  if (!HEART_OPS_AT_RE.test(at)) return { hour: 23, minute: 0 };
  return { hour: Number(at.slice(0, 2)), minute: Number(at.slice(3, 5)) };
}

/** Build `HH:MM` including 24:00–24:59. Invalid values return null. */
export function formatHeartOpsClock(hour: number, minute: number): string | null {
  if (!Number.isInteger(hour) || !Number.isInteger(minute)) return null;
  if (hour < 0 || hour > 24 || minute < 0 || minute > 59) return null;
  const at = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  return HEART_OPS_AT_RE.test(at) ? at : null;
}

/** Change one slot's `at` only — never drops sibling slots or unlock lists. */
export function patchHeartOpsSlotAt(
  slots: HeartOpsSlot[],
  index: number,
  hour: number,
  minute: number,
): HeartOpsSlot[] {
  const at = formatHeartOpsClock(hour, minute);
  if (!at) return slots;
  return slots.map((s, i) => (i === index ? { ...s, at } : s));
}

/** Change one slot's display `notice_at` only — never changes unlock `at`. */
export function patchHeartOpsSlotNoticeAt(
  slots: HeartOpsSlot[],
  index: number,
  hour: number,
  minute: number,
): HeartOpsSlot[] {
  const noticeAt = formatHeartOpsClock(hour, minute);
  if (!noticeAt) return slots;
  return slots.map((s, i) => (i === index ? { ...s, notice_at: noticeAt } : s));
}

export function slotNoticeAt(slot: HeartOpsSlot): string {
  return typeof slot.notice_at === 'string' && HEART_OPS_AT_RE.test(slot.notice_at) ? slot.notice_at : slot.at;
}

export function slotShowsNotice(slot: HeartOpsSlot, config: HeartOpsConfig): boolean {
  if (slot.show_notice === true) return true;
  if (slot.show_notice === false) return false;
  return config.show_notice_time === true;
}

/** One admin/banner row per heart. Shared pink+green slots expand into two rows. */
export function heartOpsHeartRows(config: HeartOpsConfig): HeartOpsSlot[] {
  const noticeFallback = config.show_notice_time === true;
  return HEART_OPS_ROW_KEYS.map(key => {
    const owned = config.slots.find(s => s.unlock.includes(key));
    const parked = config.slots.find(s => s.id === `slot-${key}`);
    const src = owned ?? parked;
    const at = src && HEART_OPS_AT_RE.test(src.at) ? src.at : defaultHeartOpsAt(key);
    const noticeAt = src ? slotNoticeAt(src) : at;
    const showNotice = src?.show_notice === true || (src?.show_notice == null && noticeFallback && !!owned);
    return {
      id: `slot-${key}`,
      at,
      notice_at: noticeAt,
      unlock: owned ? [key] : [],
      ...(showNotice ? { show_notice: true } : {}),
    };
  });
}

function slotBannerKeys(slot: HeartOpsSlot): HeartUnlockKey[] {
  if (slot.unlock.length) return slot.unlock;
  const key = HEART_OPS_ROW_KEYS.find(k => slot.id === `slot-${k}`);
  return key ? [key] : [];
}

export function resolveHeartOpsBannerDisplay(config: HeartOpsConfig): HeartOpsBannerDisplay {
  return {
    show_notice_time: config.show_notice_time === true,
    show_unlock_time: config.show_unlock_time !== false,
    show_countdown: config.show_countdown !== false,
  };
}

function serializeBannerDisplay(config: {
  show_notice_time?: boolean;
  show_unlock_time?: boolean;
  show_countdown?: boolean;
}): Partial<HeartOpsBannerDisplay> {
  return {
    ...(config.show_notice_time ? { show_notice_time: true } : {}),
    ...(config.show_unlock_time === false ? { show_unlock_time: false } : {}),
    ...(config.show_countdown === false ? { show_countdown: false } : {}),
  };
}

const HEART_OPS_CLOCK_MAX_MIN = 24 * 60 + 59;

/** Step `HH:MM` by minutes, wrapping 00:00–24:59 so 24:xx stays valid. */
export function stepHeartOpsClock(at: string, deltaMinutes: number): string {
  const { hour, minute } = parseHeartOpsClock(at);
  const span = HEART_OPS_CLOCK_MAX_MIN + 1;
  let total = hour * 60 + minute + deltaMinutes;
  total = ((total % span) + span) % span;
  return formatHeartOpsClock(Math.floor(total / 60), total % 60) ?? at;
}

/** Step hour only (0–24), keep the minute. */
export function stepHeartOpsHour(at: string, deltaHours: number): string {
  const { hour, minute } = parseHeartOpsClock(at);
  return formatHeartOpsClock(((hour + deltaHours) % 25 + 25) % 25, minute) ?? at;
}

/** Open the like picker when any grant type remains, or rainbow still has uses. */
export function canOpenHeartPicker(sentTypeCount: number, rainbowLeft: number): boolean {
  return sentTypeCount < TYPES.length || rainbowLeft > 0;
}

export function heartLabel(key: HeartUnlockKey): string {
  if (key === 'rainbow') return '무지개';
  return HEART_TYPES.find(h => h.type === key)?.label ?? key;
}

export function formatHeartOpsTime(at: string): string {
  const h = Number(at.slice(0, 2));
  const m = at.slice(3);
  if (h >= 24) return `${h}:${m}`;
  return at;
}

export function slotEventMinute(at: string): number {
  return Number(at.slice(0, 2)) * 60 + Number(at.slice(3));
}

export function seoulClockParts(now = new Date()): { hour: number; minute: number; second: number } {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).formatToParts(now);
  const hour = Number(parts.find(p => p.type === 'hour')?.value ?? 0);
  const minute = Number(parts.find(p => p.type === 'minute')?.value ?? 0);
  const second = Number(parts.find(p => p.type === 'second')?.value ?? 0);
  return { hour: hour === 24 ? 0 : hour, minute, second };
}

/** Event timeline minute: evening 23:xx and post-midnight 00:xx–06:xx on one axis. */
export function nowEventMinute(now = new Date()): number {
  const { hour, minute } = seoulClockParts(now);
  let base = hour * 60 + minute;
  if (hour < 7) base += 1440;
  return base;
}

export function parseHeartOpsDirectNotices(raw: unknown): HeartOpsDirectNotice[] {
  if (!Array.isArray(raw)) return [];
  const out: HeartOpsDirectNotice[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id.trim() || typeof r.text !== 'string') continue;
    const at = typeof r.at === 'string' && HEART_OPS_AT_RE.test(r.at) ? r.at : undefined;
    out.push({
      id: r.id,
      text: r.text.slice(0, 240),
      ...(at ? { at } : {}),
      ...(r.enabled === true ? { enabled: true } : {}),
    });
    if (out.length >= 4) break;
  }
  return out;
}

/** First enabled notice whose clock has arrived. Missing `at` stays immediately due (legacy). */
export function dueDirectNoticeText(items: HeartOpsDirectNotice[] | undefined, now = new Date()): string {
  if (!items?.length) return '';
  const minute = nowEventMinute(now);
  const hit = items.find(n => {
    if (n.enabled !== true || !n.text.trim()) return false;
    if (!n.at || !HEART_OPS_AT_RE.test(n.at)) return true;
    return slotEventMinute(n.at) <= minute;
  });
  return hit?.text.trim().slice(0, 240) ?? '';
}

export function resolveDirectNotice(config: HeartOpsConfig, now = new Date()): string {
  if (config.direct_notices?.length) return dueDirectNoticeText(config.direct_notices, now);
  return (config.direct_notice ?? '').trim();
}

function parseUnlockList(raw: unknown): HeartUnlockKey[] {
  if (!Array.isArray(raw)) return [];
  const out: HeartUnlockKey[] = [];
  for (const v of raw) {
    if (v === 'rainbow') { out.push('rainbow'); continue; }
    if (typeof v === 'string' && (TYPES as string[]).includes(v)) out.push(v as HeartType);
  }
  return [...new Set(out)];
}

function migrateV1Slot(row: Record<string, unknown>, index: number): HeartOpsSlot | null {
  const at = typeof row.at === 'string' && HEART_OPS_AT_RE.test(row.at) ? row.at : null;
  if (!at) return null;
  const unlock: HeartUnlockKey[] = [];
  const grants = row.heart_grants;
  if (grants && typeof grants === 'object' && !Array.isArray(grants)) {
    for (const t of TYPES) {
      const n = Number((grants as Record<string, unknown>)[t]);
      if (Number.isFinite(n) && n > 0) unlock.push(t);
    }
  }
  const rainbowPool = Number(row.rainbow_pool);
  if (Number.isFinite(rainbowPool) && rainbowPool > 0) unlock.push('rainbow');
  return {
    id: typeof row.id === 'string' ? row.id : `slot-${index + 1}`,
    at,
    unlock,
  };
}

export function parseHeartOps(raw: unknown): HeartOpsConfig {
  let value = raw;
  if (typeof value === 'string') {
    try { value = JSON.parse(value); } catch { value = null; }
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return { ...DEFAULT_HEART_OPS, slots: DEFAULT_HEART_OPS.slots.map(s => ({ ...s, unlock: [...s.unlock] })) };
  }
  const obj = value as Record<string, unknown>;
  const version = Number(obj.version);
  const rows = Array.isArray(obj.slots) ? obj.slots : [];

  let slots: HeartOpsSlot[];
  if (version === 2) {
    slots = rows.flatMap((v, i) => {
      if (!v || typeof v !== 'object' || Array.isArray(v)) return [];
      const r = v as Record<string, unknown>;
      const at = typeof r.at === 'string' && HEART_OPS_AT_RE.test(r.at) ? r.at : null;
      if (!at) return [];
      const unlock = parseUnlockList(r.unlock);
      const noticeAt = typeof r.notice_at === 'string' && HEART_OPS_AT_RE.test(r.notice_at) ? r.notice_at : undefined;
      return [{
        id: typeof r.id === 'string' ? r.id.slice(0, 64) : `slot-${i + 1}`,
        at,
        unlock,
        ...(noticeAt ? { notice_at: noticeAt } : {}),
        ...(r.show_notice === true ? { show_notice: true } : {}),
      }];
    });
  } else {
    slots = rows.flatMap((v, i) => {
      if (!v || typeof v !== 'object' || Array.isArray(v)) return [];
      const migrated = migrateV1Slot(v as Record<string, unknown>, i);
      return migrated ? [migrated] : [];
    });
  }

  if (!slots.length) {
    slots = DEFAULT_HEART_OPS.slots.map(s => ({ ...s, unlock: [...s.unlock] }));
  }
  slots.sort((a, b) => slotEventMinute(a.at) - slotEventMinute(b.at));

  const instant = parseUnlockList(obj.instant_unlock);
  const directNotice = typeof obj.direct_notice === 'string' ? obj.direct_notice.slice(0, 240) : '';
  const directNotices = parseHeartOpsDirectNotices(obj.direct_notices);
  const autoUnlockFrom = parseAutoUnlockFrom(obj.auto_unlock_from);

  return {
    timezone: 'Asia/Seoul',
    version: 2,
    slots,
    instant_unlock: instant,
    direct_notice: directNotice,
    ...(directNotices.length ? { direct_notices: directNotices } : {}),
    ...(autoUnlockFrom != null ? { auto_unlock_from: autoUnlockFrom } : {}),
    ...serializeBannerDisplay({
      show_notice_time: obj.show_notice_time === true,
      show_unlock_time: obj.show_unlock_time !== false,
      show_countdown: obj.show_countdown !== false,
    }),
  };
}

export function serializeHeartOps(config: HeartOpsConfig): string {
  const clean: HeartOpsConfig = {
    timezone: 'Asia/Seoul',
    version: 2,
    slots: config.slots.map(s => ({
      id: s.id,
      at: s.at,
      unlock: [...new Set(s.unlock)],
      ...(s.notice_at && HEART_OPS_AT_RE.test(s.notice_at) ? { notice_at: s.notice_at } : {}),
      ...(s.show_notice ? { show_notice: true } : {}),
    })),
    ...(config.instant_unlock?.length ? { instant_unlock: [...new Set(config.instant_unlock)] } : {}),
    ...(config.direct_notice?.trim() ? { direct_notice: config.direct_notice.trim().slice(0, 240) } : {}),
    ...(config.direct_notices?.length ? {
      direct_notices: config.direct_notices.slice(0, 4).map(n => ({
        id: n.id,
        text: n.text.slice(0, 240),
        ...(n.at && HEART_OPS_AT_RE.test(n.at) ? { at: n.at } : {}),
        ...(n.enabled ? { enabled: true } : {}),
      })),
    } : {}),
    ...(config.auto_unlock_from != null ? { auto_unlock_from: config.auto_unlock_from } : {}),
    ...serializeBannerDisplay(config),
  };
  return JSON.stringify(clean);
}

export function coerceEventScheduleRaw(raw: unknown): string | null {
  if (raw == null) return null;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    return trimmed ? trimmed : null;
  }
  if (typeof raw === 'object') {
    try { return JSON.stringify(raw); } catch { return null; }
  }
  return null;
}

function parseAutoUnlockFrom(raw: unknown): number | undefined {
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n) || n < 0 || n > 2000) return undefined;
  return n;
}

function slotHeldByReset(config: HeartOpsConfig, at: string, now = new Date()): boolean {
  const hold = config.auto_unlock_from;
  if (hold == null || !Number.isFinite(hold)) return false;
  // Event night rolls at 07:00 Seoul (00:00–06:59 are +1440). A hold from last night
  // has a larger minute than this afternoon/evening, so it must not keep today's slots locked.
  if (nowEventMinute(now) < hold) return false;
  return slotEventMinute(at) <= hold;
}

/** Relock all five types without touching slot times, unlock lists, notices, or likes. */
export function resetHeartUnlocks(config: HeartOpsConfig, now = new Date()): HeartOpsConfig {
  return {
    timezone: 'Asia/Seoul',
    version: 2,
    slots: config.slots.map(s => ({ ...s, unlock: [...s.unlock] })),
    instant_unlock: [],
    direct_notice: config.direct_notice ?? '',
    ...(config.direct_notices?.length ? { direct_notices: config.direct_notices } : {}),
    auto_unlock_from: nowEventMinute(now),
    ...serializeBannerDisplay(config),
  };
}

export function unlockedHeartKeys(config: HeartOpsConfig, now = new Date()): Set<HeartUnlockKey> {
  const minute = nowEventMinute(now);
  const keys = new Set<HeartUnlockKey>();
  for (const slot of config.slots) {
    if (slotHeldByReset(config, slot.at, now)) continue;
    if (slotEventMinute(slot.at) <= minute) {
      for (const k of slot.unlock) keys.add(k);
    }
  }
  for (const k of config.instant_unlock ?? []) keys.add(k);
  return keys;
}

export function emptyHeartUsage(): HeartUsage {
  return { grantUsed: { red: false, blue: false, pink: false, green: false }, rainbowUsed: 0 };
}

export function heartUsageFromLikeRows(rows: Record<string, unknown>[], likerId: string): HeartUsage {
  const usage = emptyHeartUsage();
  for (const row of rows) {
    if (String(row.liker_id) !== likerId) continue;
    const type = String(row.heart_type ?? '');
    if (String(row.like_source) === 'rainbow') {
      usage.rainbowUsed += 1;
    } else if ((TYPES as string[]).includes(type)) {
      usage.grantUsed[type as HeartType] = true;
    }
  }
  return usage;
}

export function grantRemaining(config: HeartOpsConfig, usage: HeartUsage, type: HeartType, now = new Date()): 0 | 1 {
  if (!unlockedHeartKeys(config, now).has(type)) return 0;
  return usage.grantUsed[type] ? 0 : 1;
}

export function rainbowRemaining(config: HeartOpsConfig, usage: HeartUsage, now = new Date()): number {
  if (!unlockedHeartKeys(config, now).has('rainbow')) return 0;
  return Math.max(0, RAINBOW_MAX_USES - usage.rainbowUsed);
}

export type ParticipantHeartState = {
  unlocked: Set<HeartUnlockKey>;
  grantRemaining: Record<HeartType, 0 | 1>;
  rainbowRemaining: number;
  heartsLocked: boolean;
};

export function participantHeartState(
  config: HeartOpsConfig,
  usage: HeartUsage,
  functionsLocked: boolean,
  now = new Date(),
): ParticipantHeartState {
  const unlocked = unlockedHeartKeys(config, now);
  const grantRemainingMap = {
    red: grantRemaining(config, usage, 'red', now),
    blue: grantRemaining(config, usage, 'blue', now),
    pink: grantRemaining(config, usage, 'pink', now),
    green: grantRemaining(config, usage, 'green', now),
  } as Record<HeartType, 0 | 1>;
  const rainbowRem = rainbowRemaining(config, usage, now);
  const anyHeart = unlocked.size > 0 && (
    grantRemainingMap.red + grantRemainingMap.blue + grantRemainingMap.pink + grantRemainingMap.green + rainbowRem > 0
  );
  return {
    unlocked,
    grantRemaining: grantRemainingMap,
    rainbowRemaining: rainbowRem,
    heartsLocked: functionsLocked || !anyHeart,
  };
}

export type HeaderHeartChip = {
  key: 'rainbow' | HeartType;
  testId: string;
  emoji: string;
  label: string;
  remaining: number;
  locked: boolean;
};

export function headerHeartRemainings(input: {
  functionsLocked: boolean;
  config: HeartOpsConfig;
  usage: HeartUsage;
  now?: Date;
}): HeaderHeartChip[] {
  const now = input.now ?? new Date();
  const state = participantHeartState(input.config, input.usage, input.functionsLocked, now);
  const meta = (type: HeartType) => HEART_TYPES.find(h => h.type === type)!;
  const color = (type: HeartType, testId: string): HeaderHeartChip => {
    const rem = state.grantRemaining[type];
    const isUnlocked = state.unlocked.has(type);
    return {
      key: type,
      testId,
      emoji: meta(type).emoji,
      label: meta(type).label,
      remaining: rem,
      // functionsLocked blocks the send server-side, so the chip must look locked too.
      // `remaining` stays untouched so the pre-lock state returns as-is when unlocked.
      locked: input.functionsLocked || !isUnlocked || rem <= 0,
    };
  };
  const rainbowLocked = !state.unlocked.has('rainbow') || state.rainbowRemaining <= 0 || input.functionsLocked;
  return [
    {
      key: 'rainbow',
      testId: 'home-heart-remaining-rainbow',
      emoji: rainbowLocked ? '🔒🌈' : '🌈',
      label: '무지개',
      remaining: state.rainbowRemaining,
      locked: rainbowLocked,
    },
    color('red', 'home-heart-remaining-red'),
    color('pink', 'home-heart-remaining-pink'),
    color('blue', 'home-heart-remaining-blue'),
    color('green', 'home-heart-remaining-green'),
  ];
}

export type HeartOpsBannerState = {
  show: boolean;
  directNotice: string | null;
  autoLine: string | null;
  countdownSec: number | null;
  justUnlocked: string | null;
};

export function heartOpsBannerState(config: HeartOpsConfig, now = new Date()): HeartOpsBannerState {
  const direct = resolveDirectNotice(config, now);
  const minute = nowEventMinute(now);
  const { second } = seoulClockParts(now);

  const passed = config.slots.filter(s => !slotHeldByReset(config, s.at, now) && slotEventMinute(s.at) <= minute);
  const justSlot = passed.find(s => {
    const sm = slotEventMinute(s.at);
    return minute === sm || (minute - sm <= 1 && second < 60);
  });
  let justUnlocked: string | null = null;
  if (justSlot?.unlock.length) {
    const names = justSlot.unlock.map(heartLabel).join('·');
    justUnlocked = `${names} 하트가 해금되었습니다`;
  }

  const nextUnlock = config.slots.find(s => !slotHeldByReset(config, s.at, now) && slotEventMinute(s.at) > minute && s.unlock.length > 0) ?? null;
  const nextNotice = config.slots.find(s => slotShowsNotice(s, config) && slotEventMinute(slotNoticeAt(s)) > minute) ?? null;
  const next = nextUnlock ?? nextNotice;
  const display = resolveHeartOpsBannerDisplay(config);
  let autoLine: string | null = null;
  let countdownSec: number | null = null;
  if (next) {
    const names = slotBannerKeys(next).map(heartLabel).join('·');
    const parts: string[] = [];
    if (slotShowsNotice(next, config)) parts.push(`${formatHeartOpsTime(slotNoticeAt(next))} 공지`);
    if (next.unlock.length && display.show_unlock_time) parts.push(`${formatHeartOpsTime(next.at)} 해금`);
    if (names && parts.length) autoLine = `${names} 하트 ${parts.join(' · ')}`;
    if (next.unlock.length && display.show_countdown) {
      countdownSec = Math.max(0, (slotEventMinute(next.at) - minute) * 60 - second);
    }
  }

  const show = Boolean(direct || autoLine || justUnlocked || next);
  return { show, directNotice: direct || null, autoLine, countdownSec, justUnlocked };
}

/** Legacy slot flags (functions_locked) from stored JSON. */
export function currentEventSlot(raw: unknown, now = new Date()): { functions_locked?: boolean; notice?: string } | null {
  let value = raw;
  if (typeof value === 'string') {
    try { value = JSON.parse(value); } catch { value = null; }
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const rows = (value as Record<string, unknown>).slots;
  if (!Array.isArray(rows)) return null;
  const minute = nowEventMinute(now);
  let active: Record<string, unknown> | null = null;
  for (const item of rows) {
    if (!item || typeof item !== 'object') continue;
    const at = (item as Record<string, unknown>).at;
    if (typeof at === 'string' && HEART_OPS_AT_RE.test(at) && slotEventMinute(at) <= minute) {
      active = item as Record<string, unknown>;
    }
  }
  if (!active) return null;
  return {
    ...(typeof active.functions_locked === 'boolean' ? { functions_locked: active.functions_locked } : {}),
    ...(typeof active.notice === 'string' && active.notice ? { notice: active.notice.slice(0, 240) } : {}),
  };
}

export function adminHeartStatusLine(config: HeartOpsConfig, now = new Date()): { key: HeartUnlockKey; locked: boolean }[] {
  const unlocked = unlockedHeartKeys(config, now);
  const order: HeartUnlockKey[] = ['red', 'blue', 'pink', 'green', 'rainbow'];
  return order.map(key => ({ key, locked: !unlocked.has(key) }));
}
