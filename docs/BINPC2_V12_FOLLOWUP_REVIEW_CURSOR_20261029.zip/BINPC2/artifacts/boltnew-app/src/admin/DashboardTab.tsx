import { useState } from 'react';
import { Trash2, PlayCircle, StopCircle, Lock, Unlock } from 'lucide-react';
import type { Profile, AppSettings } from './shared';
import { ConfirmDialog } from './ConfirmDialog';

// ─── Dashboard Tab ────────────────────────────────────────────────────────────

export function DashboardTab({ settings, profiles, onToggleSession, onEventEndReset, onToggleFunctionsLock,
  onClearLikes, onClearChats, onClearProfiles, onClearHistory,
  restoreMap }: {
  settings: AppSettings | null; profiles: Profile[];
  onToggleSession: () => void; onEventEndReset: () => void;
  onToggleFunctionsLock: () => void;
  onClearLikes: () => Promise<void>;
  onClearChats: () => Promise<void>;
  onClearProfiles: () => Promise<void>;
  onClearHistory: () => Promise<void>;
  restoreMap: Map<string, () => Promise<void>>;
}) {
  const [confirmToggle, setConfirmToggle] = useState<'start' | 'end' | null>(null);
  const [confirmEventEnd, setConfirmEventEnd] = useState(false);
  const [confirmAction, setConfirmAction] = useState<{ title: string; message: string; onConfirm: () => void } | null>(null);
  const isActive = settings?.session_active ?? false;
  const isFunctionsLocked = settings?.functions_locked ?? false;

  return (
    <div className="space-y-5 p-5">
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: '참여자', value: profiles.length, color: 'bg-cyan-50 text-cyan-700' },
        ].map((stat) => (
          <div key={stat.label} className={`${stat.color} rounded-2xl p-5 text-center`}>
            <div className="text-2xl font-black">{stat.value}</div>
            <div className="text-xs font-semibold mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* 잠금 제어 */}
      <div>
        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">잠금 제어</h3>
        <div className="space-y-2">
          {/* 기능 잠금 (functions_locked) */}
          <button
            type="button"
            data-testid="functions-lock-btn"
            onClick={onToggleFunctionsLock}
            className={`relative touch-target w-full rounded-2xl p-4 border-2 flex flex-wrap items-center gap-3 transition-all active:scale-[0.98] shadow-sm cursor-pointer touch-manipulation ${
              isFunctionsLocked ? 'bg-red-50 border-red-300 hover:bg-red-100' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${isFunctionsLocked ? 'bg-red-500' : 'bg-slate-400'}`}>
              {isFunctionsLocked ? <Lock className="w-5 h-5 text-white" /> : <Unlock className="w-5 h-5 text-white" />}
            </div>
            <div className="flex-1 text-left min-w-0">
              <p className={`font-black text-sm break-words ${isFunctionsLocked ? 'text-red-700' : 'text-slate-700'}`}>
                {isFunctionsLocked ? '🔒 채팅·기능 잠금 중' : '💬 채팅·기능 열려있음'}
              </p>
              <p className={`text-[10px] mt-0.5 break-words ${isFunctionsLocked ? 'text-red-500' : 'text-slate-400'}`}>
                {isFunctionsLocked ? 'MY·단톡 사용 불가 — 통계·랭킹·설정은 그대로 — 탭하여 해제' : 'MY·단톡 잠금 가능 — 통계·랭킹·설정은 항상 열림 — 탭하여 잠금'}
              </p>
            </div>
            <div className={`relative w-10 h-6 rounded-full transition-all flex-shrink-0 ${isFunctionsLocked ? 'bg-red-500' : 'bg-slate-300'}`}>
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${isFunctionsLocked ? 'left-4' : 'left-0.5'}`} />
            </div>
          </button>
        </div>
      </div>

      <div data-testid="daily-cycle-card" className="rounded-2xl border-2 border-violet-200 bg-violet-50 p-4">
        <h3 className="text-sm font-black text-violet-900 mb-2">⏰ 회식 시작 후 자동 운영</h3>
        <div className="grid grid-cols-2 gap-2 text-[11px] font-bold text-violet-800">
          <div className="rounded-xl bg-white/80 p-2">23:00 · ❤️💙💗💚 일반 하트 자동 해금</div>
          <div className="rounded-xl bg-white/80 p-2">24:00 · 🌈 무지개하트 자동 해금</div>
          <div className="rounded-xl bg-white/80 p-2">01:00 · 🚪 신규 입장 자동 마감</div>
          <div className="rounded-xl bg-white/80 p-2">다음 17:00 · ♻️ 시작된 회식만 초기화</div>
        </div>
        <p className="mt-2 text-[10px] font-semibold text-violet-600">
          하트시간·공지시간은 따로 설정하지 않습니다. 관리자가 회식을 시작한 행사에만 적용됩니다.
        </p>
      </div>

      {/* Session control — 수동 비상/현장 제어는 기존처럼 유지 */}
      <div>
        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">회식 세션</h3>
        <div className="relative grid grid-cols-2 gap-3">
          <button
            type="button"
            data-testid="session-start-btn"
            onClick={() => setConfirmToggle('start')}
            disabled={isActive}
            className={`touch-target rounded-2xl p-4 border-2 flex flex-col items-center gap-2 transition-all touch-manipulation ${
              !isActive
                ? 'bg-teal-50 border-teal-300 hover:bg-teal-100 active:scale-95 shadow-sm cursor-pointer'
                : 'bg-gray-50 border-gray-200 opacity-45 cursor-not-allowed'
            }`}
          >
            <PlayCircle className="w-7 h-7 text-teal-700" />
            <span className="text-sm font-black text-teal-700">회식 시작</span>
            <span className="text-[10px] font-medium text-teal-700">
              {isActive ? '진행 중' : '클릭하여 세션 열기'}
            </span>
          </button>
          <button
            type="button"
            data-testid="session-end-btn"
            onClick={() => setConfirmToggle('end')}
            disabled={!isActive}
            className={`touch-target rounded-2xl p-4 border-2 flex flex-col items-center gap-2 transition-all touch-manipulation ${
              isActive
                ? 'bg-red-50 border-red-300 hover:bg-red-100 active:scale-95 shadow-sm cursor-pointer'
                : 'bg-gray-50 border-gray-200 opacity-45 cursor-not-allowed'
            }`}
          >
            <StopCircle className="w-7 h-7 text-red-500" />
            <span className="text-sm font-black text-red-700">회식 종료</span>
            <span className="text-[10px] font-medium text-red-500">
              {isActive ? '클릭하여 세션 닫기' : '대기 중'}
            </span>
          </button>
        </div>
      </div>

      {/* 데이터 초기화 */}
      <div>
        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">데이터 초기화 / 복구</h3>
        <div className="space-y-2.5">
          {([
            { key: 'likes', emoji: '❤️', label: '하트', desc: '모든 하트 기록 삭제', bg: 'bg-pink-50 border-pink-200 hover:bg-pink-100', title: '하트 초기화', msg: '모든 하트(좋아요) 기록을 삭제합니다.', fn: onClearLikes },
            { key: 'chats', emoji: '💬', label: '채팅', desc: '채팅·메시지 전체 삭제', bg: 'bg-teal-50 border-teal-200 hover:bg-teal-100', title: '채팅 초기화', msg: '모든 채팅방과 메시지를 삭제합니다.', fn: onClearChats },
            { key: 'profiles', emoji: '👤', label: '참여자', desc: '모든 프로필 삭제', bg: 'bg-indigo-50 border-indigo-200 hover:bg-indigo-100', title: '참여자 초기화', msg: '모든 참여자 프로필을 삭제합니다.', fn: onClearProfiles },
            { key: 'history', emoji: '📋', label: '기존 이력', desc: '옛 session_history만 삭제 · 익명 행사기록은 유지', bg: 'bg-emerald-50 border-emerald-200 hover:bg-emerald-100', title: '기존 이력 초기화', msg: '옛 session_history 기록만 삭제합니다. 새 익명 행사기록과 매출 집계는 보존됩니다.', fn: onClearHistory },
          ] as const).map(item => {
            const hasRestore = restoreMap.has(item.key);
            return (
              <div key={item.label} className="flex gap-1.5">
                <button
                  onClick={() => setConfirmAction({ title: item.title, message: item.msg, onConfirm: item.fn })}
                  className={`flex-1 rounded-2xl px-3 py-2.5 border-2 flex items-center gap-2.5 transition-all active:scale-[0.97] text-left ${item.bg}`}
                >
                  <span className="text-lg leading-none flex-shrink-0">{item.emoji}</span>
                  <div className="min-w-0">
                    <p className="text-sm font-black text-gray-800 leading-tight">{item.label} 초기화</p>
                    <p className="text-[10px] text-gray-500 mt-0.5 leading-tight">{item.desc}</p>
                  </div>
                </button>
                <button
                  onClick={() => hasRestore && restoreMap.get(item.key)!()}
                  disabled={!hasRestore}
                  className={`flex-shrink-0 w-14 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 transition-all text-center ${
                    hasRestore
                      ? 'bg-teal-50 border-teal-300 text-teal-700 hover:bg-teal-100 active:scale-95 cursor-pointer'
                      : 'bg-gray-50 border-gray-200 text-gray-300 cursor-not-allowed opacity-50'
                  }`}
                >
                  <span className="text-base leading-none">↩</span>
                  <span className="text-[9px] font-black leading-tight">복구</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 회식 종료 전체 초기화 */}
      <div className="rounded-2xl p-5 border-2 border-red-300 bg-red-50">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5 mb-0.5">
              <span className="text-xs font-black text-red-600 bg-red-100 border border-red-300 px-2 py-0.5 rounded-full">위험</span>
              <h3 className="font-bold text-red-900 text-sm">회식 종료 전체 초기화</h3>
            </div>
            <p className="text-xs text-red-600 mt-0.5 font-semibold">현재 참여자·하트·채팅·단체채팅 등 삭제 — 익명 행사 합계·매출 집계는 보존. 시작된 회식만 다음 17:00 자동 초기화</p>
          </div>
          <button onClick={() => setConfirmEventEnd(true)}
            className="flex-shrink-0 flex items-center gap-2 px-4 py-2.5 bg-red-600 text-white rounded-xl font-semibold text-sm hover:bg-red-700 transition-all border-2 border-red-800">
            <Trash2 className="w-4 h-4" />
            전체 초기화
          </button>
        </div>
      </div>

      {confirmToggle && (
        <ConfirmDialog
          title={confirmToggle === 'end' ? '회식을 종료하시겠습니까?' : '회식을 시작하시겠습니까?'}
          message={confirmToggle === 'end'
            ? (isActive ? '새 참가자의 입장만 닫습니다. 기존 참가자는 하트·채팅을 계속 사용할 수 있고, 수동 기능잠금은 유지됩니다.' : '이미 대기 중입니다.')
            : (isActive ? '이미 진행 중입니다.' : '시작 시 유저들이 앱에 입장할 수 있습니다.')}
          onConfirm={() => {
            const action = confirmToggle;
            setConfirmToggle(null);
            if ((action === 'start' && !isActive) || (action === 'end' && isActive)) onToggleSession();
          }}
          onCancel={() => setConfirmToggle(null)}
        />
      )}
      {confirmAction && (
        <ConfirmDialog
          title={confirmAction.title}
          message={confirmAction.message}
          danger
          onConfirm={() => { confirmAction.onConfirm(); setConfirmAction(null); }}
          onCancel={() => setConfirmAction(null)}
        />
      )}
      {confirmEventEnd && (
        <ConfirmDialog title="회식 종료 전체 초기화"
          message={`참여자 · 하트 · 채팅 · 단체채팅 등 현재 행사 데이터가 초기화됩니다.\n익명 행사기록과 매출 집계는 보존합니다.\n\n운영 데이터를 복구하지 못할 수 있습니다. 계속하시겠습니까?`}
          danger
          onConfirm={() => { setConfirmEventEnd(false); onEventEndReset(); }}
          onCancel={() => setConfirmEventEnd(false)}
        />
      )}
    </div>
  );
}

// ─── Hearts Tab ───────────────────────────────────────────────────────────────
