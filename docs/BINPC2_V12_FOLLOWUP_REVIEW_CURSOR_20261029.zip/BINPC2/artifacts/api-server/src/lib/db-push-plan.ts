/**
 * Web-push recipient + payload planner — extracted from routes/db.ts.
 * Pure given row lookups; sendPush / subscription prune stay in db.ts.
 */

export type PushPlanPayload = {
  title: string;
  body: string;
  tag?: string;
  url?: string;
};

export type PushPlan =
  | { recipientId: string; payload: PushPlanPayload }
  | null;

/**
 * Plan who gets a push and what it says for messages/likes/signal_sends/chats.
 * Nickname fallbacks and Korean body strings match prior db.ts behavior.
 */
export function planPushForEvent(
  table: string,
  row: Record<string, unknown>,
  actorId: string | null | undefined,
  findChat: (chatId: string) => Record<string, unknown> | undefined,
  findProfile: (userId: string) => Record<string, unknown> | undefined,
): PushPlan {
  if (table === 'messages') {
    const chat = findChat(String(row.chat_id ?? ''));
    const senderId = String(row.sender_id ?? actorId ?? '');
    if (!chat || !senderId) return null;
    const u1 = String(chat.user1_id ?? '');
    const u2 = String(chat.user2_id ?? '');
    const recipientId = u1 === senderId ? u2 : u1;
    if (!recipientId || recipientId === senderId) return null;

    const sender = findProfile(senderId);
    const nick = (sender?.nickname as string) ?? '누군가';
    let body = String(row.content ?? '');
    if (row.image_url) body = '[이미지]';
    else if (body.startsWith('__sticker__')) body = '[스티커]';
    else if (body.length > 60) body = body.slice(0, 60) + '…';

    const chatId = String(chat.id ?? row.chat_id ?? '');
    return {
      recipientId,
      payload: {
        title: `💬 ${nick}`,
        body,
        tag: `message-${String(row.id ?? chatId)}`,
        url: `/?push=chat&peer=${encodeURIComponent(senderId)}&chat=${encodeURIComponent(chatId)}`,
      },
    };
  }

  if (table === 'likes') {
    const senderId = String(row.liker_id ?? actorId ?? '');
    const recipientId = String(row.liked_id ?? '');
    if (!senderId || !recipientId || recipientId === senderId) return null;

    const sender = findProfile(senderId);
    const nick = (sender?.nickname as string) ?? '누군가';
    const heartEmoji =
      row.heart_type === 'red' ? '❤️' :
      row.heart_type === 'blue' ? '💙' :
      row.heart_type === 'pink' ? '💗' : '💚';
    return {
      recipientId,
      payload: {
        title: `${heartEmoji} ${nick}님`,
        body: `${heartEmoji} 하트가 도착했어요`,
        tag: `like-${String(row.id ?? `${senderId}-${row.heart_type ?? ''}`)}`,
        // rainbow source is intentionally hidden: notify as the selected real heart_type.
        url: `/?push=heart&from=${encodeURIComponent(senderId)}`,
      },
    };
  }

  // No phone push for signal_sends, chat-open events, or group chat.
  return null;
}

export type PushSubscribeReject = {
  status: number;
  body: { error: string };
};

export type PushSubscribeOk = {
  ok: true;
  userId: string;
  endpoint: string;
  auth: string;
  p256dh: string;
};

export type PushSubscribeResult = PushSubscribeOk | { ok: false; reject: PushSubscribeReject };

export function validatePushSubscribeBody(body: unknown): PushSubscribeResult {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, reject: { status: 400, body: { error: 'Invalid request body' } } };
  }
  const rawBody = body as Record<string, unknown>;
  const userId = typeof rawBody.userId === 'string' ? rawBody.userId : null;
  const sub = rawBody.subscription;
  const endpoint = sub != null && typeof (sub as Record<string, unknown>).endpoint === 'string'
    ? (sub as Record<string, unknown>).endpoint as string : null;
  const keys = sub != null ? (sub as Record<string, unknown>).keys : null;
  const auth = keys != null && typeof (keys as Record<string, unknown>).auth === 'string'
    ? (keys as Record<string, unknown>).auth as string : null;
  const p256dh = keys != null && typeof (keys as Record<string, unknown>).p256dh === 'string'
    ? (keys as Record<string, unknown>).p256dh as string : null;

  if (!userId || userId.length > 128) {
    return { ok: false, reject: { status: 400, body: { error: 'Missing or invalid userId' } } };
  }
  if (!endpoint || endpoint.length > 2048) {
    return { ok: false, reject: { status: 400, body: { error: 'Missing or invalid endpoint' } } };
  }
  if (!auth || auth.length > 512) {
    return { ok: false, reject: { status: 400, body: { error: 'Missing or invalid auth key' } } };
  }
  if (!p256dh || p256dh.length > 512) {
    return { ok: false, reject: { status: 400, body: { error: 'Missing or invalid p256dh key' } } };
  }
  return { ok: true, userId, endpoint, auth, p256dh };
}

export function pushSubscribeUnauthorizedReject(): PushSubscribeReject {
  return { status: 401, body: { error: 'Unauthorized: invalid SSE token' } };
}


/** One push endpoint belongs to one local account. Prevent previous-account leaks. */
export function pushSubscriptionIdsToReplace(
  subs: Record<string, unknown>[], userId: string, endpoint: string,
  evictIndex: number | null,
): string[] {
  const stale = subs.filter(s => s.endpoint === endpoint && s.user_id !== userId);
  if (evictIndex != null && subs[evictIndex]) stale.push(subs[evictIndex]);
  return [...new Set(stale.map(s => String(s.id ?? '')).filter(Boolean))];
}

export const USER_MAX_PUSH_SUBS = 5;

export type PushSubscribeStorePlan =
  | { kind: 'update'; index: number; row: Record<string, unknown> }
  | { kind: 'insert'; row: Record<string, unknown>; evictIndex: number | null };

/**
 * Plan push_subscriptions memory mutation for /push/subscribe.
 * Evicts oldest user sub when at USER_MAX_PUSH_SUBS (sliding window).
 */
export function planPushSubscribeStore(input: {
  subs: Record<string, unknown>[];
  userId: string;
  endpoint: string;
  auth: string;
  p256dh: string;
  now: string;
  newId: string;
  maxSubs?: number;
}): PushSubscribeStorePlan {
  const max = input.maxSubs ?? USER_MAX_PUSH_SUBS;
  const idx = input.subs.findIndex(
    s => s.user_id === input.userId && s.endpoint === input.endpoint,
  );
  if (idx >= 0) {
    return {
      kind: 'update',
      index: idx,
      row: {
        ...input.subs[idx],
        auth: input.auth,
        p256dh: input.p256dh,
        updated_at: input.now,
      },
    };
  }
  type SubWithIdx = Record<string, unknown> & { _idx: number };
  const userSubs = (input.subs as Array<Record<string, unknown>>)
    .map((s, i) => ({ ...s, _idx: i } as SubWithIdx))
    .filter(s => s['user_id'] === input.userId)
    .sort((a, b) => String(a['created_at']).localeCompare(String(b['created_at'])));
  let evictIndex: number | null = null;
  if (userSubs.length >= max) {
    const oldestIdx = input.subs.findIndex(s => s['id'] === userSubs[0]['id']);
    if (oldestIdx >= 0) evictIndex = oldestIdx;
  }
  return {
    kind: 'insert',
    evictIndex,
    row: {
      id: input.newId,
      user_id: input.userId,
      endpoint: input.endpoint,
      auth: input.auth,
      p256dh: input.p256dh,
      created_at: input.now,
    },
  };
}

export type PushNotifyReject = { status: number; body: { error: string } };

export function pushNotifyForbiddenReject(): PushNotifyReject {
  return { status: 403, body: { error: 'Forbidden' } };
}

export function pushNotifyInvalidBodyReject(): PushNotifyReject {
  return { status: 400, body: { error: 'Invalid request body' } };
}

export function pushNotifyInvalidRecipientReject(): PushNotifyReject {
  return { status: 400, body: { error: 'Missing or invalid recipientId' } };
}

export function pushNotifyInternalReject(): PushNotifyReject {
  return { status: 500, body: { error: 'Internal server error' } };
}

export type PushNotifyBodyOk = {
  ok: true;
  recipientId: string;
  payload: PushPlanPayload;
};

export type PushNotifyBodyResult = PushNotifyBodyOk | { ok: false; reject: PushNotifyReject };

/**
 * /push/notify secret + body validate + payload slice (exact prior wording/limits).
 * Send / store mutate stay in db.ts.
 */
export function validatePushNotifyRequest(input: {
  secretOk: boolean;
  body: unknown;
}): PushNotifyBodyResult {
  if (!input.secretOk) return { ok: false, reject: pushNotifyForbiddenReject() };
  if (input.body == null || typeof input.body !== 'object' || Array.isArray(input.body)) {
    return { ok: false, reject: pushNotifyInvalidBodyReject() };
  }
  const raw = input.body as Record<string, unknown>;
  const recipientId = typeof raw.recipientId === 'string' ? raw.recipientId : null;
  if (!recipientId || recipientId.length > 128) {
    return { ok: false, reject: pushNotifyInvalidRecipientReject() };
  }
  const safeStr = (v: unknown, def: string, max: number) =>
    (typeof v === 'string' ? v : def).slice(0, max);
  return {
    ok: true,
    recipientId,
    payload: {
      title: safeStr(raw.title, '범일NPC 술번개', 64),
      body: safeStr(raw.body, '', 200),
      tag: safeStr(raw.tag, 'notification', 64),
      url: safeStr(raw.url, '/', 512),
    },
  };
}

