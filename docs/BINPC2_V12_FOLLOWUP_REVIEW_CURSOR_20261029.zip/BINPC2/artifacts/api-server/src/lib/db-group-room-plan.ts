/**
 * Group room match / merge / opt-in pure planners — extracted from routes/db.ts.
 * Persist, store mutate, and SSE stay in db.ts (thin wrappers + I/O).
 */
import { groupAgeDecadeBand } from './korean-age.js';

export const MAX_GROUPS_PER_USER = 4;
/** 방 인원 상한 없음. 정원 초과로 방을 나누지 않음. */
export const UNLIMITED_GROUP_MEMBERS = 999999;
export const GROUP_LIMIT_MESSAGE = '단체 채팅은 최대 4개까지 입장할 수 있어요.';

export type OptInGroupRoomSpec = {
  id: string;
  name: string;
  interest_tag: string;
  room_kind: string;
};

export const OPT_IN_GROUP_ROOMS: OptInGroupRoomSpec[] = [
  { id: 'group_afterparty_club', name: '2차 클럽 갈 분', interest_tag: '2차클럽', room_kind: 'afterparty_club' },
  { id: 'group_afterparty_drink', name: '2차 술 갈 분', interest_tag: '2차술', room_kind: 'afterparty_drink' },
];

export const AUTO_ROOM_AGE_DECADE = 'age_decade';
export const AUTO_ROOM_BIRTH_YEAR = 'birth_year';
export const VISIBLE_AGE_BANDS = ['20대', '30대'] as const;
export const RETIRED_AGE_ROOM_RE = /^(10|40|50|60|70)대 모임$/;

export function compactGroupName(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, '');
}

export function matchesAfterpartySpec(
  g: Record<string, unknown>,
  spec: OptInGroupRoomSpec,
): boolean {
  const name = String(g.name ?? '');
  const compact = compactGroupName(name);
  return String(g.id) === spec.id
    || name === spec.name
    || compact === compactGroupName(spec.name)
    || String(g.interest_tag) === spec.interest_tag
    || String(g.room_kind ?? '') === spec.room_kind
    || (spec.room_kind === 'afterparty_club' && (name.includes('2차 클럽') || compact.includes('2차클럽')))
    || (spec.room_kind === 'afterparty_drink' && (name.includes('2차 술') || compact.includes('2차술')));
}

export function matchesVisibleAgeBand(g: Record<string, unknown>, band: string): boolean {
  if (String(g.id) === `group_age_${band.replace(/대$/, '')}`) return true;
  const compact = compactGroupName(g.name);
  return compact === compactGroupName(`${band} 모임`);
}

export function birthYearOfGroup(g: Record<string, unknown>): number | null {
  const idm = String(g.id ?? '').match(/^group_birth_(\d{4})$/);
  if (idm) return Number(idm[1]);
  const namem = String(g.name ?? '').match(/^(\d{4})년생\s*모임$/);
  if (namem) return Number(namem[1]);
  return null;
}

export function isRetiredAgeRoom(g: Record<string, unknown>): boolean {
  const name = String(g.name ?? '');
  const id = String(g.id ?? '');
  const band = String(g.age_group ?? '');
  return RETIRED_AGE_ROOM_RE.test(name)
    || /^group_age_(10|40|50|60|70)$/.test(id)
    || /^(10|40|50|60|70)대$/.test(band);
}

export function ageBandFromYear(year: unknown): string | null {
  return groupAgeDecadeBand(year);
}

export function canonicalAgeRoomId(ageBand: string): string {
  return `group_age_${ageBand.replace(/대$/, '')}`;
}

export function canonicalYearRoomId(year: number): string {
  return `group_birth_${year}`;
}

export function autoRoomOptKey(kind: string, extra: string): string {
  return `${kind}:${extra}`;
}

/**
 * Opt-out / leave slot key for a group.
 * `resolveMergedId` defaults to identity; db.ts passes resolveMergedGroupId.
 */
export function optKeyForGroup(
  group: Record<string, unknown> | undefined,
  groupId: string,
  resolveMergedId: (id: string) => string = (id) => id,
): string {
  const kind = String(group?.room_kind ?? '');
  const name = String(group?.name ?? '');
  const tag = String(group?.interest_tag ?? '');
  const age = String(group?.age_group ?? '');
  if (kind === AUTO_ROOM_AGE_DECADE || /^\d+대 모임$/.test(name)) {
    const band = age || name.match(/^(\d+대)/)?.[1] || tag;
    return autoRoomOptKey(AUTO_ROOM_AGE_DECADE, String(band));
  }
  if (kind === AUTO_ROOM_BIRTH_YEAR || /^\d{4}년생 모임$/.test(name)) {
    const yearTag = /^\d{4}년생$/.test(tag)
      ? tag
      : (name.match(/^(\d{4}년생)/)?.[1] || tag);
    return autoRoomOptKey(AUTO_ROOM_BIRTH_YEAR, String(yearTag));
  }
  if (kind === 'afterparty_club' || tag === '2차클럽' || name.includes('2차 클럽')) return 'afterparty_club';
  if (kind === 'afterparty_drink' || tag === '2차술' || name.includes('2차 술')) return 'afterparty_drink';
  return resolveMergedId(groupId);
}

export function isLeftoverInterestRoom(g: Record<string, unknown>): boolean {
  const kind = String(g.room_kind ?? '');
  const name = String(g.name ?? '');
  if (kind === 'afterparty_club' || kind === 'afterparty_drink') return false;
  if (kind === AUTO_ROOM_BIRTH_YEAR || /^\d{4}년생 모임$/.test(name)) return false;
  if (kind === AUTO_ROOM_AGE_DECADE || /^\d+대 모임$/.test(name)) return false;
  return kind === 'interest_age' || /대\s+.+\s*모임/.test(name) || /모임\s*모임/.test(name);
}

export function afterpartySlotKey(g: Record<string, unknown>): 'afterparty_club' | 'afterparty_drink' | null {
  if (matchesAfterpartySpec(g, OPT_IN_GROUP_ROOMS[0])) return 'afterparty_club';
  if (matchesAfterpartySpec(g, OPT_IN_GROUP_ROOMS[1])) return 'afterparty_drink';
  return null;
}

/** 한도 계산용. 숨긴 중복 2차·레거시 관심사/은퇴 N대는 칸을 차지하지 않음. */
export function groupLimitSlotKey(g: Record<string, unknown> | undefined, groupId: string): string | null {
  if (!g) return null;
  if (g.hidden === true) return null;
  const into = String(g.merged_into ?? '');
  if (into && into !== String(g.id)) return null;
  if (isLeftoverInterestRoom(g) || isRetiredAgeRoom(g)) return null;
  const ap = afterpartySlotKey(g);
  if (ap) return ap;
  const name = String(g.name ?? '');
  if (/^\d{4}년생 모임$/.test(name)) return `year:${name}`;
  if (/^\d+대 모임$/.test(name)) return `age:${name}`;
  return String(g.id || groupId);
}

/** Build a new auto room row (caller supplies id / created_at). */
export function buildAutoRoomRow(spec: {
  id: string;
  name: string;
  interest_tag: string;
  age_group: string | null;
  room_kind: string;
  created_at: string;
}): Record<string, unknown> {
  return {
    id: spec.id,
    name: spec.name,
    interest_tag: spec.interest_tag,
    age_group: spec.age_group,
    room_kind: spec.room_kind,
    max_members: UNLIMITED_GROUP_MEMBERS,
    hidden: false,
    created_at: spec.created_at,
  };
}

/** Fields to refresh on an existing catalog/auto room before join. */
export function patchExistingAutoRoom(
  room: Record<string, unknown>,
  spec: {
    name: string;
    interest_tag: string;
    age_group: string | null;
    room_kind: string;
  },
): Record<string, unknown> {
  return {
    ...room,
    name: spec.name,
    interest_tag: spec.interest_tag,
    room_kind: spec.room_kind,
    age_group: spec.age_group,
    max_members: UNLIMITED_GROUP_MEMBERS,
    hidden: false,
    merged_into: null,
  };
}

/** Whether join should skip afterparty / opt-out / already-member / slot-full. */
export function shouldSkipAutoRoomJoin(input: {
  hasOptOut: boolean;
  roomKind: string;
  alreadyMember: boolean;
  slotsUsed: number;
  maxSlots: number;
}): boolean {
  if (input.hasOptOut) return true;
  if (input.roomKind === 'afterparty_club' || input.roomKind === 'afterparty_drink') return true;
  if (input.alreadyMember) return true;
  if (input.slotsUsed >= input.maxSlots) return true;
  return false;
}

export function buildGroupParticipantRow(
  groupId: string,
  userId: string,
  joinedAt: string,
): Record<string, unknown> {
  return {
    id: `${groupId}__${userId}`,
    group_id: groupId,
    user_id: userId,
    joined_at: joinedAt,
  };
}

export type AutoMatchJoinSpec = {
  room_kind: string;
  name: string;
  interest_tag: string;
  age_group: string | null;
  optKey: string;
  canonicalId: string;
};

/** Pure list of auto rooms a profile should join (age decade + birth year). */
export function planAutoMatchJoinSpecs(profile: Record<string, unknown>): AutoMatchJoinSpec[] {
  const specs: AutoMatchJoinSpec[] = [];
  const ageBand = ageBandFromYear(profile.birth_year);
  const year = Number(profile.birth_year);
  if (ageBand) {
    specs.push({
      room_kind: AUTO_ROOM_AGE_DECADE,
      name: `${ageBand} 모임`,
      interest_tag: ageBand,
      age_group: ageBand,
      optKey: autoRoomOptKey(AUTO_ROOM_AGE_DECADE, ageBand),
      canonicalId: canonicalAgeRoomId(ageBand),
    });
  }
  if (Number.isFinite(year) && year >= 1900 && year <= 2100) {
    specs.push({
      room_kind: AUTO_ROOM_BIRTH_YEAR,
      name: `${year}년생 모임`,
      interest_tag: `${year}년생`,
      age_group: null,
      optKey: autoRoomOptKey(AUTO_ROOM_BIRTH_YEAR, `${year}년생`),
      canonicalId: canonicalYearRoomId(year),
    });
  }
  return specs;
}

export type GroupParticipantMergeAction =
  | { kind: 'delete'; oldId: string }
  | { kind: 'remap'; oldId: string; userId: string; newId: string };

/** Pure plan: move or drop participants when merging dup group into canonical. */
export function planGroupParticipantMerge(
  parts: Record<string, unknown>[],
  dupId: string,
  canonicalId: string,
): GroupParticipantMergeAction[] {
  const actions: GroupParticipantMergeAction[] = [];
  for (const p of parts) {
    if (String(p.group_id) !== dupId) continue;
    const uid = String(p.user_id ?? '');
    const oldId = String(p.id);
    const already = parts.some(
      x => String(x.group_id) === canonicalId && String(x.user_id) === uid,
    );
    if (already) actions.push({ kind: 'delete', oldId });
    else actions.push({ kind: 'remap', oldId, userId: uid, newId: `${canonicalId}__${uid}` });
  }
  return actions;
}

export function filterRowsByGroupId(
  rows: Record<string, unknown>[],
  groupId: string,
): Record<string, unknown>[] {
  return rows.filter(r => String(r.group_id) === groupId);
}

export function groupNeedsUnlimitedMaxMembers(
  g: Record<string, unknown>,
  unlimited: number = UNLIMITED_GROUP_MEMBERS,
): boolean {
  const cap = Number(g.max_members);
  return !Number.isFinite(cap) || cap < unlimited;
}

/** Catalog seed spec for a visible N대 band (20대/30대). */
export function planVisibleAgeBandRoomSpec(band: string): {
  id: string;
  name: string;
  interest_tag: string;
  room_kind: string;
  age_group: string;
} {
  return {
    id: canonicalAgeRoomId(band),
    name: `${band} 모임`,
    interest_tag: band,
    room_kind: 'age_decade',
    age_group: band,
  };
}

/** Catalog seed spec for a birth-year room. */
export function planBirthYearRoomSpec(year: number): {
  id: string;
  name: string;
  interest_tag: string;
  room_kind: string;
  age_group: null;
} {
  return {
    id: canonicalYearRoomId(year),
    name: `${year}년생 모임`,
    interest_tag: `${year}년생`,
    room_kind: 'birth_year',
    age_group: null,
  };
}

/** Group rooms that already carry a birth_year identity, keyed by year. */
export function collectBirthYearRoomGroups(
  groups: Record<string, unknown>[],
): Map<number, Record<string, unknown>[]> {
  const byYear = new Map<number, Record<string, unknown>[]>();
  for (const g of groups) {
    const year = birthYearOfGroup(g);
    if (year == null) continue;
    const list = byYear.get(year) ?? [];
    list.push(g);
    byYear.set(year, list);
  }
  return byYear;
}

export type GroupParticipantMergeApplyEffect =
  | { kind: 'delete'; oldId: string }
  | { kind: 'persist'; row: Record<string, unknown>; oldId: string; deleteOldId: boolean };

/**
 * Apply one group_participants merge action in memory.
 * Delete mutates `parts` in place; remap updates group_id/id on the row.
 * Persist/delete PG I/O stays in the caller.
 */
export function applyGroupParticipantMergeAction(
  parts: Record<string, unknown>[],
  action: GroupParticipantMergeAction,
  canonicalId: string,
): GroupParticipantMergeApplyEffect | null {
  if (action.kind === 'delete') {
    for (let i = parts.length - 1; i >= 0; i--) {
      if (String(parts[i].id) === action.oldId) parts.splice(i, 1);
    }
    return { kind: 'delete', oldId: action.oldId };
  }
  const p = parts.find(x => String(x.id) === action.oldId);
  if (!p) return null;
  p.group_id = canonicalId;
  p.id = action.newId;
  return {
    kind: 'persist',
    row: p,
    oldId: action.oldId,
    deleteOldId: Boolean(action.oldId && action.oldId !== action.newId),
  };
}

/** Mutate group_id on matching rows; returns the remapped rows (for persist). */
export function remapRowsGroupId(
  rows: Record<string, unknown>[],
  fromGroupId: string,
  toGroupId: string,
): Record<string, unknown>[] {
  const hit = filterRowsByGroupId(rows, fromGroupId);
  for (const r of hit) r.group_id = toGroupId;
  return hit;
}
