BINPC2 V6 — GitHub 저장 완료 / 운영 미배포

개발 브랜치: feat/event-hub-v6-20261027
검증 코드 커밋: 73861cf5dfdde94044b36ebde5688b6584090eba
원격: https://github.com/aoaldhkd-spec/BINPC2/tree/feat/event-hub-v6-20261027

가장 쉬운 체험: BINPC2-V6-demo.html 다운로드 → Chrome에서 파일 열기. 로그인/설치 불필요. 기본 가상 3등. 관리자 화면으로 보기 버튼으로 전환. 처음부터 신청은 시험 데이터만 초기화. 실제 정보/송금 금지.
실제 DB 저장/기기 간 복구/실제 예약/실제 발송은 HTML에서 지원하지 않습니다. 실제 기능의 DB/브라우저 검증 증거는 logs와 baseline에 보존합니다.

Cursor는 GitHub 저장소의 위 개발 브랜치를 clone하여 이어가세요. 코드 커밋 이후 문서/다운로드 파일 보존 커밋이 추가될 수 있으므로 최신 원격 HEAD를 기준으로 하세요.
전체 Git bundle은 약464MiB여서 GitHub 파일 크기 제한상 이 ZIP/개발 브랜치에 포함하지 않았으며 기존 로컬 백업과 체크섬을 보존했습니다. ZIP의 작은 dev.bundle은 공통 GitHub main 기반 b06a9002를 요구하는 기존 코드 백업입니다.

단위1300 PASS, Node 운영 스크립트 검사13 PASS, 실제 브라우저5 PASS; DB56은 이전 검증 증거 보존. 79건 경고 개별 분류도 포함합니다. 개인정보 정책 미확정 및 실제 기기 검증은 남아 있습니다.
Netlify 빌드 중단은 사용자가 확인했고 Render main은 유지했습니다. main push/병합, 운영 배포, 모집/외부 알림, 운영 DB 변경은 없습니다.
과거 보고서의 push BLOCKED는 당시 기록이며 현재 상태는 이 README/HANDOFF_STATE.json이 우선합니다.
